<?php

namespace FluentMail\App\Http\Controllers;

use FluentMail\App\Models\Settings;
use FluentMail\App\Services\NotificationHelper;
use FluentMail\App\Services\Notification\Manager as NotificationManager;
use FluentMail\Includes\Request\Request;
use FluentMail\Includes\Support\Arr;

class TelegramController extends Controller
{
    public function issuePinCode(Request $request)
    {
        $this->verify();

        $formData = $request->get('settings', []);

        $userEmail = sanitize_email(Arr::get($formData, 'user_email'));

        if (!is_email($userEmail)) {
            return $this->sendError([
                'message' => __('Please provide a valid email address.', 'fluent-smtp')
            ], 422);
        }

        $payload = [
            'admin_email' => $userEmail,
            'smtp_url'    => admin_url('options-general.php?page=fluent-mail#/'),
            'site_url'    => site_url(),
            'site_title'  => fluentMailSiteTitle(),
            'site_lang'   => get_bloginfo('language'),
        ];


        $activationData = NotificationHelper::issueTelegramPinCode($payload);

        if (is_wp_error($activationData)) {
            return $this->sendError([
                'message' => $activationData->get_error_message(),
                'errors'  => $activationData->get_error_data(),
            ], 422);
        }

        return $this->sendSuccess([
            'message'    => __('Now activate the connection from your Telegram account.', 'fluent-smtp'),
            'site_token' => Arr::get($activationData, 'site_token'),
            'site_pin'   => Arr::get($activationData, 'site_pin'),
        ]);
    }

    public function confirmConnection(Request $request)
    {
        $this->verify();

        $siteToken = $request->get('site_token', '');

        if (empty($siteToken)) {
            return $this->sendError([
                'message' => __('Please provide the site token.', 'fluent-smtp')
            ], 422);
        }


        $connectionInfo = NotificationHelper::getTelegramConnectionInfo($siteToken);

        if (is_wp_error($connectionInfo)) {
            return $this->sendError([
                'message' => $connectionInfo->get_error_message(),
                'errors'  => $connectionInfo->get_error_data(),
            ], 422);
        }

        NotificationHelper::updateChannelSettings('telegram', [
            'status' => 'yes',
            'token'  => $siteToken
        ]);

        return $this->sendSuccess([
            'success' => true,
            'message' => __('Connection successful.', 'fluent-smtp'),
        ]);
    }

    public function getTelegramConnectionInfo(Request $request)
    {
        $this->verify();

        $settings = (new Settings())->notificationSettings();

        if (Arr::get($settings, 'telegram.status') != 'yes') {
            return $this->sendSuccess([
                'message'                => __('Telegram notifications are not enabled.', 'fluent-smtp'),
                'telegram_notify_status' => 'no'
            ], 200);
        }

        $siteToken = Arr::get($settings, 'telegram.token');

        $connectionInfo = NotificationHelper::getTelegramConnectionInfo($siteToken);

        if (is_wp_error($connectionInfo)) {
            return $this->sendSuccess([
                'telegram_notify_status' => 'failed',
                'message'                => $connectionInfo->get_error_message(),
                'errors'                 => $connectionInfo->get_error_data(),
            ]);
        }

        return $this->sendSuccess([
            'telegram_notify_status' => 'yes',
            'telegram_receiver'      => Arr::get($connectionInfo, 'telegram_receiver', []),
        ]);
    }

    public function sendTestMessage(Request $request)
    {
        $this->verify();

        // Let's update the notification status
        $settings = (new Settings())->notificationSettings();

        if (Arr::get($settings, 'telegram.status') != 'yes') {
            return $this->sendError([
                'message' => __('Telegram notifications are not enabled.', 'fluent-smtp')
            ], 422);
        }

        $result = NotificationHelper::sendTestTelegramMessage(Arr::get($settings, 'telegram.token'));

        if (is_wp_error($result)) {
            return $this->sendError([
                'message' => $result->get_error_message(),
                'errors'  => $result->get_error_data(),
            ], 422);
        }

        return $this->sendSuccess([
            'message' => __('Test message sent.', 'fluent-smtp')
        ]);
    }

    public function disconnect()
    {
        $this->verify();

        $settings = (new Settings())->notificationSettings();

        $token = Arr::get($settings, 'telegram.token');

        // Only call disconnect API if we have a token
        if ($token) {
            NotificationHelper::disconnectTelegram($token);
        }

        NotificationHelper::updateChannelSettings('telegram', [
            'status' => 'no',
            'token'  => ''
        ]);

        return $this->sendSuccess([
            'message' => __('Telegram has been disconnected.', 'fluent-smtp')
        ]);
    }
}

( function ( $, rwmb ) {
	'use strict';

	// Cache ajax requests: https://github.com/select2/select2/issues/110#issuecomment-419247158
	var cache = {};

	/**
	 * Reorder selected values in correct order that they were selected.
	 * @param $select2 jQuery element of the select2.
	 */
	function reorderSelected( $select2 ) {
		var selected = $select2.data( 'selected' );
		if ( !selected ) {
			return;
		}
		selected.forEach( function ( value ) {
			var option = $select2.children( '[value="' + value + '"]' );
			option.detach();
			$select2.append( option );
		} );
		$select2.trigger( 'change' );
	}

	function setObjectThumbnailTemplate( options, $select ) {
		if ( ! options.show_thumbnail ) {
			return options;
		}

		const thumbClass = $select.hasClass( 'rwmb-user' )
			? 'rwmb-object-thumbnail rwmb-object-thumbnail--user'
			: 'rwmb-object-thumbnail';

		options.templateResult = function ( data ) {
			if ( ! data.id ) {
				return data.text;
			}
			const $wrap = $( '<span class="rwmb-object-option"></span>' );
			const thumb = data.thumbnail || ( data.element ? $( data.element ).data( 'thumbnail' ) : '' );

			if ( thumb ) {
				$wrap.append( $( '<img>', {
					src: thumb,
					class: thumbClass,
					alt: '',
				} ) );
			}

			$wrap.append( document.createTextNode( data.text || '' ) );
			return $wrap;
		};
		options.templateSelection = options.templateResult;

		return options;
	}

	/**
	 * Transform select fields into beautiful dropdown with select2 library.
	 */
	function transform() {
		var $this = $( this ),
			options = setObjectThumbnailTemplate( $this.data( 'options' ) || {}, $this );

		$this.removeClass( 'select2-hidden-accessible' ).removeAttr( 'data-select2-id' );
		$this.siblings( '.select2-container' ).remove();
		$this.find( 'option' ).removeAttr( 'data-select2-id' );

		if ( options.ajax_data ) {
			options.ajax.dataType = 'json';
			options.ajax.data = function ( params ) {
				return Object.assign( options.ajax_data, params );
			};
			options.ajax.processResults = function ( response ) {
				var items = response.data.items.map( function ( item ) {
					return {
						id: item.value,
						text: _.unescape( item.label ),
						thumbnail: item.thumbnail || ''
					};
				} );

				var results = {
					results: items
				};
				if ( response.data.hasOwnProperty( 'more' ) ) {
					results.pagination = { more: true };
				}

				return results;
			};

			options.ajax.transport = function ( params, success, failure ) {
				if ( params.data._type === 'query' ) {
					delete params.data.page;
				}

				// Create cache key from ajax params from only necessary keys to make cache available for multiple fields.
				var data = $.extend( true, {}, params.data );
				delete data.field.id;
				delete data.action;
				if ( !data.term ) {
					delete data.term;
				}

				var key = JSON.stringify( data );
				if ( cache[ key ] ) {
					success( cache[ key ] );
					return;
				}

				// Action comes from PHP field.ajax_action (set in each field's normalize()).
				params.data.action = params.data.field.ajax_action;
				params.method = 'POST';

				return $.ajax( params ).then( function ( data ) {
					cache[ key ] = data;
					return data;
				} ).then( success ).fail( failure );
			};
		}

		$this.show();

		if ( $this.hasClass( 'rwmb-icon' ) ) {
			// Initialize select2 with icons for icon field.
			$this.trigger( 'init_icon_field', [ options ] );
		} else {
			// Initialize select2 normally.
			$this.select2( options );
		}

		if ( !$this.attr( 'multiple' ) ) {
			return;
		}

		reorderSelected( $this );

		/**
		 * Preserve the order that options are selected.
		 * @see https://github.com/select2/select2/issues/3106#issuecomment-255492815
		 */
		$this.on( 'select2:select', function ( event ) {
			var option = $this.children( '[value="' + event.params.data.id + '"]' );
			option.detach();
			$this.append( option ).trigger( 'change' );
		} );
	}

	function init( e ) {
		$( e.target ).find( '.rwmb-select_advanced, .rwmb-icon' ).each( transform );
	}

	function fixDropdownPosition( e ) {
		if ( $( "#wpadminbar" ).length === 0 ) {
			return;
		}

		if ( rwmbSelect2.isAdmin == 1 ) {
			$( 'body > .select2-container--open .select2-dropdown--above' ).css( 'top', 0 );
			return;
		}

		$( 'body > .select2-container:last-child > .select2-dropdown' ).css( 'top', $( document.body ).offset().top );
	};

	rwmb.$document
		.on( 'mb_ready', init )
		.on( 'clone', '.rwmb-select_advanced, .rwmb-icon', transform )
		.on( 'select2:open', fixDropdownPosition );
} )( jQuery, rwmb );

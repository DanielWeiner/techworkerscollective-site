<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * The mega-class.
 *
 * This contains too much, so please think twice before adding more.
 *
 * @package automattic/jetpack
 */

use Automattic\Jetpack\Assets;
use Automattic\Jetpack\Boost_Speed_Score\Speed_Score;
use Automattic\Jetpack\Config;
use Automattic\Jetpack\Connection\Authorize_Json_Api;
use Automattic\Jetpack\Connection\Client;
use Automattic\Jetpack\Connection\Manager as Connection_Manager;
use Automattic\Jetpack\Connection\Rest_Authentication as Connection_Rest_Authentication;
use Automattic\Jetpack\Connection\Secrets;
use Automattic\Jetpack\Connection\Tokens;
use Automattic\Jetpack\Connection\Webhooks\Authorize_Redirect;
use Automattic\Jetpack\Constants;
use Automattic\Jetpack\CookieState;
use Automattic\Jetpack\Current_Plan as Jetpack_Plan;
use Automattic\Jetpack\Device_Detection\User_Agent_Info;
use Automattic\Jetpack\Errors;
use Automattic\Jetpack\Feature_Policy;
use Automattic\Jetpack\Files;
use Automattic\Jetpack\Heartbeat;
use Automattic\Jetpack\Identity_Crisis;
use Automattic\Jetpack\Import\Main as Import_Main;
use Automattic\Jetpack\Licensing;
use Automattic\Jetpack\Modules;
use Automattic\Jetpack\My_Jetpack\Initializer as My_Jetpack_Initializer;
use Automattic\Jetpack\Newsletter\Reader_Link;
use Automattic\Jetpack\Paths;
use Automattic\Jetpack\Plugin\Deprecate;
use Automattic\Jetpack\Plugin\Tracking as Plugin_Tracking;
use Automattic\Jetpack\Podcast\Podcast;
use Automattic\Jetpack\Redirect;
use Automattic\Jetpack\Scan_Page\Jetpack_Scan as Scan_Page_Init;
use Automattic\Jetpack\SEO\Initializer as Jetpack_SEO_Initializer;
use Automattic\Jetpack\Status;
use Automattic\Jetpack\Status\Host;
use Automattic\Jetpack\Status\Visitor;
use Automattic\Jetpack\Sync\Actions as Sync_Actions;
use Automattic\Jetpack\Sync\Health;
use Automattic\Jetpack\Sync\Sender;
use Automattic\Jetpack\Terms_Of_Service;
use Automattic\Jetpack\Tracking;
use Automattic\Woocommerce_Analytics;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/*
Options:
jetpack_options (array)
	An array of options.
	@see Jetpack_Options::get_option_names()

jetpack_register (string)
	Temporary verification secrets.

jetpack_activated (int)
	1: the plugin was activated normally
	2: the plugin was activated on this site because of a network-wide activation
	3: the plugin was auto-installed
	4: the plugin was manually disconnected (but is still installed)

jetpack_active_modules (array)
	Array of active module slugs.

jetpack_do_activate (bool)
	Flag for "activating" the plugin on sites where the activation hook never fired (auto-installs)
*/

require_once JETPACK__PLUGIN_DIR . '_inc/lib/class.media.php';

/**
 * The Jetpack class.
 */
class Jetpack {
	/**
	 * XMLRPC server instance.
	 *
	 * @var null|Jetpack_XMLRPC_Server XMLRPC server used by Jetpack.
	 */
	public $xmlrpc_server = null;

	/**
	 * Contains all assets that have had their URL rewritten to minified versions.
	 *
	 * @var array
	 */
	public static $min_assets = array();

	/**
	 * Plugins to deactivate.
	 *
	 * @var array Plugins to deactivate by module.
	 */
	public $plugins_to_deactivate = array(
		'contact-form'        => array(
			array( 'grunion-contact-form/grunion-contact-form.php', 'Grunion Contact Form' ),
			array( 'mullet/mullet-contact-form.php', 'Mullet Contact Form' ),
		),
		'gravatar-hovercards' => array(
			array( 'jetpack-gravatar-hovercards/gravatar-hovercards.php', 'Jetpack Gravatar Hovercards' ),
		),
		'latex'               => array(
			array( 'wp-latex/wp-latex.php', 'WP LaTeX' ),
		),
		'random-redirect'     => array(
			array( 'random-redirect/random-redirect.php', 'Random Redirect' ),
		),
		'sharedaddy'          => array(
			array( 'sharedaddy/sharedaddy.php', 'Sharedaddy' ),
			array( 'jetpack-sharing/sharedaddy.php', 'Jetpack Sharing' ),
		),
		'shortlinks'          => array(
			array( 'stats/stats.php', 'WordPress.com Stats' ),
		),
		'stats'               => array(
			array( 'stats/stats.php', 'WordPress.com Stats' ),
		),
		'twitter-widget'      => array(
			array( 'wickett-twitter-widget/wickett-twitter-widget.php', 'Wickett Twitter Widget' ),
		),
		'videopress'          => array(
			array( 'video/video.php', 'VideoPress' ),
		),
		'widget-visibility'   => array(
			array( 'jetpack-widget-visibility/widget-visibility.php', 'Jetpack Widget Visibility' ),
			array( 'widget-visibility-without-jetpack/widget-visibility-without-jetpack.php', 'Widget Visibility Without Jetpack' ),
		),
	);

	/**
	 * Map of roles we care about, and their corresponding minimum capabilities.
	 *
	 * @deprecated 7.6 Use Automattic\Jetpack\Roles::$capability_translations instead.
	 *
	 * @access public
	 * @static
	 *
	 * @var array
	 */
	public static $capability_translations = array(
		'administrator' => 'manage_options',
		'editor'        => 'edit_others_posts',
		'author'        => 'publish_posts',
		'contributor'   => 'edit_posts',
		'subscriber'    => 'read',
	);

	/**
	 * Map of modules that have conflicts with plugins and should not be auto-activated
	 * if the plugins are active.  Used by filter_default_modules
	 *
	 * Plugin Authors: If you'd like to prevent a single module from auto-activating,
	 * change `module-slug` and add this to your plugin:
	 *
	 * add_filter( 'jetpack_get_default_modules', 'my_jetpack_get_default_modules' );
	 * function my_jetpack_get_default_modules( $modules ) {
	 *     return array_diff( $modules, array( 'module-slug' ) );
	 * }
	 *
	 * @var array
	 */
	private $conflicting_plugins = array(
		'comments'           => array(
			'Intense Debate'                 => 'intensedebate/intensedebate.php',
			'Disqus'                         => 'disqus-comment-system/disqus.php',
			'Livefyre'                       => 'livefyre-comments/livefyre.php',
			'Comments Evolved for WordPress' => 'gplus-comments/comments-evolved.php',
			'Google+ Comments'               => 'google-plus-comments/google-plus-comments.php',
			'WP-SpamShield Anti-Spam'        => 'wp-spamshield/wp-spamshield.php',
		),
		'comment-likes'      => array(
			'Epoch' => 'epoch/plugincore.php',
		),
		'latex'              => array(
			'LaTeX for WordPress'     => 'latex/latex.php',
			'Youngwhans Simple Latex' => 'youngwhans-simple-latex/yw-latex.php',
			'Easy WP LaTeX'           => 'easy-wp-latex-lite/easy-wp-latex-lite.php',
			'MathJax-LaTeX'           => 'mathjax-latex/mathjax-latex.php',
			'Enable Latex'            => 'enable-latex/enable-latex.php',
			'WP QuickLaTeX'           => 'wp-quicklatex/wp-quicklatex.php',
		),
		'protect'            => array(
			'Limit Login Attempts'              => 'limit-login-attempts/limit-login-attempts.php',
			'Captcha'                           => 'captcha/captcha.php',
			'Brute Force Login Protection'      => 'brute-force-login-protection/brute-force-login-protection.php',
			'Login Security Solution'           => 'login-security-solution/login-security-solution.php',
			'WPSecureOps Brute Force Protect'   => 'wpsecureops-bruteforce-protect/wpsecureops-bruteforce-protect.php',
			'BulletProof Security'              => 'bulletproof-security/bulletproof-security.php',
			'SiteGuard WP Plugin'               => 'siteguard/siteguard.php',
			'Security-protection'               => 'security-protection/security-protection.php',
			'Login Security'                    => 'login-security/login-security.php',
			'Botnet Attack Blocker'             => 'botnet-attack-blocker/botnet-attack-blocker.php',
			'Wordfence Security'                => 'wordfence/wordfence.php',
			'All In One WP Security & Firewall' => 'all-in-one-wp-security-and-firewall/wp-security.php',
			'iThemes Security'                  => 'better-wp-security/better-wp-security.php',
		),
		'random-redirect'    => array(
			'Random Redirect 2' => 'random-redirect-2/random-redirect.php',
		),
		'related-posts'      => array(
			'YARPP'                       => 'yet-another-related-posts-plugin/yarpp.php',
			'WordPress Related Posts'     => 'wordpress-23-related-posts-plugin/wp_related_posts.php',
			'nrelate Related Content'     => 'nrelate-related-content/nrelate-related.php',
			'Contextual Related Posts'    => 'contextual-related-posts/contextual-related-posts.php',
			'Related Posts for WordPress' => 'microkids-related-posts/microkids-related-posts.php',
			'outbrain'                    => 'outbrain/outbrain.php',
			'Shareaholic'                 => 'shareaholic/shareaholic.php',
			'Sexybookmarks'               => 'sexybookmarks/shareaholic.php',
		),
		'sharedaddy'         => array(
			'AddThis'     => 'addthis/addthis_social_widget.php',
			'Add To Any'  => 'add-to-any/add-to-any.php',
			'ShareThis'   => 'share-this/sharethis.php',
			'Shareaholic' => 'shareaholic/shareaholic.php',
		),
		'seo-tools'          => array(
			'WordPress SEO by Yoast'         => 'wordpress-seo/wp-seo.php',
			'WordPress SEO Premium by Yoast' => 'wordpress-seo-premium/wp-seo-premium.php',
			'All in One SEO Pack'            => 'all-in-one-seo-pack/all_in_one_seo_pack.php',
			'All in One SEO Pack Pro'        => 'all-in-one-seo-pack-pro/all_in_one_seo_pack.php',
			'The SEO Framework'              => 'autodescription/autodescription.php',
			'Rank Math'                      => 'seo-by-rank-math/rank-math.php',
			'Slim SEO'                       => 'slim-seo/slim-seo.php',
			'SEOKEY'                         => 'seo-key/seo-key.php',
			'SEOKEY Pro'                     => 'seo-key-pro/seo-key.php',
			'SEOPress'                       => 'wp-seopress/seopress.php',
			'SEOPress Pro'                   => 'wp-seopress-pro/seopress-pro.php',
		),
		'verification-tools' => array(
			'WordPress SEO by Yoast'         => 'wordpress-seo/wp-seo.php',
			'WordPress SEO Premium by Yoast' => 'wordpress-seo-premium/wp-seo-premium.php',
			'All in One SEO Pack'            => 'all-in-one-seo-pack/all_in_one_seo_pack.php',
			'All in One SEO Pack Pro'        => 'all-in-one-seo-pack-pro/all_in_one_seo_pack.php',
			'The SEO Framework'              => 'autodescription/autodescription.php',
			'Rank Math'                      => 'seo-by-rank-math/rank-math.php',
			'Slim SEO'                       => 'slim-seo/slim-seo.php',
		),
		'widget-visibility'  => array(
			'Widget Logic'    => 'widget-logic/widget_logic.php',
			'Dynamic Widgets' => 'dynamic-widgets/dynamic-widgets.php',
		),
		'sitemaps'           => array(
			'Google XML Sitemaps'                  => 'google-sitemap-generator/sitemap.php',
			'Better WordPress Google XML Sitemaps' => 'bwp-google-xml-sitemaps/bwp-simple-gxs.php',
			'Google XML Sitemaps for qTranslate'   => 'google-xml-sitemaps-v3-for-qtranslate/sitemap.php',
			'XML Sitemap & Google News feeds'      => 'xml-sitemap-feed/xml-sitemap.php',
			'Google Sitemap by BestWebSoft'        => 'google-sitemap-plugin/google-sitemap-plugin.php',
			'WordPress SEO by Yoast'               => 'wordpress-seo/wp-seo.php',
			'WordPress SEO Premium by Yoast'       => 'wordpress-seo-premium/wp-seo-premium.php',
			'All in One SEO Pack'                  => 'all-in-one-seo-pack/all_in_one_seo_pack.php',
			'All in One SEO Pack Pro'              => 'all-in-one-seo-pack-pro/all_in_one_seo_pack.php',
			'The SEO Framework'                    => 'autodescription/autodescription.php',
			'Sitemap'                              => 'sitemap/sitemap.php',
			'Simple Wp Sitemap'                    => 'simple-wp-sitemap/simple-wp-sitemap.php',
			'Simple Sitemap'                       => 'simple-sitemap/simple-sitemap.php',
			'XML Sitemaps'                         => 'xml-sitemaps/xml-sitemaps.php',
			'MSM Sitemaps'                         => 'msm-sitemap/msm-sitemap.php',
			'Rank Math'                            => 'seo-by-rank-math/rank-math.php',
			'Slim SEO'                             => 'slim-seo/slim-seo.php',
		),
	);

	/**
	 * Plugins for which we turn off our Facebook OG Tags implementation.
	 *
	 * Note: the following plugins automatically deactivate Jetpack's Open
	 * Graph tags via filter when their Social Meta modules are active:
	 *
	 * - All in One SEO Pack, All in one SEO Pack Pro
	 * - WordPress SEO by Yoast, WordPress SEO Premium by Yoast
	 *
	 * Plugin authors: If you'd like to prevent Jetpack's Open Graph tag generation in your plugin, you can do so via this filter:
	 * add_filter( 'jetpack_enable_open_graph', '__return_false' );
	 *
	 * @var array Array of plugin slugs.
	 */
	private $open_graph_conflicting_plugins = array(
		'2-click-socialmedia-buttons/2-click-socialmedia-buttons.php', // 2 Click Social Media Buttons.
		'add-link-to-facebook/add-link-to-facebook.php',         // Add Link to Facebook.
		'add-meta-tags/add-meta-tags.php',                       // Add Meta Tags.
		'complete-open-graph/complete-open-graph.php',           // Complete Open Graph.
		'easy-facebook-share-thumbnails/esft.php',               // Easy Facebook Share Thumbnail.
		'heateor-open-graph-meta-tags/heateor-open-graph-meta-tags.php', // Open Graph Meta Tags by Heateor.
		'facebook/facebook.php',                                 // Facebook (official plugin).
		'facebook-awd/AWD_facebook.php',                         // Facebook AWD All in one.
		'facebook-featured-image-and-open-graph-meta-tags/fb-featured-image.php', // Facebook Featured Image & OG Meta Tags.
		'facebook-meta-tags/facebook-metatags.php',              // Facebook Meta Tags.
		'wonderm00ns-simple-facebook-open-graph-tags/wonderm00n-open-graph.php', // Facebook Open Graph Meta Tags for WordPress.
		'facebook-revised-open-graph-meta-tag/index.php',        // Facebook Revised Open Graph Meta Tag.
		'facebook-thumb-fixer/_facebook-thumb-fixer.php',        // Facebook Thumb Fixer.
		'facebook-and-digg-thumbnail-generator/facebook-and-digg-thumbnail-generator.php', // Fedmich's Facebook Open Graph Meta.
		'network-publisher/networkpub.php',                      // Network Publisher.
		'nextgen-facebook/nextgen-facebook.php',                 // NextGEN Facebook OG.
		'social-networks-auto-poster-facebook-twitter-g/NextScripts_SNAP.php', // NextScripts SNAP.
		'og-tags/og-tags.php',                                   // OG Tags.
		'opengraph/opengraph.php',                               // Open Graph.
		'open-graph-protocol-framework/open-graph-protocol-framework.php', // Open Graph Protocol Framework.
		'seo-facebook-comments/seofacebook.php',                 // SEO Facebook Comments.
		'seo-ultimate/seo-ultimate.php',                         // SEO Ultimate.
		'sexybookmarks/sexy-bookmarks.php',                      // Shareaholic.
		'shareaholic/sexy-bookmarks.php',                        // Shareaholic.
		'sharepress/sharepress.php',                             // SharePress.
		'simple-facebook-connect/sfc.php',                       // Simple Facebook Connect.
		'social-discussions/social-discussions.php',             // Social Discussions.
		'social-sharing-toolkit/social_sharing_toolkit.php',     // Social Sharing Toolkit.
		'socialize/socialize.php',                               // Socialize.
		'squirrly-seo/squirrly.php',                             // SEO by SQUIRRLY™.
		'only-tweet-like-share-and-google-1/tweet-like-plusone.php', // Tweet, Like, Google +1 and Share.
		'wordbooker/wordbooker.php',                             // Wordbooker.
		'wpsso/wpsso.php',                                       // WordPress Social Sharing Optimization.
		'wp-caregiver/wp-caregiver.php',                         // WP Caregiver.
		'wp-facebook-like-send-open-graph-meta/wp-facebook-like-send-open-graph-meta.php', // WP Facebook Like Send & Open Graph Meta.
		'wp-facebook-open-graph-protocol/wp-facebook-ogp.php',   // WP Facebook Open Graph protocol.
		'wp-ogp/wp-ogp.php',                                     // WP-OGP.
		'wp-seopress/seopress.php',                              // SEOPress.
		'wp-seopress-pro/seopress-pro.php',                      // SEOPress Pro.
		'zoltonorg-social-plugin/zosp.php',                      // Zolton.org Social Plugin.
		'wp-fb-share-like-button/wp_fb_share-like_widget.php',   // WP Facebook Like Button.
		'open-graph-metabox/open-graph-metabox.php',              // Open Graph Metabox.
		'seo-by-rank-math/rank-math.php',                        // Rank Math.
		'slim-seo/slim-seo.php',                                 // Slim SEO.
	);

	/**
	 * Plugins for which we turn off our Twitter Cards Tags implementation.
	 *
	 * @var array Plugins that conflict with Twitter cards.
	 */
	private $twitter_cards_conflicting_plugins = array(
		// phpcs:ignore Squiz.PHP.CommentedOutCode.Found
		// 'twitter/twitter.php',                       // The official one handles this on its own.
		// https://github.com/twitter/wordpress/blob/master/src/Twitter/WordPress/Cards/Compatibility.php
			'eewee-twitter-card/index.php',              // Eewee Twitter Card.
		'ig-twitter-cards/ig-twitter-cards.php',     // IG:Twitter Cards.
		'jm-twitter-cards/jm-twitter-cards.php',     // JM Twitter Cards.
		'kevinjohn-gallagher-pure-web-brilliants-social-graph-twitter-cards-extention/kevinjohn_gallagher___social_graph_twitter_output.php',  // Pure Web Brilliant's Social Graph Twitter Cards Extension.
		'twitter-cards/twitter-cards.php',           // Twitter Cards.
		'twitter-cards-meta/twitter-cards-meta.php', // Twitter Cards Meta.
		'wp-to-twitter/wp-to-twitter.php',           // WP to Twitter.
		'wp-twitter-cards/twitter_cards.php',        // WP Twitter Cards.
		'seo-by-rank-math/rank-math.php',            // Rank Math.
		'slim-seo/slim-seo.php',                     // Slim SEO.
	);

	/**
	 * Message to display in admin_notice
	 *
	 * @var string
	 */
	public $message = '';

	/**
	 * Error to display in admin_notice
	 *
	 * @var string
	 */
	public $error = '';

	/**
	 * Modules that need more privacy description.
	 *
	 * @var string
	 */
	public $privacy_checks = '';

	/**
	 * Stats to record once the page loads
	 *
	 * @var array
	 */
	public $stats = array();

	/**
	 * Jetpack_Sync object
	 *
	 * @todo This is also seemingly unused.
	 *
	 * @var object
	 */
	public $sync;

	/**
	 * Verified data for JSON authorization request
	 *
	 * @deprecated 13.4
	 *
	 * @var array
	 */
	public $json_api_authorization_request = array();

	/**
	 * Connection manager.
	 *
	 * @var Automattic\Jetpack\Connection\Manager
	 */
	protected $connection_manager;

	/**
	 * Plugin lock key.
	 *
	 * @var string Transient key used to prevent multiple simultaneous plugin upgrades
	 */
	public static $plugin_upgrade_lock_key = 'jetpack_upgrade_lock';

	/**
	 * Holds an instance of Automattic\Jetpack\A8c_Mc_Stats
	 *
	 * @var Automattic\Jetpack\A8c_Mc_Stats
	 */
	public $a8c_mc_stats_instance;

	/**
	 * Constant for login redirect key.
	 *
	 * @var string
	 * @since 8.4.0
	 */
	public static $jetpack_redirect_login = 'jetpack_connect_login_redirect';

	/**
	 * Holds the singleton instance of this class
	 *
	 * @since 2.3.3
	 * @var Jetpack
	 */
	public static $instance = false;

	/**
	 * Resolved answer for `is_premium_analytics_enabled()`, or null before the first call.
	 *
	 * @since 16.1
	 * @var bool|null
	 */
	private static $premium_analytics_enabled = null;

	/**
	 * Singleton
	 *
	 * @static
	 */
	public static function init() {
		if ( ! self::$instance ) {
			self::$instance = new Jetpack();
			add_action( 'plugins_loaded', array( self::$instance, 'plugin_upgrade' ) );
			add_action( 'jetpack_idc_disconnect', array( __CLASS__, 'on_idc_disconnect' ) );
		}

		return self::$instance;
	}

	/**
	 * Must never be called statically
	 */
	public function plugin_upgrade() {
		if ( self::is_connection_ready() ) {
			list( $version ) = explode( ':', Jetpack_Options::get_option( 'version' ) );
			if ( JETPACK__VERSION !== $version ) {
				// Prevent multiple upgrades at once - only a single process should trigger an upgrade to avoid stampedes.
				if ( wp_using_ext_object_cache() ) {
					if ( true !== wp_cache_add( self::$plugin_upgrade_lock_key, 1, 'transient', 10 ) ) {
						return;
					}
				} else {
					if ( false !== get_transient( self::$plugin_upgrade_lock_key ) ) {
						return;
					}

					set_transient( self::$plugin_upgrade_lock_key, 1, 10 );
				}

				// check which active modules actually exist and remove others from active_modules list.
				$unfiltered_modules = self::get_active_modules();
				$modules            = array_filter( $unfiltered_modules, array( 'Jetpack', 'is_module' ) );
				if ( array_diff( $unfiltered_modules, $modules ) ) {
					self::update_active_modules( $modules );
				}

				self::register_upgrade_init_hooks();

				// Upgrade to 4.3.0.
				if ( Jetpack_Options::get_option( 'identity_crisis_whitelist' ) ) {
					Jetpack_Options::delete_option( 'identity_crisis_whitelist' );
				}

				// Make sure Markdown for posts gets turned back on.
				if ( ! get_option( 'wpcom_publish_posts_with_markdown' ) ) {
					update_option( 'wpcom_publish_posts_with_markdown', true );
				}

				/*
				 * Minileven deprecation. 8.3.0.
				 * Only delete options if not using
				 * the replacement standalone Minileven plugin.
				 */
				if (
					! self::is_plugin_active( 'minileven-master/minileven.php' )
					&& ! self::is_plugin_active( 'minileven/minileven.php' )
				) {
					if ( get_option( 'wp_mobile_custom_css' ) ) {
						delete_option( 'wp_mobile_custom_css' );
					}
					if ( get_option( 'wp_mobile_excerpt' ) ) {
						delete_option( 'wp_mobile_excerpt' );
					}
					if ( get_option( 'wp_mobile_featured_images' ) ) {
						delete_option( 'wp_mobile_featured_images' );
					}
					if ( get_option( 'wp_mobile_app_promos' ) ) {
						delete_option( 'wp_mobile_app_promos' );
					}
				}

				// Upgrade to 8.4.0.
				if ( Jetpack_Options::get_option( 'ab_connect_banner_green_bar' ) ) {
					Jetpack_Options::delete_option( 'ab_connect_banner_green_bar' );
				}

				// Update to 8.8.x (WordPress 5.5 Compatibility).
				if ( Jetpack_Options::get_option( 'autoupdate_plugins' ) ) {
					$updated = update_site_option(
						'auto_update_plugins',
						array_unique(
							array_merge(
								(array) Jetpack_Options::get_option( 'autoupdate_plugins', array() ),
								(array) get_site_option( 'auto_update_plugins', array() )
							)
						)
					);

					if ( $updated ) {
						Jetpack_Options::delete_option( 'autoupdate_plugins' );
					} // Should we have some type of fallback if something fails here?
				}

				// Set the newsletter send default option for existing sites.
				if ( false === get_option( 'wpcom_newsletter_send_default' ) ) {
					add_option( 'wpcom_newsletter_send_default', 1 );
				}

				// Its handler went with the Recommendations assistant.
				wp_clear_scheduled_hook( 'jetpack_recommend_videopress' );

				if ( did_action( 'wp_loaded' ) ) {
					self::upgrade_on_load();
				} else {
					add_action(
						'wp_loaded',
						array( __CLASS__, 'upgrade_on_load' )
					);
				}
			}
		}
	}

	/**
	 * Runs upgrade routines that need to have modules loaded.
	 */
	public static function upgrade_on_load() {

		// Not attempting any upgrades if jetpack_modules_loaded did not fire.
		// This can happen in case Jetpack has been just upgraded and is
		// being initialized late during the page load. In this case we wait
		// until the next proper admin page load with Jetpack active.
		if ( ! did_action( 'jetpack_modules_loaded' ) ) {
			delete_transient( self::$plugin_upgrade_lock_key );

			return;
		}

		self::maybe_set_version_option();

		if ( method_exists( 'Jetpack_Widget_Conditions', 'migrate_post_type_rules' ) ) {
			Jetpack_Widget_Conditions::migrate_post_type_rules();
		}

		if (
			class_exists( 'Jetpack_Sitemap_Manager' )
		) {
			do_action( 'jetpack_sitemaps_purge_data' );
		}

		// Delete old stats cache.
		delete_option( 'jetpack_restapi_stats_cache' );

		delete_transient( self::$plugin_upgrade_lock_key );
	}

	/**
	 * Saves all the currently active modules to options.
	 * Also fires Action hooks for each newly activated and deactivated module.
	 *
	 * @param array $modules Array of active modules to be saved in options.
	 *
	 * @return bool $success true for success, false for failure.
	 */
	public static function update_active_modules( $modules ) {
		return ( new Modules() )->update_active( $modules );
	}

	/**
	 * Remove all active modules.
	 *
	 * @return void
	 */
	public static function delete_active_modules() {
		self::update_active_modules( array() );
	}

	/**
	 * Adds a hook to plugins_loaded at a priority that's currently the earliest
	 * available.
	 */
	public function add_configure_hook() {
		global $wp_filter;

		$current_priority = has_filter( 'plugins_loaded', array( $this, 'configure' ) );
		if ( false !== $current_priority ) {
			remove_action( 'plugins_loaded', array( $this, 'configure' ), $current_priority );
		}

		$taken_priorities = array_map( 'intval', array_keys( $wp_filter['plugins_loaded']->callbacks ) );
		sort( $taken_priorities );

		$first_priority = array_shift( $taken_priorities );

		if ( $first_priority <= PHP_INT_MIN ) {
			$new_priority = PHP_INT_MIN;
		} else {
			$new_priority = $first_priority - 1;
		}

		add_action( 'plugins_loaded', array( $this, 'configure' ), $new_priority );
	}

	/**
	 * Constructor.  Initializes WordPress hooks
	 */
	private function __construct() {
		/*
		 * Check for and alert any deprecated hooks
		 */
		add_action( 'init', array( $this, 'deprecated_hooks' ) );

		// Note how this runs at an earlier plugin_loaded hook intentionally to accomodate for other plugins.
		add_action( 'plugin_loaded', array( $this, 'add_configure_hook' ), 90 );
		add_action( 'network_plugin_loaded', array( $this, 'add_configure_hook' ), 90 );
		add_action( 'mu_plugin_loaded', array( $this, 'add_configure_hook' ), 90 );
		add_action( 'plugins_loaded', array( $this, 'late_initialization' ), 90 );

		/**
		 * Prepare Gutenberg Editor functionality
		 *
		 * The hooks previously here have been moved to modules/blocks.php but leaving this here pending
		 * a longer investigation to see if code is expecting the Gutenberg class to always be available.
		 */
		require_once JETPACK__PLUGIN_DIR . 'class.jetpack-gutenberg.php';
		add_action( 'set_user_role', array( $this, 'maybe_clear_other_linked_admins_transient' ), 10, 3 );

		add_action( 'jetpack_event_log', array( 'Jetpack', 'log' ), 10, 2 );

		add_filter( 'login_url', array( $this, 'login_url' ), 10, 2 );
		add_action( 'login_init', array( $this, 'login_init' ) );

		// Set up the REST authentication hooks.
		Connection_Rest_Authentication::init();

		// Register Jetpack-specific connection tests (sync health, etc.) with the connection
		// package's health test suite. This runs on all requests (not just admin), because
		// the connection/test REST endpoint can be called outside admin context.
		add_action( 'jetpack_connection_tests_loaded', array( $this, 'register_jetpack_connection_tests' ) );

		add_action( 'admin_init', array( $this, 'admin_init' ) );
		add_action( 'admin_init', array( $this, 'dismiss_jetpack_notice' ) );

		add_filter( 'admin_body_class', array( $this, 'admin_body_class' ), 20 );

		// Filter the dashboard meta box order to swap the new one in in place of the old one.
		add_filter( 'get_user_option_meta-box-order_dashboard', array( $this, 'get_user_option_meta_box_order_dashboard' ) );

		// WordPress dashboard widget.
		require_once JETPACK__PLUGIN_DIR . 'class-jetpack-stats-dashboard-widget.php';
		add_action( 'wp_dashboard_setup', array( new Jetpack_Stats_Dashboard_Widget(), 'init' ) );

		// Returns HTTPS support status.
		add_action( 'wp_ajax_jetpack-recheck-ssl', array( $this, 'ajax_recheck_ssl' ) );

		add_action( 'wp_loaded', array( $this, 'register_assets' ) );

		/**
		 * These actions run checks to load additional files.
		 * They check for external files or plugins, so they need to run as late as possible.
		 */
		add_action( 'wp_head', array( $this, 'check_open_graph' ), 1 );
		add_action( 'web_stories_story_head', array( $this, 'check_open_graph' ), 1 );
		add_action( 'plugins_loaded', array( $this, 'check_twitter_tags' ), 999 );
		add_action( 'plugins_loaded', array( $this, 'check_rest_api_compat' ), 1000 );

		add_filter( 'plugins_url', array( 'Jetpack', 'maybe_min_asset' ), 1, 3 );
		add_action( 'style_loader_src', array( 'Jetpack', 'set_suffix_on_min' ), 10, 2 );

		add_filter( 'profile_update', array( 'Jetpack', 'user_meta_cleanup' ) );

		add_filter( 'jetpack_get_default_modules', array( $this, 'filter_default_modules' ) );
		add_filter( 'jetpack_get_default_modules', array( $this, 'handle_deprecated_modules' ), 99 );

		add_action(
			'plugins_loaded',
			function () {
				if ( User_Agent_Info::is_mobile_app() ) {
					add_filter( 'get_edit_post_link', '__return_empty_string' );
				}
			}
		);

		// Update the site's Jetpack plan and products from API on heartbeats.
		add_action( 'jetpack_heartbeat', array( Jetpack_Plan::class, 'refresh_from_wpcom' ) );

		// The Connection package fetches the site record for `jetpack/v4/site`; reuse it to refresh the plan.
		add_action( 'jetpack_site_data_fetched', array( Jetpack_Plan::class, 'update_from_site_record' ) );

		// Actually push the stats on shutdown.
		if ( ! has_action( 'shutdown', array( $this, 'push_stats' ) ) ) {
			add_action( 'shutdown', array( $this, 'push_stats' ) );
		}

		// After a successful connection.
		add_action( 'jetpack_site_registered', array( $this, 'activate_default_modules_on_site_register' ) );
		add_action( 'jetpack_site_registered', array( $this, 'handle_unique_registrations_stats' ) );
		add_action( 'jetpack_site_registered', array( Reader_Link::class, 'activate_on_connection' ), 9 );
		add_action( 'jetpack_site_registered', array( \Automattic\Jetpack\Reprint_Export\Reprint_Exporter::class, 'discard_credentials' ) );

		// Actions for Manager::authorize().
		add_action( 'jetpack_authorize_starting', array( $this, 'authorize_starting' ) );
		add_action( 'jetpack_authorize_ending_linked', array( $this, 'authorize_ending_linked' ) );
		add_action( 'jetpack_authorize_ending_authorized', array( $this, 'authorize_ending_authorized' ) );

		Jetpack_Client_Server::init();
		add_action( 'jetpack_client_authorize_error', array( Jetpack_Client_Server::class, 'client_authorize_error' ) );
		add_filter( 'jetpack_client_authorize_already_authorized_url', array( Jetpack_Client_Server::class, 'client_authorize_already_authorized_url' ) );
		add_action( 'jetpack_client_authorize_processing', array( Jetpack_Client_Server::class, 'client_authorize_processing' ) );
		add_filter( 'jetpack_client_authorize_fallback_url', array( Jetpack_Client_Server::class, 'client_authorize_fallback_url' ) );

		// Filters for the Manager::get_token() urls and request body.
		add_filter( 'jetpack_token_redirect_url', array( Authorize_Redirect::class, 'filter_connect_redirect_url' ) );
		add_filter( 'jetpack_token_request_body', array( __CLASS__, 'filter_token_request_body' ) );

		// Filter for the `jetpack/v4/connection/data` API response.
		add_filter( 'jetpack_current_user_connection_data', array( __CLASS__, 'filter_jetpack_current_user_connection_data' ) );

		// Actions for successful reconnect.
		add_action( 'jetpack_reconnection_completed', array( $this, 'reconnection_completed' ) );

		// Actions for successful disconnect.
		add_action( 'jetpack_site_disconnected', array( $this, 'jetpack_site_disconnected' ) );

		// Actions for licensing.
		Licensing::instance()->initialize();

		// Filters for Sync Callables.
		add_filter( 'jetpack_sync_callable_whitelist', array( $this, 'filter_sync_callable_whitelist' ), 10, 1 );
		add_filter( 'jetpack_sync_multisite_callable_whitelist', array( $this, 'filter_sync_multisite_callable_whitelist' ), 10, 1 );

		// Make resources use static domain when possible.
		add_filter( 'jetpack_static_url', array( 'Automattic\\Jetpack\\Assets', 'staticize_subdomain' ) );

		// Validate the domain names in Jetpack development versions.
		add_action( 'jetpack_pre_register', array( static::class, 'registration_check_domains' ) );

		// Register product descriptions for partner coupon usage.
		add_filter( 'jetpack_partner_coupon_products', array( $this, 'get_partner_coupon_product_descriptions' ) );

		// Add 5-star
		add_filter( 'plugin_row_meta', array( $this, 'add_5_star_review_link' ), 10, 2 );
		add_action( 'init', array( Deprecate::class, 'instance' ) );

		// Register Jetpack module management abilities (WordPress Abilities API, WP 6.9+).
		\Automattic\Jetpack\Plugin\Abilities\Modules_Abilities::init();

		// Register Connection abilities (WordPress Abilities API, WP 6.9+). Scoped to the
		// Jetpack plugin for now: the Connection package no longer auto-wires these, so
		// connection-only consumers (Boost, Protect, Search, etc.) do not register them yet.
		\Automattic\Jetpack\Connection\Abilities\Connection_Abilities::init();
	}

	/**
	 * Whether the current request should eagerly initialize the admin/REST-only
	 * packages (the Import package and My Jetpack) now, at `plugins_loaded` time.
	 *
	 * Returns true for admin, cron, POST, and WP-CLI requests — the contexts,
	 * knowable this early, where those packages have work to do. Returns false
	 * for a plain front-end GET *and* for a REST request: the two can't be told
	 * apart yet (this runs before `rest_api_init`), so callers defer the REST
	 * case by initializing the package on `rest_api_init` instead, while a plain
	 * page view never fires that hook and so loads nothing. This keeps
	 * admin/REST-only PHP out of opcache on the front-end GET hot path.
	 *
	 * No in-repo code depends on the deferral. The one externally observable
	 * change is timing: the packages' documented init hooks
	 * (`jetpack_import_initialized`, `jetpack_feature_import_enabled`, and
	 * `my_jetpack_init`) no longer fire on a plain front-end GET — they fire on
	 * the admin, cron, POST, WP-CLI, and REST requests where the packages load.
	 *
	 * @return bool
	 */
	private static function should_eager_load_packages() {
		$is_post_request = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) );
		$is_wp_cli       = Constants::is_true( 'WP_CLI' );

		return is_admin() || wp_doing_cron() || $is_post_request || $is_wp_cli;
	}

	/**
	 * Configure the Import package from a deferred hook.
	 *
	 * The eager path uses Config::ensure( 'import' ), but the deferred REST path
	 * runs after Config::on_plugins_loaded() has already processed its feature
	 * flags, so it needs a hookable bootstrap callback. Preserve Config's
	 * feature-enabled action for hook consumers.
	 *
	 * @since 16.0
	 *
	 * @return void
	 */
	public static function configure_import_package() {
		if ( class_exists( Import_Main::class ) ) {
			Import_Main::configure();

			if ( ! did_action( 'jetpack_feature_import_enabled' ) ) {
				do_action( 'jetpack_feature_import_enabled' );
			}
		}
	}

	/**
	 * Enable the bundled Backup dashboard.
	 *
	 * The standalone plugin initializes the package first, so with both active this is a no-op.
	 *
	 * @return void
	 */
	public static function configure_backup_package() {
		// Not offered on multisite, which the Backup package does not support, or without a
		// connected owner, since buying and managing backups needs a linked account.
		if ( is_multisite() || ! self::is_connection_ready() || ! self::connection()->has_connected_owner() ) {
			return;
		}

		if ( ! self::is_module_active( 'backup' ) ) {
			return;
		}

		/**
		 * Filters whether the Jetpack plugin offers its bundled Backup dashboard.
		 *
		 * Resolved at the earliest `plugins_loaded` priority, so hook it from a mu-plugin.
		 *
		 * @since 16.3
		 *
		 * @param bool $enabled Whether to initialize the bundled Backup dashboard. Default true.
		 */
		if ( ! apply_filters( 'jetpack_backup_dashboard_enabled', true ) ) {
			return;
		}

		$backup = 'Automattic\\Jetpack\\Backup\\V0005\\Jetpack_Backup';

		// An older package would take over the connection (see Jetpack_Backup::DEFAULT_INIT_OPTIONS);
		// only the standalone plugin ships one that old, and it draws its own menu.
		if ( ! class_exists( $backup ) || ! defined( $backup . '::DEFAULT_INIT_OPTIONS' ) ) {
			return;
		}

		$backup::initialize( array( 'manage_connection' => false ) );
	}

	/**
	 * Whether the bundled Stats v2 dashboard is enabled.
	 *
	 * Stats v2 (formerly "Premium Analytics") ships with the plugin behind this
	 * flag while it rolls out (WOOA7S-1595). When enabled it adds its own admin
	 * menu alongside the existing Stats UI; it never replaces or hides the
	 * legacy Stats menu, admin-bar entries, post-list column, or WP dashboard
	 * widget. The Stats module's tracking is unaffected either way, and Stats v2
	 * reads what that module collects, so while the module is off the plugin
	 * answers false here before even reading the flag.
	 *
	 * The package has to be loadable for this to be true, so a site with the
	 * flag on but a missing package answers false here and never adds the
	 * Stats v2 menu (a warning is logged instead).
	 *
	 * @since 16.1
	 *
	 * @return bool
	 */
	public static function is_premium_analytics_enabled() {
		if ( null !== self::$premium_analytics_enabled ) {
			return self::$premium_analytics_enabled;
		}

		if ( ! self::is_module_active( 'stats' ) ) {
			self::$premium_analytics_enabled = false;
			return false;
		}

		/**
		 * Filters whether the bundled Premium Analytics dashboard is enabled.
		 *
		 * Resolved once, from `Jetpack::configure()` on `plugins_loaded`, and only
		 * while the Stats module is active. Register this from a mu-plugin or a
		 * plugin's main file — a callback added on `plugins_loaded` or later runs
		 * too late to be seen.
		 *
		 * @since 16.1
		 *
		 * @param bool $enabled Defaults to the `jetpack_premium_analytics_enabled` option (false).
		 */
		$flag = (bool) apply_filters( 'jetpack_premium_analytics_enabled', (bool) get_option( 'jetpack_premium_analytics_enabled' ) );

		self::$premium_analytics_enabled = $flag && class_exists( 'Automattic\Jetpack\PremiumAnalytics\Analytics' );

		if ( $flag && ! self::$premium_analytics_enabled ) {
			wp_trigger_error(
				__METHOD__,
				'The jetpack_premium_analytics_enabled flag is on but the Premium Analytics package is not loadable; keeping the Stats UI in place.'
			);
		}

		return self::$premium_analytics_enabled;
	}

	/**
	 * Expose the setting that turns the Premium Analytics dashboard on and off.
	 *
	 * Deliberately not behind is_premium_analytics_enabled(): this is the setting that flips that
	 * check, so it has to answer while the dashboard is still off.
	 *
	 * @since 16.2
	 *
	 * @return void
	 */
	public static function register_premium_analytics_enablement_setting() {
		if ( class_exists( 'Automattic\Jetpack\PremiumAnalytics\Enablement_Setting' ) ) {
			\Automattic\Jetpack\PremiumAnalytics\Enablement_Setting::register();
		}
	}

	/**
	 * Before everything else starts getting initalized, we need to initialize Jetpack using the
	 * Config object.
	 */
	public function configure() {
		$config = new Config();

		foreach (
			array(
				'jitm',
				'sync',
				'account_protection',
				'waf',
			)
			as $feature
		) {
			$config->ensure( $feature );
		}

		// Enable the VideoPress admin UI (the "Jetpack > VideoPress" dashboard) inside the
		// Jetpack plugin, mirroring the standalone Jetpack VideoPress plugin. The dashboard
		// only renders when the VideoPress module is active (Status::is_active()); when it
		// is not, the menu item links to the My Jetpack interstitial to activate it.
		$config->ensure( 'videopress', array( 'admin_ui' => true ) );

		// The Backup dashboard is only an admin menu and REST routes, so it is deferred like Import below.
		if ( self::should_eager_load_packages() ) {
			self::configure_backup_package();
		} else {
			add_action( 'rest_api_init', array( __CLASS__, 'configure_backup_package' ), 0 );
		}

		/*
		 * The Import package only registers `jetpack/v4/import` REST routes — it
		 * does nothing when rendering a front-end page — so gate its `ensure()`
		 * to keep its PHP out of opcache on the front-end GET hot path. It still
		 * loads on admin, cron, POST, and WP-CLI requests, and on `rest_api_init`
		 * for REST: a REST request can't be identified yet at `plugins_loaded`
		 * (this runs before `Config::on_plugins_loaded`, and `rest_api_init`
		 * fires later), so it is initialized directly when that hook fires, while
		 * a plain page view never fires it and so loads nothing.
		 *
		 * JITM stays eager (above): unlike Import, its `register()` adds a
		 * `jetpack_sync_before_send_updated_option` filter that records the
		 * `jetpack_last_plugin_sync` transient, and a Jetpack Sync send can fire
		 * on a plain front-end GET — including the dedicated-sync `spawn-sync`
		 * GET, which runs on `init` and exits before `rest_api_init`. Deferring
		 * JITM would skip that bookkeeping and leave its message cache stale after
		 * a plugin change, so it loads on every request as before.
		 */
		if ( self::should_eager_load_packages() ) {
			$config->ensure( 'import' );
		} else {
			add_action(
				'rest_api_init',
				array( __CLASS__, 'configure_import_package' ),
				0
			);
		}

		/*
		 * The Stats and Stats Admin packages only do work when the Stats module
		 * is active (the front-end tracking pixel) or on wp-admin, REST, cron,
		 * POST, and WP-CLI requests: the Stats dashboard page, the stats /
		 * stats-app REST endpoints (which the block editor also calls for
		 * email-open rates), the transient-cleanup cron, the connection
		 * package's package-version tracker (which runs on POSTs and reads the
		 * `jetpack_package_versions` filter that Stats registers), and CLI
		 * introspection such as the heartbeat inspector. On a plain front-end
		 * GET page view with the module off they are inert: the pixel
		 * short-circuits on `Stats\Main::should_track()` and every other entry
		 * point only hooks rest_api_init, admin, cron, the POST-only tracker, or
		 * is reached through WP-CLI.
		 * Skip loading them — and eagerly constructing the Stats Admin REST
		 * controller — on that hot path to keep their PHP out of opcache, but
		 * keep loading them everywhere else exactly as before so the stats REST
		 * permission mapping (view_stats, registered by Stats\Main), the
		 * editor's stats-app calls, the cleanup cron, and the package-version
		 * tracker are all unchanged.
		 *
		 * REST requests are not yet identifiable here (REST_REQUEST is defined
		 * after plugins_loaded), so defer those to rest_api_init. Call the
		 * package initializers directly rather than `$config->ensure()`: ensure()
		 * only flags a feature for `Config::on_plugins_loaded()` (plugins_loaded
		 * priority 2), which has already run by the time rest_api_init fires.
		 * Priority 0 runs before each package's own priority-10 route
		 * registration, so their routes still register within the same dispatch.
		 * A plain page view never fires rest_api_init, so the packages stay
		 * unloaded there. See JETPACK-1747.
		 */
		$is_post_request = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
		$is_wp_cli       = defined( 'WP_CLI' ) && WP_CLI;

		if ( self::is_module_active( 'stats' ) || is_admin() || wp_doing_cron() || $is_post_request || $is_wp_cli ) {
			$config->ensure( 'stats' );
			$config->ensure( 'stats_admin' );
		} else {
			add_action(
				'rest_api_init',
				static function () {
					if ( class_exists( 'Automattic\Jetpack\Stats\Main' ) ) {
						\Automattic\Jetpack\Stats\Main::init();
					}
					if ( class_exists( 'Automattic\Jetpack\Stats_Admin\Main' ) ) {
						\Automattic\Jetpack\Stats_Admin\Main::init();
					}
				},
				0
			);
		}

		// Stats v2 (WOOA7S-1595). Unlike Stats above it cannot be deferred when enabled — see
		// Analytics::init() for why, and for why it takes no menu_title here.
		if ( self::is_premium_analytics_enabled() ) {
			\Automattic\Jetpack\PremiumAnalytics\Analytics::init();
		}

		// Outside the check above on purpose — see Enablement_Setting. Deferred like Stats, to keep
		// the autoload off the front-end hot path.
		add_action( 'rest_api_init', array( __CLASS__, 'register_premium_analytics_enablement_setting' ), 0 );

		$config->ensure(
			'connection',
			array(
				'slug' => 'jetpack',
				'name' => 'Jetpack',
			)
		);

		// Identity crisis package.
		$config->ensure(
			'identity_crisis',
			array(
				'slug'       => 'jetpack',
				'admin_page' => '/wp-admin/admin.php?page=jetpack',
			)
		);

		$config->ensure( 'search' );

		if ( ! $this->connection_manager ) {
			$this->connection_manager = new Connection_Manager( 'jetpack' );
		}

		$modules = new Automattic\Jetpack\Modules();
		if ( $modules->is_active( 'publicize' ) && $this->connection_manager->has_connected_user() ) {
			$config->ensure( 'publicize' );
		}

		add_action( 'jetpack_initialize_tracking', array( $this, 'initialize_tracking' ) );

		/*
		 * Load things that should only be in Network Admin.
		 *
		 * For now blow away everything else until a more full
		 * understanding of what is needed at the network level is
		 * available
		 */
		if ( is_multisite() ) {
			$network = Jetpack_Network::init();
			$network->set_connection( $this->connection_manager );
		}

		$is_connection_ready = self::is_connection_ready();

		if ( $is_connection_ready ) {
			add_action( 'login_form_jetpack_json_api_authorization', array( $this, 'login_form_json_api_authorization' ) );
			$this->run_initialize_tracking_action();

			Jetpack_Heartbeat::init();
			if ( self::is_module_active( 'stats' ) && self::is_module_active( 'search' ) ) {
				require_once JETPACK__PLUGIN_DIR . '_inc/lib/class.jetpack-search-performance-logger.php';
				Jetpack_Search_Performance_Logger::init();
			}
		} else {
			add_action( 'jetpack_agreed_to_terms_of_service', array( $this, 'run_initialize_tracking_action' ) );
			add_action( 'rest_api_init', array( $this, 'run_initialize_tracking_action' ) );
			add_filter(
				'xmlrpc_methods',
				function ( $methods ) {
					$this->run_initialize_tracking_action();
					return $methods;
				},
				1
			);
		}

		// Initialize remote file upload request handlers.
		$this->add_remote_request_handlers();

		/*
		 * Enable enhanced handling of previewing sites in Calypso
		 */
		if ( $is_connection_ready ) {
			require_once JETPACK__PLUGIN_DIR . '_inc/lib/class.jetpack-iframe-embed.php';
			add_action( 'init', array( 'Jetpack_Iframe_Embed', 'init' ), 9, 0 );
			add_action( 'rest_api_init', array( $this, 'maybe_initialize_rest_jsonapi' ) );
		}
	}

	/**
	 * Runs on plugins_loaded. Use this to add code that needs to be executed later than other
	 * initialization code.
	 *
	 * @action plugins_loaded
	 */
	public function late_initialization() {
		add_action( 'after_setup_theme', array( 'Jetpack', 'load_modules' ), -2 );

		/*
		 * My Jetpack is a wp-admin dashboard. Its Initializer::init() only wires
		 * up admin-menu, admin_init, and rest_api_init surfaces — and eagerly
		 * loads every product class (backup, boost, protect, …) just to register
		 * admin plugin-action links — so none of it is needed on a plain
		 * front-end GET page view. (The pieces that do immediate work, e.g.
		 * Connection REST authentication and Licensing, are already initialized
		 * unconditionally in Jetpack's constructor, so they are unaffected here.)
		 *
		 * Gate the call to the request types where My Jetpack actually does work.
		 * REST can't be detected yet at plugins_loaded, so initialize on
		 * rest_api_init for that branch; a plain page view never fires it, so My
		 * Jetpack stays unloaded there.
		 */
		if ( self::should_eager_load_packages() ) {
			My_Jetpack_Initializer::init();
		} else {
			add_action( 'rest_api_init', array( My_Jetpack_Initializer::class, 'init' ), 0 );
		}

		Scan_Page_Init::initialize();
		Jetpack_SEO_Initializer::init();

		if ( ( new Modules() )->is_active( 'podcast' ) ) {
			Podcast::init();
		}

		/*
		 * Initialize Boost Speed Score. It only does work on REST requests (the
		 * dashboard speed-score endpoints) and on a few Jetpack Boost lifecycle
		 * actions, so defer constructing it — and loading the boost-speed-score
		 * package classes — until one of those hooks actually fires instead of on
		 * every request. Priority 0 ensures the object's own callbacks (added in
		 * its constructor at the default priority) still run for the firing hook.
		 */
		$initialize_speed_score = static function () {
			static $initialized = false;
			if ( $initialized ) {
				return;
			}
			$initialized = true;
			new Speed_Score( array(), 'jetpack-dashboard' );
		};
		add_action( 'rest_api_init', $initialize_speed_score, 0 );
		add_action( 'jetpack_boost_deactivate', $initialize_speed_score, 0 );
		add_action( 'jetpack_boost_environment_changed', $initialize_speed_score, 0 );
		add_action( 'handle_environment_change', $initialize_speed_score, 0 );

		/**
		 * Fires when Jetpack is fully loaded and ready. This is the point where it's safe
		 * to instantiate classes from packages and namespaces that are managed by the Jetpack Autoloader.
		 *
		 * @since 8.1.0
		 *
		 * @param Jetpack $jetpack the main plugin class object.
		 */
		do_action( 'jetpack_loaded', $this );

		add_filter( 'map_meta_cap', array( $this, 'jetpack_custom_caps' ), 1, 2 );
	}

	/**
	 * This is ported over from the manage module, which has been deprecated and baked in here.
	 */
	public function add_wpcom_to_allowed_redirect_hosts() {
		add_filter( 'allowed_redirect_hosts', array( $this, 'allow_wpcom_domain' ) );
	}

	/**
	 * Return $domains, with 'wordpress.com' appended.
	 * This is ported over from the manage module, which has been deprecated and baked in here.
	 *
	 * @param array $domains Array of domains allowed for redirect.
	 *
	 * @return array
	 */
	public function allow_wpcom_domain( $domains ) {
		if ( empty( $domains ) ) {
			$domains = array();
		}
		$domains[] = 'wordpress.com';
		return array_unique( $domains );
	}

	/**
	 * Redirect edit post links to Calypso.
	 *
	 * @deprecated since 13.9
	 *
	 * @param string $default_url Post edit URL.
	 * @param int    $post_id Post ID.
	 *
	 * @return string
	 */
	public function point_edit_post_links_to_calypso( $default_url, $post_id ) {
		_deprecated_function( __METHOD__, '13.9' );

		$post = get_post( $post_id );

		if ( empty( $post ) ) {
			return $default_url;
		}

		$post_type = $post->post_type;

		// Mapping the allowed CPTs on WordPress.com to corresponding paths in Calypso.
		// https://en.support.wordpress.com/custom-post-types/.
		$allowed_post_types = array(
			'post',
			'page',
			'jetpack-portfolio',
			'jetpack-testimonial',
		);

		if ( ! in_array( $post_type, $allowed_post_types, true ) ) {
			return $default_url;
		}

		return Redirect::get_url(
			'calypso-edit-' . $post_type,
			array(
				'path' => $post_id,
			)
		);
	}

	/**
	 * Redirect edit comment links to Calypso.
	 *
	 * @deprecated since 13.9
	 *
	 * @param string $url Comment edit URL.
	 *
	 * @return string
	 */
	public function point_edit_comment_links_to_calypso( $url ) {
		_deprecated_function( __METHOD__, '13.9' );

		// Take the `query` key value from the URL, and parse its parts to the $query_args. `amp;c` matches the comment ID.
		$query_args = null;
		wp_parse_str( wp_parse_url( $url, PHP_URL_QUERY ), $query_args );

		return Redirect::get_url(
			'calypso-edit-comment',
			array(
				'path' => $query_args['amp;c'],
			)
		);
	}

	/**
	 * Extend Sync callables with Jetpack Plugin functions.
	 *
	 * @param array $callables list of callables.
	 *
	 * @return array list of callables.
	 */
	public function filter_sync_callable_whitelist( $callables ) {
		// Jetpack Functions.
		$jetpack_callables = array(
			'single_user_site'         => array( 'Jetpack', 'is_single_user_site' ),
			'updates'                  => array( 'Jetpack', 'get_updates' ),
			'available_jetpack_blocks' => array( 'Jetpack_Gutenberg', 'get_availability' ), // Includes both Gutenberg blocks *and* plugins.
			'theme_styles'             => array( 'Automattic\\Jetpack\\Plugin\\Theme_Styles_Sync', 'get_theme_styles' ),
		);
		return array_merge( $callables, $jetpack_callables );
	}

	/**
	 * Extend Sync multisite callables with Jetpack Plugin functions.
	 *
	 * @param array $callables list of callables.
	 *
	 * @return array list of callables.
	 */
	public function filter_sync_multisite_callable_whitelist( $callables ) {

		// Jetpack Funtions.
		$jetpack_multisite_callables = array(
			'network_name'                        => array( 'Jetpack', 'network_name' ),
			'network_allow_new_registrations'     => array( 'Jetpack', 'network_allow_new_registrations' ),
			'network_add_new_users'               => array( 'Jetpack', 'network_add_new_users' ),
			'network_site_upload_space'           => array( 'Jetpack', 'network_site_upload_space' ),
			'network_upload_file_types'           => array( 'Jetpack', 'network_upload_file_types' ),
			'network_enable_administration_menus' => array( 'Jetpack', 'network_enable_administration_menus' ),
		);
		$callables                   = array_merge( $callables, $jetpack_multisite_callables );

		return $callables;
	}

	/**
	 * If there are any stats that need to be pushed, but haven't been, push them now.
	 */
	public function push_stats() {
		if ( ! empty( $this->stats ) ) {
			$this->do_stats( 'server_side' );
		}
	}

	/**
	 * Sets the Jetpack custom capabilities.
	 *
	 * @param string[] $caps    Array of the user's capabilities.
	 * @param string   $cap     Capability name.
	 */
	public function jetpack_custom_caps( $caps, $cap ) {
		switch ( $cap ) {
			case 'jetpack_manage_autoupdates':
				$caps = array(
					'manage_options',
					'update_plugins',
				);
				break;
			case 'jetpack_network_admin_page':
			case 'jetpack_network_settings_page':
				$caps = array( 'manage_network_plugins' );
				break;
			case 'jetpack_network_sites_page':
				$caps = array( 'manage_sites' );
				break;
			case 'jetpack_admin_page':
				$is_offline_mode = ( new Status() )->is_offline_mode();
				if ( $is_offline_mode ) {
					$caps = array( 'manage_options' );
					break;
				} else {
					$caps = array( 'edit_posts' );
				}
				break;
		}
		return $caps;
	}

	/**
	 * Register assets for use in various modules and the Jetpack admin page.
	 *
	 * @uses wp_script_is, wp_register_script, plugins_url
	 * @action wp_loaded
	 * @return void
	 */
	public function register_assets() {
		if ( ! wp_script_is( 'jetpack-gallery-settings', 'registered' ) ) {
			wp_register_script(
				'jetpack-gallery-settings',
				Assets::get_file_url_for_environment( '_inc/build/gallery-settings.min.js', '_inc/gallery-settings.js' ),
				array( 'media-views' ),
				'20121225',
				true
			);
		}

		if ( ! wp_script_is( 'jetpack-twitter-timeline', 'registered' ) ) {
			wp_register_script(
				'jetpack-twitter-timeline',
				Assets::get_file_url_for_environment( '_inc/build/twitter-timeline.min.js', '_inc/twitter-timeline.js' ),
				array(),
				'4.0.0',
				true
			);
		}

		if ( ! wp_script_is( 'jetpack-facebook-embed', 'registered' ) ) {
			wp_register_script(
				'jetpack-facebook-embed',
				Assets::get_file_url_for_environment( '_inc/build/facebook-embed.min.js', '_inc/facebook-embed.js' ),
				array(),
				JETPACK__VERSION,
				true
			);

			/** This filter is documented in modules/sharedaddy/sharing-sources.php */
			$fb_app_id = apply_filters( 'jetpack_sharing_facebook_app_id', '249643311490' );
			if ( ! is_numeric( $fb_app_id ) ) {
				$fb_app_id = '';
			}
			wp_localize_script(
				'jetpack-facebook-embed',
				'jpfbembed',
				array(
					'appid'  => $fb_app_id,
					'locale' => $this->get_locale(),
				)
			);
		}

		/**
		 * As jetpack_register_genericons is by default fired off a hook,
		 * the hook may have already fired by this point.
		 * So, let's just trigger it manually.
		 */
		require_once JETPACK__PLUGIN_DIR . '_inc/genericons.php';
		jetpack_register_genericons();

		/**
		 * Register the social logos
		 */
		require_once JETPACK__PLUGIN_DIR . '_inc/social-logos.php';
		jetpack_register_social_logos();
	}

	/**
	 * Guess locale from language code.
	 *
	 * @param string $lang Language code.
	 * @return string|bool
	 */
	public function guess_locale_from_lang( $lang ) {
		if ( 'en' === $lang || 'en_US' === $lang || ! $lang ) {
			return 'en_US';
		}

		if ( ! class_exists( 'GP_Locales' ) ) {
			if ( ! defined( 'JETPACK__GLOTPRESS_LOCALES_PATH' ) || ! file_exists( JETPACK__GLOTPRESS_LOCALES_PATH ) ) {
				return false;
			}

			require JETPACK__GLOTPRESS_LOCALES_PATH;
		}

		if ( defined( 'IS_WPCOM' ) && IS_WPCOM ) {
			// WP.com: get_locale() returns 'it'.
			$locale = GP_Locales::by_slug( $lang );
		} else {
			// Jetpack: get_locale() returns 'it_IT';.
			$locale = GP_Locales::by_field( 'facebook_locale', $lang );
		}

		if ( ! $locale ) {
			return false;
		}

		if ( empty( $locale->facebook_locale ) ) {
			if ( empty( $locale->wp_locale ) ) {
				return false;
			} else {
				// Facebook SDK is smart enough to fall back to en_US if a
				// locale isn't supported. Since supported Facebook locales
				// can fall out of sync, we'll attempt to use the known
				// wp_locale value and rely on said fallback.
				return $locale->wp_locale;
			}
		}

		return $locale->facebook_locale;
	}

	/**
	 * Get the locale.
	 *
	 * @return string|bool
	 */
	public function get_locale() {
		$locale = $this->guess_locale_from_lang( get_locale() );

		if ( ! $locale ) {
			$locale = 'en_US';
		}

		return $locale;
	}

	/**
	 * Return the network_site_url so that .com knows what network this site is a part of.
	 *
	 * @return string
	 */
	public function jetpack_main_network_site_option() {
		return network_site_url();
	}
	/**
	 * Network Name.
	 */
	public static function network_name() {
		global $current_site;
		return $current_site->site_name;
	}
	/**
	 * Does the network allow new user and site registrations.
	 *
	 * @return string
	 */
	public static function network_allow_new_registrations() {
		return ( in_array( get_site_option( 'registration' ), array( 'none', 'user', 'blog', 'all' ), true ) ? get_site_option( 'registration' ) : 'none' );
	}
	/**
	 * Does the network allow admins to add new users.
	 *
	 * @return bool
	 */
	public static function network_add_new_users() {
		return (bool) get_site_option( 'add_new_users' );
	}
	/**
	 * File upload psace left per site in MB.
	 *  -1 means NO LIMIT.
	 *
	 * @return int
	 */
	public static function network_site_upload_space() {
		// value in MB.
		return ( get_site_option( 'upload_space_check_disabled' ) ? -1 : get_space_allowed() );
	}

	/**
	 * Network allowed file types.
	 *
	 * @return string
	 */
	public static function network_upload_file_types() {
		return get_site_option( 'upload_filetypes', 'jpg jpeg png gif' );
	}

	/**
	 * Maximum file upload size set by the network.
	 *
	 * @return int
	 */
	public static function network_max_upload_file_size() {
		// value in KB.
		return get_site_option( 'fileupload_maxk', 300 );
	}

	/**
	 * Lets us know if a site allows admins to manage the network.
	 *
	 * @return array
	 */
	public static function network_enable_administration_menus() {
		return get_site_option( 'menu_items' );
	}

	/**
	 * If a user has been promoted to or demoted from admin, we need to clear the
	 * jetpack_other_linked_admins transient.
	 *
	 * @since 4.3.2
	 * @since 4.4.0  $old_roles is null by default and if it's not passed, the transient is cleared.
	 *
	 * @param int    $user_id   The user ID whose role changed.
	 * @param string $role      The new role.
	 * @param array  $old_roles An array of the user's previous roles.
	 */
	public function maybe_clear_other_linked_admins_transient( $user_id, $role, $old_roles = null ) {
		if ( 'administrator' === $role
			|| ( is_array( $old_roles ) && in_array( 'administrator', $old_roles, true ) )
			|| $old_roles === null
		) {
			delete_transient( 'jetpack_other_linked_admins' );
		}
	}

	/**
	 * Checks to see if there are any other users available to become primary
	 * Users must both:
	 * - Be linked to wpcom
	 * - Be an admin
	 *
	 * @return mixed False if no other users are linked, Int if there are.
	 */
	public static function get_other_linked_admins() {
		$other_linked_users = get_transient( 'jetpack_other_linked_admins' );

		if ( false === $other_linked_users ) {
			$admins = get_users( array( 'role' => 'administrator' ) );
			if ( count( $admins ) > 1 ) {
				$available = array();
				foreach ( $admins as $admin ) {
					if ( self::connection()->is_user_connected( $admin->ID ) ) {
						$available[] = $admin->ID;
					}
				}

				$count_connected_admins = count( $available );
				if ( count( $available ) > 1 ) {
					$other_linked_users = $count_connected_admins;
				} else {
					$other_linked_users = 0;
				}
			} else {
				$other_linked_users = 0;
			}

			set_transient( 'jetpack_other_linked_admins', $other_linked_users, HOUR_IN_SECONDS );
		}

		return ( 0 === $other_linked_users ) ? false : $other_linked_users;
	}

	/**
	 * Return whether we are dealing with a multi network setup or not.
	 * The reason we are type casting this is because we want to avoid the situation where
	 * the result is false since when is_main_network_option return false it cases
	 * the rest the get_option( 'jetpack_is_multi_network' ); to return the value that is set in the
	 * database which could be set to anything as opposed to what this function returns.
	 *
	 * @return boolean
	 */
	public function is_main_network_option() {
		// returns either an '1' or an empty string.
		return (string) (bool) self::is_multi_network();
	}

	/**
	 * Return true if we are with multi-site or multi-network false if we are dealing with single site.
	 *
	 * @return string
	 */
	public function is_multisite() {
		return (string) (bool) is_multisite();
	}

	/**
	 * Implemented since there is no core is multi network function
	 * Right now there is no way to tell if we which network is the dominant network on the system
	 *
	 * @since  3.3
	 * @return boolean
	 */
	public static function is_multi_network() {
		global  $wpdb;

		// if we don't have a multi site setup no need to do any more.
		if ( ! is_multisite() ) {
			return false;
		}

		$num_sites = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->site}" );
		if ( $num_sites > 1 ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Get back if the current site is single user site.
	 *
	 * @return bool
	 */
	public static function is_single_user_site() {
		global $wpdb;

		$some_users = get_transient( 'jetpack_is_single_user' );
		if ( false === $some_users ) {
			$some_users = $wpdb->get_var( "SELECT COUNT(*) FROM (SELECT user_id FROM $wpdb->usermeta WHERE meta_key = '{$wpdb->prefix}capabilities' LIMIT 2) AS someusers" );
			set_transient( 'jetpack_is_single_user', (int) $some_users, 12 * HOUR_IN_SECONDS );
		}
		return 1 === (int) $some_users;
	}

	/**
	 * Returns true if the site has file write access false otherwise.
	 *
	 * @return string ( '1' | '0' )
	 **/
	public static function file_system_write_access() {
		if ( ! function_exists( 'get_filesystem_method' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		require_once ABSPATH . 'wp-admin/includes/template.php';

		$filesystem_method = get_filesystem_method();
		if ( 'direct' === $filesystem_method ) {
			return 1;
		}

		ob_start();
		$filesystem_credentials_are_stored = request_filesystem_credentials( self_admin_url() );
		ob_end_clean();
		if ( $filesystem_credentials_are_stored ) {
			return 1;
		}
		return 0;
	}

	// phpcs:disable WordPress.WP.CapitalPDangit.MisspelledInComment
	/**
	 * Gets updates and stores in jetpack_updates.
	 *
	 * The jetpack_updates option is saved in the following schema:
	 *
	 * array (
	 *      'plugins'                       => (int) Number of plugin updates available.
	 *      'themes'                        => (int) Number of theme updates available.
	 *      'wordpress'                     => (int) Number of WordPress core updates available.
	 *      'translations'                  => (int) Number of translation updates available.
	 *      'total'                         => (int) Total of all available updates.
	 *      'wp_update_version'             => (string) The latest available version of WordPress, only present if a WordPress update is needed.
	 * )
	 *
	 * @return array
	 */
	public static function get_updates() {
		$updates     = array();
		$update_data = wp_get_update_data();

		// Stores the individual update counts as well as the total count.
		if ( isset( $update_data['counts'] ) ) {
			$updates = $update_data['counts'];
		}

		// If we need to update WordPress core, let's find the latest version number.
		if ( ! empty( $updates['wordpress'] ) ) {
			$cur = get_preferred_from_update_core();
			if ( isset( $cur->response ) && 'upgrade' === $cur->response ) {
				$updates['wp_update_version'] = $cur->current;
			}
		}
		return $updates;
	}
	// phpcs:enable WordPress.WP.CapitalPDangit.MisspelledInComment

	/**
	 * Get update details for core, plugins, and themes.
	 *
	 * @return array
	 */
	public static function get_update_details() {
		$update_details = array(
			'update_core'    => get_site_transient( 'update_core' ),
			'update_plugins' => get_site_transient( 'update_plugins' ),
			'update_themes'  => get_site_transient( 'update_themes' ),
		);
		return $update_details;
	}

	/**
	 * Is Jetpack active?
	 * The method only checks if there's an existing token for the master user. It doesn't validate the token.
	 *
	 * This method is deprecated since 9.6.0. Please use one of the methods provided by the Manager class in the Connection package,
	 * or Jetpack::is_connection_ready if you want to know when the Jetpack plugin starts considering the connection ready to be used.
	 *
	 * Since this method has a wide spread use, we decided not to throw any deprecation warnings for now.
	 *
	 * @deprecated 9.6.0
	 *
	 * @return bool
	 */
	public static function is_active() {
		return self::connection()->has_connected_owner();
	}

	/**
	 * Returns true if the current site is connected to WordPress.com and has the minimum requirements to enable Jetpack UI
	 *
	 * This method was introduced just before the release of the possibility to use Jetpack without a user connection, while
	 * it was available only when no_user_testing_mode was enabled. In the near future, this will return is_connected for all
	 * users and this option will be available by default for everybody.
	 *
	 * @since 9.6.0
	 * @since 9.7.0 returns is_connected in all cases and adds filter to the returned value
	 *
	 * @return bool is the site connection ready to be used?
	 */
	public static function is_connection_ready() {
		/**
		 * Allows filtering whether the connection is ready to be used. If true, this will enable the Jetpack UI and modules
		 *
		 * Modules will be enabled depending on the connection status and if the module requires a connection or user connection.
		 *
		 * @since 9.7.0
		 *
		 * @param bool                                  $is_connection_ready Is the connection ready?
		 * @param Automattic\Jetpack\Connection\Manager $connection_manager Instance of the Manager class, can be used to check the connection status.
		 */
		return apply_filters( 'jetpack_is_connection_ready', self::connection()->is_connected(), self::connection() );
	}

	/**
	 * Determines reason for Jetpack offline mode.
	 */
	public static function development_mode_trigger_text() {
		$status = new Status();

		if ( ! $status->is_offline_mode() ) {
			return __( 'Jetpack is not in Offline Mode.', 'jetpack' );
		}

		if ( defined( 'JETPACK_DEV_DEBUG' ) && JETPACK_DEV_DEBUG ) {
			$notice = __( 'The JETPACK_DEV_DEBUG constant is defined in wp-config.php or elsewhere.', 'jetpack' );
		} elseif ( defined( 'WP_LOCAL_DEV' ) && WP_LOCAL_DEV ) {
			$notice = __( 'The WP_LOCAL_DEV constant is defined in wp-config.php or elsewhere.', 'jetpack' );
		} elseif ( $status->is_local_site() ) {
			$notice = __( 'The site URL is a known local development environment URL (e.g. http://localhost).', 'jetpack' );
		} elseif ( get_option( 'jetpack_offline_mode' ) ) {
			$notice = __( 'The jetpack_offline_mode option is set to true.', 'jetpack' );
		} else {
			$notice = __( 'The jetpack_offline_mode filter is set to true.', 'jetpack' );
		}

		return $notice;
	}
	/**
	 * Get Jetpack offline mode notice text and notice class.
	 *
	 * Mirrors the checks made in Automattic\Jetpack\Status->is_offline_mode
	 */
	public static function show_development_mode_notice() {
		if ( ( new Status() )->is_offline_mode() ) {
			$notice = sprintf(
				/* translators: %s is a URL */
				__( 'In <a href="%s" target="_blank">Offline Mode</a>:', 'jetpack' ),
				esc_url( Redirect::get_url( 'jetpack-support-development-mode' ) )
			);

			$notice .= ' ' . self::development_mode_trigger_text();

			echo '<div class="updated" style="border-color: #f0821e;"><p>' . $notice . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- All provided text.
		}

		// Throw up a notice if using a development version and as for feedback.
		if ( self::is_development_version() ) {
			/* translators: %s is a URL */
			$notice = sprintf( __( 'You are currently running a development version of Jetpack. <a href="%s" target="_blank">Submit your feedback</a>', 'jetpack' ), esc_url( Redirect::get_url( 'jetpack-contact-support-beta-group' ) ) );

			echo '<div class="updated" style="border-color: #f0821e;"><p>' . $notice . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- All provided text.
		}
	}

	/**
	 * Whether Jetpack's version maps to a public release, or a development version.
	 */
	public static function is_development_version() {
		/**
		 * Allows filtering whether this is a development version of Jetpack.
		 *
		 * This filter is especially useful for tests.
		 *
		 * @since 4.3.0
		 *
		 * @param bool $development_version Is this a develoment version of Jetpack?
		 */
		return (bool) apply_filters(
			'jetpack_development_version',
			! preg_match( '/^\d+(\.\d+)+$/', Constants::get_constant( 'JETPACK__VERSION' ) )
		);
	}

	/**
	 * Get the wpcom email of the current|specified connected user.
	 *
	 * @param null|int $user_id User ID or will use get_current_user_id if null.
	 */
	public static function get_connected_user_email( $user_id = null ) {
		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$xml = new Jetpack_IXR_Client(
			array(
				'user_id' => $user_id,
			)
		);
		$xml->query( 'wpcom.getUserEmail' );
		if ( ! $xml->isError() ) {
			return $xml->getResponse();
		}
		return false;
	}

	/**
	 * Get the wpcom email of the master user.
	 */
	public static function get_master_user_email() {
		$master_user_id = Jetpack_Options::get_option( 'master_user' );
		if ( $master_user_id ) {
			return self::get_connected_user_email( $master_user_id );
		}
		return '';
	}

	/**
	 * Gets current user IP address.
	 *
	 * @param  bool $check_all_headers Check all headers? Default is `false`.
	 *
	 * @deprecated Jetpack 10.6
	 *
	 * @return string                  Current user IP address.
	 */
	public static function current_user_ip( $check_all_headers = false ) {
		_deprecated_function( __METHOD__, 'jetpack-10.6', 'Automattic\\Jetpack\\Status\\Visitor::get_ip' );

		return ( new Visitor() )->get_ip( $check_all_headers );
	}

	/**
	 * Loads the currently active modules.
	 */
	public static function load_modules() {
		$status = new Status();

		if (
			! self::is_connection_ready()
			&& ! $status->is_offline_mode()
			&& (
				! is_multisite()
				|| ! get_site_option( 'jetpack_protect_active' )
			)
		) {
			return;
		}

		$version = Jetpack_Options::get_option( 'version' );
		if ( ! $version ) {
			$version     = JETPACK__VERSION . ':' . time();
			$old_version = $version;
			/** This action is documented in class.jetpack.php */
			do_action( 'updating_jetpack_version', $version, false );
			Jetpack_Options::update_options( compact( 'version', 'old_version' ) );
		}
		list( $version ) = explode( ':', $version );

		$modules = array_filter( self::get_active_modules(), array( 'Jetpack', 'is_module' ) );

		$modules_data = array();

		// Don't load modules that have had "Major" changes since the stored version until they have been deactivated/reactivated through the lint check.
		if ( version_compare( $version, JETPACK__VERSION, '<' ) ) {
			$updated_modules = array();
			foreach ( $modules as $module ) {
				$modules_data[ $module ] = self::get_module( $module );
				if ( ! isset( $modules_data[ $module ]['changed'] ) ) {
					continue;
				}

				if ( version_compare( $modules_data[ $module ]['changed'], $version, '<=' ) ) {
					continue;
				}

				$updated_modules[] = $module;
			}

			$modules = array_diff( $modules, $updated_modules );
		}

		$is_site_connection = false;

		if ( method_exists( self::connection(), 'is_site_connection' ) ) {
			$is_site_connection = self::connection()->is_site_connection();
		}

		foreach ( $modules as $index => $module ) {
			// If we're in offline/site-connection mode, disable modules requiring a connection/user connection.
			if ( $status->is_offline_mode() || $is_site_connection ) {
				// Prime the pump if we need to.
				if ( empty( $modules_data[ $module ] ) ) {
					$modules_data[ $module ] = self::get_module( $module );
				}
				// If the module requires a connection, but we're in local mode, don't include it.
				if ( $status->is_offline_mode() && $modules_data[ $module ]['requires_connection'] ) {
					continue;
				}

				if ( $is_site_connection && $modules_data[ $module ]['requires_user_connection'] ) {
					continue;
				}
			}

			if ( did_action( 'jetpack_module_loaded_' . $module ) ) {
				continue;
			}

			if ( ! include_once self::get_module_path( $module ) ) { // phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.NotAbsolutePath
				unset( $modules[ $index ] );
				self::update_active_modules( array_values( $modules ) );
				continue;
			}

			/**
			 * Fires when a specific module is loaded.
			 * The dynamic part of the hook, $module, is the module slug.
			 *
			 * @since 1.1.0
			 */
			do_action( 'jetpack_module_loaded_' . $module );
		}

		/**
		 * Fires when all the modules are loaded.
		 *
		 * @since 1.1.0
		 */
		do_action( 'jetpack_modules_loaded' );

		// Load module-specific code that is needed even when a module isn't active. Loaded here because code contained therein may need actions such as setup_theme.
		require_once JETPACK__PLUGIN_DIR . 'modules/module-extras.php';
	}

	/**
	 * Check if Jetpack's REST API compat file should be included
	 *
	 * @action plugins_loaded
	 * @return void
	 */
	public function check_rest_api_compat() {
		/**
		 * Filters the list of REST API compat files to be included.
		 *
		 * @since 2.2.5
		 *
		 * @param array $args Array of REST API compat files to include.
		 */
		$_jetpack_rest_api_compat_includes = apply_filters( 'jetpack_rest_api_compat', array() );

		foreach ( $_jetpack_rest_api_compat_includes as $_jetpack_rest_api_compat_include ) {
			require_once $_jetpack_rest_api_compat_include;
		}
	}

	/**
	 * Gets all plugins currently active in values, regardless of whether they're
	 * traditionally activated or network activated.
	 *
	 * @todo Store the result in core's object cache maybe?
	 */
	public static function get_active_plugins() {
		// Older Connection copies can load first and lack this method.
		if ( ! method_exists( Heartbeat::class, 'get_active_plugins' ) ) {
			return array();
		}

		return Heartbeat::get_active_plugins();
	}

	/**
	 * Gets and parses additional plugin data to send with the heartbeat data
	 *
	 * @since 3.8.1
	 *
	 * @return array Array of plugin data
	 */
	public static function get_parsed_plugin_data() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		/** This filter is documented in wp-admin/includes/class-wp-plugins-list-table.php */
		$all_plugins    = apply_filters( 'all_plugins', get_plugins() );
		$active_plugins = self::get_active_plugins();

		$plugins = array();
		foreach ( $all_plugins as $path => $plugin_data ) {
			$plugins[ $path ] = array(
				'is_active' => in_array( $path, $active_plugins, true ),
				'file'      => $path,
				'name'      => $plugin_data['Name'],
				'version'   => $plugin_data['Version'],
				'author'    => $plugin_data['Author'],
			);
		}

		return $plugins;
	}

	/**
	 * Gets and parses theme data to send with the heartbeat data
	 *
	 * @since 3.8.1
	 *
	 * @return array Array of theme data
	 */
	public static function get_parsed_theme_data() {
		$all_themes  = wp_get_themes( array( 'allowed' => true ) );
		$header_keys = array( 'Name', 'Author', 'Version', 'ThemeURI', 'AuthorURI', 'Status', 'Tags' );

		$themes = array();
		foreach ( $all_themes as $slug => $theme_data ) {
			$theme_headers = array();
			foreach ( $header_keys as $header_key ) {
				$theme_headers[ $header_key ] = $theme_data->get( $header_key );
			}

			$themes[ $slug ] = array(
				'is_active_theme' => wp_get_theme()->get_template() === $slug,
				'slug'            => $slug,
				'theme_root'      => $theme_data->get_theme_root_uri(),
				'parent'          => $theme_data->parent(),
				'headers'         => $theme_headers,
			);
		}

		return $themes;
	}

	/**
	 * Checks whether a specific plugin is active.
	 *
	 * We don't want to store these in a static variable, in case
	 * there are switch_to_blog() calls involved.
	 *
	 * @param string $plugin Plugin to check in 'folder/file.php` format.
	 */
	public static function is_plugin_active( $plugin = 'jetpack/jetpack.php' ) {
		return in_array( $plugin, self::get_active_plugins(), true );
	}

	/**
	 * Check if Jetpack's Open Graph tags should be used.
	 * If certain plugins are active, Jetpack's og tags are suppressed.
	 *
	 * @uses Jetpack::get_active_modules, add_filter, get_option, apply_filters
	 * @action plugins_loaded
	 * @return void
	 */
	public function check_open_graph() {
		if ( in_array( 'publicize', self::get_active_modules(), true ) || in_array( 'sharedaddy', self::get_active_modules(), true ) ) {
			include_once JETPACK__PLUGIN_DIR . 'enhanced-open-graph.php';
			add_filter( 'jetpack_enable_open_graph', '__return_true', 0 );
		}

		$active_plugins = self::get_active_plugins();

		if ( ! empty( $active_plugins ) ) {
			foreach ( $this->open_graph_conflicting_plugins as $plugin ) {
				if ( in_array( $plugin, $active_plugins, true ) ) {
					add_filter( 'jetpack_enable_open_graph', '__return_false', 99 );
					break;
				}
			}
		}

		/**
		 * Allow the addition of Open Graph Meta Tags to all pages.
		 *
		 * @since 2.0.3
		 *
		 * @param bool false Should Open Graph Meta tags be added. Default to false.
		 */
		if ( apply_filters( 'jetpack_enable_open_graph', false ) ) {
			require_once JETPACK__PLUGIN_DIR . 'functions.opengraph.php';
		}
	}

	/**
	 * Check if Jetpack's Twitter tags should be used.
	 * If certain plugins are active, Jetpack's twitter tags are suppressed.
	 *
	 * @uses Jetpack::get_active_modules, add_filter, get_option, apply_filters
	 * @action plugins_loaded
	 * @return void
	 */
	public function check_twitter_tags() {

		$active_plugins = self::get_active_plugins();

		if ( ! empty( $active_plugins ) ) {
			foreach ( $this->twitter_cards_conflicting_plugins as $plugin ) {
				if ( in_array( $plugin, $active_plugins, true ) ) {
					add_filter( 'jetpack_disable_twitter_cards', '__return_true', 99 );
					break;
				}
			}
		}

		/**
		 * Allow Twitter Card Meta tags to be disabled.
		 *
		 * @since 2.6.0
		 *
		 * @param bool true Should Twitter Card Meta tags be disabled. Default to true.
		 */
		if ( ! apply_filters( 'jetpack_disable_twitter_cards', false ) ) {
			// @todo Remove this require once the deprecated Jetpack_Twitter_Cards wrapper has been removed.
			// Twitter Cards functionality now lives in the jetpack-post-media package (Automattic\Jetpack\Post_Media\Twitter_Cards).
			require_once JETPACK__PLUGIN_DIR . 'class.jetpack-twitter-cards.php';
		}
	}

	/* Jetpack Options API */

	/**
	 * Gets the option names from Jetpack_Options.
	 *
	 * @param string $type Jetpack option type.
	 *
	 * @return array
	 */
	public static function get_option_names( $type = 'compact' ) {
		return Jetpack_Options::get_option_names( $type );
	}

	/**
	 * Returns the requested option.
	 *
	 * Looks in jetpack_options or jetpack_$name as appropriate.
	 *
	 * @param string $name    Option name.
	 * @param mixed  $default Default value.
	 */
	public static function get_option( $name, $default = false ) {
		return Jetpack_Options::get_option( $name, $default );
	}

	/**
	 * Returns an array of all PHP files in the specified absolute path.
	 * Equivalent to glob( "$absolute_path/*.php" ).
	 *
	 * @param string $absolute_path The absolute path of the directory to search.
	 * @return array Array of absolute paths to the PHP files.
	 */
	public static function glob_php( $absolute_path ) {
		return ( new Files() )->glob_php( $absolute_path );
	}

	/**
	 * Activate new modules.
	 *
	 * @param bool $redirect Should this function redirect after activation.
	 *
	 * @return void
	 */
	public static function activate_new_modules( $redirect = false ) {
		if ( ! self::is_connection_ready() && ! ( new Status() )->is_offline_mode() ) {
			return;
		}

		$jetpack_old_version = Jetpack_Options::get_option( 'version' );
		if ( ! $jetpack_old_version ) {
			$old_version         = '1.1:' . time();
			$version             = $old_version;
			$jetpack_old_version = $version;
			/** This action is documented in class.jetpack.php */
			do_action( 'updating_jetpack_version', $version, false );
			Jetpack_Options::update_options( compact( 'version', 'old_version' ) );
		}

		list( $jetpack_version ) = explode( ':', $jetpack_old_version );

		if ( version_compare( JETPACK__VERSION, $jetpack_version, '<=' ) ) {
			return;
		}

		$active_modules     = self::get_active_modules();
		$reactivate_modules = array();
		foreach ( $active_modules as $active_module ) {
			$module = self::get_module( $active_module );
			if ( ! isset( $module['changed'] ) ) {
				continue;
			}

			if ( version_compare( $module['changed'], $jetpack_version, '<=' ) ) {
				continue;
			}

			$reactivate_modules[] = $active_module;
			self::deactivate_module( $active_module );
		}

		$new_version = JETPACK__VERSION . ':' . time();
		/** This action is documented in class.jetpack.php */
		do_action( 'updating_jetpack_version', $new_version, $jetpack_old_version );
		Jetpack_Options::update_options(
			array(
				'version'     => $new_version,
				'old_version' => $jetpack_old_version,
			)
		);

		self::state( 'message', 'modules_activated' );

		self::activate_default_modules( $jetpack_version, JETPACK__VERSION, $reactivate_modules, $redirect );

		if ( $redirect ) {
			$page = 'jetpack'; // make sure we redirect to either settings or the jetpack page.
			if ( isset( $_GET['page'] ) && in_array( $_GET['page'], array( 'jetpack', 'jetpack_modules' ), true ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- we're not changing the site.
				$page = sanitize_text_field( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- we're not changing the site.
			}
			wp_safe_redirect( self::admin_url( 'page=' . rawurlencode( $page ) ) );
			exit( 0 );
		}
	}

	/**
	 * List available Jetpack modules. Simply lists .php files in /modules/.
	 * Make sure to tuck away module "library" files in a sub-directory.
	 *
	 * @param bool|string $min_version Only return modules introduced in this version or later. Default is false, do not filter.
	 * @param bool|string $max_version Only return modules introduced before this version. Default is false, do not filter.
	 * @param bool|null   $requires_connection Pass a boolean value to only return modules that require (or do not require) a connection.
	 * @param bool|null   $requires_user_connection Pass a boolean value to only return modules that require (or do not require) a user connection.
	 *
	 * @return array $modules Array of module slugs
	 */
	public static function get_available_modules( $min_version = false, $max_version = false, $requires_connection = null, $requires_user_connection = null ) {
		return ( new Modules() )->get_available( $min_version, $max_version, $requires_connection, $requires_user_connection );
	}

	/**
	 * Get default modules loaded on activation.
	 *
	 * @param bool|string $min_version Only return modules introduced in this version or later. Default is false, do not filter.
	 * @param bool|string $max_version Only return modules introduced before this version. Default is false, do not filter.
	 * @param bool|null   $requires_connection Pass a boolean value to only return modules that require (or do not require) a connection.
	 * @param bool|null   $requires_user_connection Pass a boolean value to only return modules that require (or do not require) a user connection.
	 *
	 * @return array $modules Array of module slugs
	 */
	public static function get_default_modules( $min_version = false, $max_version = false, $requires_connection = null, $requires_user_connection = null ) {
		$return = array();

		foreach ( self::get_available_modules( $min_version, $max_version, $requires_connection, $requires_user_connection ) as $module ) {
			$module_data = self::get_module( $module );

			switch ( strtolower( $module_data['auto_activate'] ) ) {
				case 'yes':
					$return[] = $module;
					break;
				case 'public':
					if ( Jetpack_Options::get_option( 'public' ) ) {
						$return[] = $module;
					}
					break;
				case 'no':
				default:
					break;
			}
		}
		if ( method_exists( Feature_Policy::class, 'ensure_hooks' ) ) {
			Feature_Policy::ensure_hooks();
		}

		/**
		 * Filters the array of default modules.
		 *
		 * @since 2.5.0
		 *
		 * @param array $return Array of default modules.
		 * @param string $min_version Minimum version number required to use modules.
		 * @param string $max_version Maximum version number required to use modules.
		 * @param bool|null $requires_connection Value of the Requires Connection filter.
		 * @param bool|null $requires_user_connection Value of the Requires User Connection filter.
		 */
		return apply_filters( 'jetpack_get_default_modules', $return, $min_version, $max_version, $requires_connection, $requires_user_connection );
	}

	/**
	 * Checks activated modules during auto-activation to determine
	 * if any of those modules are being deprecated.  If so, close
	 * them out, and add any replacement modules.
	 *
	 * Runs at priority 99 by default.
	 *
	 * This is run late, so that it can still activate a module if
	 * the new module is a replacement for another that the user
	 * currently has active, even if something at the normal priority
	 * would kibosh everything.
	 *
	 * @since 2.6
	 * @uses jetpack_get_default_modules filter
	 * @param array $modules Array of Jetpack modules.
	 * @return array
	 */
	public function handle_deprecated_modules( $modules ) {
		$deprecated_modules = array(
			'debug'                 => null,  // Closed out and moved to the debugger library.
			'wpcc'                  => 'sso', // Closed out in 2.6 -- SSO provides the same functionality.
			'gplus-authorship'      => null,  // Closed out in 3.2 -- Google dropped support.
			'minileven'             => null,  // Closed out in 8.3 -- Responsive themes are common now, and so is AMP.
			'lazy-images'           => null, // Closed out in 12.8 -- WordPress core now has native lazy loading.
			'enhanced-distribution' => null, // Closed out in 13.3 -- WP.com is winding down the firehose.
		);

		// Don't activate SSO if they never completed activating WPCC.
		if ( self::is_module_active( 'wpcc' ) ) {
			$wpcc_options = Jetpack_Options::get_option( 'wpcc_options' );
			if ( empty( $wpcc_options ) || empty( $wpcc_options['client_id'] ) || empty( $wpcc_options['client_id'] ) ) {
				$deprecated_modules['wpcc'] = null;
			}
		}

		foreach ( $deprecated_modules as $module => $replacement ) {
			if ( self::is_module_active( $module ) ) {
				self::deactivate_module( $module );
				if ( $replacement ) {
					$modules[] = $replacement;
				}
			}
		}

		return array_unique( $modules );
	}

	/**
	 * Checks activated plugins during auto-activation to determine
	 * if any of those plugins are in the list with a corresponding module
	 * that is not compatible with the plugin. The module will not be allowed
	 * to auto-activate.
	 *
	 * @since 2.6
	 * @uses jetpack_get_default_modules filter
	 * @param array $modules Array of Jetpack modules.
	 * @return array
	 */
	public function filter_default_modules( $modules ) {

		$active_plugins = self::get_active_plugins();

		if ( ! empty( $active_plugins ) ) {

			// For each module we'd like to auto-activate...
			foreach ( $modules as $key => $module ) {
				// If there are potential conflicts for it...
				if ( ! empty( $this->conflicting_plugins[ $module ] ) ) {
					// For each potential conflict...
					foreach ( $this->conflicting_plugins[ $module ] as $plugin ) {
						// If that conflicting plugin is active...
						if ( in_array( $plugin, $active_plugins, true ) ) {
							// Remove that item from being auto-activated.
							unset( $modules[ $key ] );
						}
					}
				}
			}
		}

		// Special case to convert block setting to a block module.
		$block_key = array_search( 'blocks', $modules, true );
		if ( $block_key !== false ) { // Only care if 'blocks' made it through the previous filters.
			$block_option = get_option( 'jetpack_blocks_disabled', null );
			if ( $block_option ) {
				unset( $modules[ $block_key ] );
			}
		}

		return $modules;
	}

	/**
	 * Extract a module's slug from its full path.
	 *
	 * @param string $file Full path to a file.
	 *
	 * @return string Module slug.
	 */
	public static function get_module_slug( $file ) {
		return ( new Modules() )->get_slug( $file );
	}

	/**
	 * Generate a module's path from its slug.
	 *
	 * @param string $slug Module slug.
	 */
	public static function get_module_path( $slug ) {
		return ( new Modules() )->get_path( $slug );
	}

	/**
	 * Load module data from module file. Headers differ from WordPress
	 * plugin headers to avoid them being identified as standalone
	 * plugins on the WordPress plugins page.
	 *
	 * @param string $module The module slug.
	 */
	public static function get_module( $module ) {
		return ( new Modules() )->get( $module );
	}

	/**
	 * Like core's get_file_data implementation, but caches the result.
	 *
	 * @param string $file Absolute path to the file.
	 * @param array  $headers List of headers, in the format array( 'HeaderKey' => 'Header Name' ).
	 */
	public static function get_file_data( $file, $headers ) {
		return ( new Modules() )->get_file_data( $file, $headers );
	}

	/**
	 * Return translated module tag.
	 *
	 * @param string $tag Tag as it appears in each module heading.
	 *
	 * @return mixed
	 */
	public static function translate_module_tag( $tag ) {
		return jetpack_get_module_i18n_tag( $tag );
	}

	/**
	 * Return module name translation. Uses matching string created in modules/module-headings.php.
	 *
	 * The module list is globbed from `modules/` at runtime, so a module can be listed with no
	 * entry in that generated file. Fall back to the untranslated header rather than overwriting
	 * it with the null `jetpack_get_module_i18n()` returns for an unknown slug.
	 *
	 * @since 3.9.2
	 *
	 * @param array $modules Array of Jetpack modules.
	 *
	 * @return array
	 */
	public static function get_translated_modules( $modules ) {
		foreach ( $modules as $index => $module ) {
			$i18n_module = jetpack_get_module_i18n( $module['module'] );
			$name        = $i18n_module['name'] ?? null;
			$description = $i18n_module['description'] ?? null;

			if ( null !== $name && isset( $module['name'] ) ) {
				$modules[ $index ]['name'] = $name;
			}
			if ( null !== $description && isset( $module['description'] ) ) {
				$modules[ $index ]['description']       = $description;
				$modules[ $index ]['short_description'] = $description;
			}
			if ( isset( $module['module_tags'] ) ) {
				$modules[ $index ]['module_tags'] = array_map( 'jetpack_get_module_i18n_tag', $module['module_tags'] );
			}
		}
		return $modules;
	}

	/**
	 * Get a list of activated modules as an array of module slugs.
	 */
	public static function get_active_modules() {
		return ( new Modules() )->get_active();
	}

	/**
	 * Check whether or not a Jetpack module is active.
	 *
	 * @param string $module The slug of a Jetpack module.
	 * @return bool
	 *
	 * @static
	 */
	public static function is_module_active( $module ) {
		return ( new Modules() )->is_active( $module );
	}

	/**
	 * Is slug a valid module.
	 *
	 * @param string $module Module slug.
	 *
	 * @return bool
	 */
	public static function is_module( $module ) {
		return ( new Modules() )->is_module( $module );
	}

	/**
	 * Catches PHP errors.  Must be used in conjunction with output buffering.
	 *
	 * @deprecated since 13.5
	 * @param bool $catch True to start catching, False to stop.
	 *
	 * @static
	 * @deprecated 13.5
	 * @see \Automattic\Jetpack\Errors
	 */
	public static function catch_errors( $catch ) {
		_deprecated_function( __METHOD__, '13.5' );
		// @phan-suppress-next-line PhanDeprecatedClass
		return ( new Errors() )->catch_errors( $catch );
	}

	/**
	 * Saves any generated PHP errors in ::state( 'php_errors', {errors} )
	 *
	 * @deprecated since 13.5
	 */
	public static function catch_errors_on_shutdown() {
		_deprecated_function( __METHOD__, '13.5' );
		self::state( 'php_errors', self::alias_directories( ob_get_clean() ) );
	}

	/**
	 * Rewrite any string to make paths easier to read.
	 *
	 * Rewrites ABSPATH (eg `/home/jetpack/wordpress/`) to ABSPATH, and if WP_CONTENT_DIR
	 * is located outside of ABSPATH, rewrites that to WP_CONTENT_DIR.
	 *
	 * @param string $string String to attempt rewrite.
	 * @return mixed
	 */
	public static function alias_directories( $string ) {
		// ABSPATH has a trailing slash.
		$string = str_replace( ABSPATH, 'ABSPATH/', $string );
		// WP_CONTENT_DIR does not have a trailing slash.
		$string = str_replace( WP_CONTENT_DIR, 'WP_CONTENT_DIR', $string );

		return $string;
	}

	/**
	 * Activates default Jetpack modules.
	 *
	 * @param null|string $min_version Only return modules introduced in this version or later. Default is false, do not filter.
	 * @param null|string $max_version Only return modules introduced before this version. Default is false, do not filter.
	 * @param array       $other_modules Other modules to activate.
	 * @param null|bool   $redirect Should there be a redirection after activation.
	 * @param bool        $send_state_messages If a state message should be sent.
	 * @param bool|null   $requires_connection Pass a boolean value to only return modules that require (or do not require) a connection.
	 * @param bool|null   $requires_user_connection Pass a boolean value to only return modules that require (or do not require) a user connection.
	 *
	 * @return void
	 */
	public static function activate_default_modules(
		$min_version = false,
		$max_version = false,
		$other_modules = array(),
		$redirect = null,
		$send_state_messages = null,
		$requires_connection = null,
		$requires_user_connection = null
	) {
		$jetpack = self::init();

		if ( $redirect === null ) {
			if (
				( defined( 'REST_REQUEST' ) && REST_REQUEST )
			||
				( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST )
			||
				( defined( 'WP_CLI' ) && WP_CLI )
			||
				( defined( 'DOING_CRON' ) && DOING_CRON )
			||
				( defined( 'DOING_AJAX' ) && DOING_AJAX )
			) {
				$redirect = false;
			} elseif ( is_admin() ) {
				$redirect = true;
			} else {
				$redirect = false;
			}
		}

		if ( $send_state_messages === null ) {
			$send_state_messages = current_user_can( 'jetpack_activate_modules' );
		}

		$modules = self::get_default_modules( $min_version, $max_version, $requires_connection, $requires_user_connection );
		$modules = array_merge( $other_modules, $modules );

		// Look for standalone plugins and disable if active.

		$to_deactivate = array();
		foreach ( $modules as $module ) {
			if ( isset( $jetpack->plugins_to_deactivate[ $module ] ) ) {
				$to_deactivate[ $module ] = $jetpack->plugins_to_deactivate[ $module ];
			}
		}

		$deactivated = array();
		foreach ( $to_deactivate as $module => $deactivate_us ) {
			foreach ( $deactivate_us as $i => $deactivate_me ) {
				list( $probable_file, $probable_title ) = $deactivate_me;
				if ( Jetpack_Client_Server::deactivate_plugin( $probable_file, $probable_title ) ) {
					$deactivated[] = "$module:$i";
				}
			}
		}

		if ( $deactivated ) {
			if ( $send_state_messages ) {
				self::state( 'deactivated_plugins', implode( ',', $deactivated ) );
			}

			if ( $redirect ) {
				$url = add_query_arg(
					array(
						'action'   => 'activate_default_modules',
						'_wpnonce' => wp_create_nonce( 'activate_default_modules' ),
					),
					add_query_arg( compact( 'min_version', 'max_version', 'other_modules' ), self::admin_url( 'page=jetpack' ) )
				);
				wp_safe_redirect( $url );
				exit( 0 );
			}
		}

		/**
		 * Fires before default modules are activated.
		 *
		 * @since 1.9.0
		 *
		 * @param string    $min_version Minimum version number required to use modules.
		 * @param string    $max_version Maximum version number required to use modules.
		 * @param array     $other_modules Array of other modules to activate alongside the default modules.
		 * @param bool|null $requires_connection Value of the Requires Connection filter.
		 * @param bool|null $requires_user_connection Value of the Requires User Connection filter.
		 */
		do_action( 'jetpack_before_activate_default_modules', $min_version, $max_version, $other_modules, $requires_connection, $requires_user_connection );

		// Check each module for fatal errors, a la wp-admin/plugins.php::activate before activating.
		if ( $send_state_messages ) {
			self::restate();
		}

		$active = self::get_active_modules();

		foreach ( $modules as $module ) {
			if ( did_action( "jetpack_module_loaded_$module" ) ) {
				$active[] = $module;
				self::update_active_modules( $active );
				continue;
			}

			if ( $send_state_messages && in_array( $module, $active, true ) ) {
				$module_info = self::get_module( $module );
				if ( ! $module_info['deactivate'] ) {
					$state        = in_array( $module, $other_modules, true ) ? 'reactivated_modules' : 'activated_modules';
					$active_state = self::state( $state );
					if ( $active_state ) {
						$active_state = explode( ',', $active_state );
					} else {
						$active_state = array();
					}
					$active_state[] = $module;
					self::state( $state, implode( ',', $active_state ) );
				}
				continue;
			}

			$file = self::get_module_path( $module );
			if ( ! file_exists( $file ) ) {
				continue;
			}

			// we'll override this later if the plugin can be included without fatal error.
			if ( $redirect ) {
				wp_safe_redirect( self::admin_url( 'page=jetpack' ) );
			}

			if ( $send_state_messages ) {
				self::state( 'error', 'module_activation_failed' );
				self::state( 'module', $module );
			}

			ob_start();
			require_once $file;

			$active[] = $module;

			if ( $send_state_messages ) {

				$state        = in_array( $module, $other_modules, true ) ? 'reactivated_modules' : 'activated_modules';
				$active_state = self::state( $state );
				if ( $active_state ) {
					$active_state = explode( ',', $active_state );
				} else {
					$active_state = array();
				}
				$active_state[] = $module;
				self::state( $state, implode( ',', $active_state ) );
			}

			self::update_active_modules( $active );

			ob_end_clean();
		}

		if ( $send_state_messages ) {
			self::state( 'error', false );
			self::state( 'module', false );
		}
		/**
		 * Fires when default modules are activated.
		 *
		 * @since 1.9.0
		 *
		 * @param string    $min_version Minimum version number required to use modules.
		 * @param string    $max_version Maximum version number required to use modules.
		 * @param array     $other_modules Array of other modules to activate alongside the default modules.
		 * @param bool|null $requires_connection Value of the Requires Connection filter.
		 * @param bool|null $requires_user_connection Value of the Requires User Connection filter.
		 */
		do_action( 'jetpack_activate_default_modules', $min_version, $max_version, $other_modules, $requires_connection, $requires_user_connection );
	}

	/**
	 * Activate a module.
	 *
	 * @param string $module Module slug.
	 * @param bool   $exit Should exit be called after deactivation.
	 * @param bool   $redirect Should there be a redirection after activation.
	 *
	 * @return bool|void
	 */
	public static function activate_module( $module, $exit = true, $redirect = true ) {
		return ( new Modules() )->activate( $module, $exit, $redirect );
	}

	/**
	 * Deactivate module.
	 *
	 * @param string $module Module slug.
	 *
	 * @return bool
	 */
	public static function deactivate_module( $module ) {
		return ( new Modules() )->deactivate( $module );
	}

	/**
	 * Enable a configuable module.
	 *
	 * @param string $module Module slug.
	 *
	 * @return void
	 */
	public static function enable_module_configurable( $module ) {
		$module = self::get_module_slug( $module );
		add_filter( 'jetpack_module_configurable_' . $module, '__return_true' );
	}

	/**
	 * Composes a module configure URL. It uses Jetpack settings search as default value
	 * It is possible to redefine resulting URL by using "jetpack_module_configuration_url_$module" filter
	 *
	 * @param string $module Module slug.
	 * @return string $url module configuration URL.
	 */
	public static function module_configuration_url( $module ) {
		$module      = self::get_module_slug( $module );
		$default_url = self::admin_url( array( 'page' => 'jetpack-settings' ) ) . "#/settings?term=$module";
		/**
		 * Allows to modify configure_url of specific module to be able to redirect to some custom location.
		 *
		 * @since 6.9.0
		 *
		 * @param string $default_url Default url, which redirects to jetpack settings page.
		 */
		$url = apply_filters( 'jetpack_module_configuration_url_' . $module, $default_url );

		return $url;
	}

	/* Installation */
	/**
	 * Bail on activation if there is an issue.
	 *
	 * @param string $message Error message.
	 * @param bool   $deactivate Deactivate Jetpack or not.
	 *
	 * @return never
	 */
	public static function bail_on_activation( $message, $deactivate = true ) {
		?>
<!doctype html>
<html>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<style>
* {
	text-align: center;
	margin: 0;
	padding: 0;
	font-family: "Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;
}
p {
	margin-top: 1em;
	font-size: 18px;
}
</style>
<body>
<p><?php echo esc_html( $message ); ?></p>
</body>
</html>
		<?php
		if ( $deactivate ) {
			$plugins = get_option( 'active_plugins' );
			$jetpack = plugin_basename( JETPACK__PLUGIN_DIR . 'jetpack.php' );
			$update  = false;
			foreach ( $plugins as $i => $plugin ) {
				if ( $plugin === $jetpack ) {
					$plugins[ $i ] = false;
					$update        = true;
				}
			}

			if ( $update ) {
				update_option( 'active_plugins', array_filter( $plugins ) );
			}
		}
		exit( 0 );
	}

	/**
	 * Attached to activate_{ plugin_basename( __FILES__ ) } by register_activation_hook()
	 *
	 * @param bool $network_wide Network-wide activation.
	 */
	public static function plugin_activation( $network_wide ) {
		Jetpack_Options::update_option( 'activated', 1 );

		if ( version_compare( $GLOBALS['wp_version'], JETPACK__MINIMUM_WP_VERSION, '<' ) ) {
			/* translators: Jetpack version number. */
			self::bail_on_activation( sprintf( __( 'Jetpack requires WordPress version %s or later.', 'jetpack' ), JETPACK__MINIMUM_WP_VERSION ) );
		}

		if ( $network_wide ) {
			self::state( 'network_nag', true );
		}

		// For firing one-off events (notices) immediately after activation.
		set_transient( 'activated_jetpack', true, 0.1 * MINUTE_IN_SECONDS );

		update_option( 'jetpack_activation_source', self::get_activation_source( wp_get_referer() ) );

		Health::on_jetpack_activated();

		\Automattic\Jetpack\Reprint_Export\Reprint_Exporter::discard_credentials();

		if ( self::is_connection_ready() && method_exists( 'Automattic\Jetpack\Sync\Actions', 'do_only_first_initial_sync' ) ) {
			Sync_Actions::do_only_first_initial_sync();
		}

		if ( ! defined( 'WC_ANALYTICS' ) && class_exists( 'Automattic\Woocommerce_Analytics' ) ) {
			Woocommerce_Analytics::maybe_add_proxy_speed_module();
		}

		self::plugin_initialize();
	}

	/**
	 * Returns the activation source.
	 *
	 * @param string $referer_url URL.
	 *
	 * @return array source_type, source_query.
	 */
	public static function get_activation_source( $referer_url ) {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return array( 'wp-cli', null );
		}

		$referer = wp_parse_url( $referer_url );

		$source_type  = 'unknown';
		$source_query = null;

		if ( ! is_array( $referer ) || ! isset( $referer['path'] ) ) {
			return array( $source_type, $source_query );
		}

		$plugins_path         = wp_parse_url( admin_url( 'plugins.php' ), PHP_URL_PATH );
		$plugins_install_path = wp_parse_url( admin_url( 'plugin-install.php' ), PHP_URL_PATH );// /wp-admin/plugin-install.php

		if ( isset( $referer['query'] ) ) {
			parse_str( $referer['query'], $query_parts );
		} else {
			$query_parts = array();
		}

		if ( $plugins_path === $referer['path'] ) {
			$source_type = 'list';
		} elseif ( $plugins_install_path === $referer['path'] ) {
			$tab = $query_parts['tab'] ?? 'featured';
			switch ( $tab ) {
				case 'popular':
					$source_type = 'popular';
					break;
				case 'recommended':
					$source_type = 'recommended';
					break;
				case 'favorites':
					$source_type = 'favorites';
					break;
				case 'search':
					$source_type  = 'search-' . ( $query_parts['type'] ?? 'term' );
					$source_query = $query_parts['s'] ?? null;
					break;
				default:
					$source_type = 'featured';
			}
		}

		return array( $source_type, $source_query );
	}

	/**
	 * Runs before bumping version numbers up to a new version.
	 *
	 * Only ever registered the hooks for the release post update modal, which has been removed.
	 * No longer hooked to `updating_jetpack_version`.
	 *
	 * @deprecated 16.2
	 *
	 * @param string $version     Version:timestamp.
	 * @param string $old_version Old Version:timestamp or false if not set yet.
	 */
	public static function do_version_bump( $version, $old_version ) { // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- Signature preserved for the deprecation shim.
		_deprecated_function( __METHOD__, 'jetpack-16.2' );
	}

	/**
	 * Enables the Newsletter (subscriptions) module for existing sites now that it is a default-on module.
	 *
	 * Fresh installs receive the module via its "Auto Activate: Yes" header, so this only handles sites
	 * upgrading from a version where the module defaulted off. It runs once per site (guarded by the
	 * subscriptions_default_on_migrated option). Fresh installs are marked as migrated immediately so the
	 * migration never runs for them. After it has run, the user's choice to deactivate the module again
	 * (for example from the My Jetpack Products page) is respected and never reverted.
	 *
	 * The module requires a connection, so on a disconnected site the migration is deferred without setting
	 * the guard, allowing a later version bump to retry once the site is connected.
	 *
	 * @param string       $version     New Jetpack version:timestamp.
	 * @param string|false $old_version Previous Jetpack version:timestamp, or false on a fresh install.
	 */
	public static function activate_subscriptions_module_for_existing_sites( $version, $old_version ) {
		if ( get_option( 'jetpack_subscriptions_default_on_migrated' ) ) {
			return;
		}

		// Fresh installs get the module via its "Auto Activate: Yes" header. Mark them as migrated so a
		// later opt-out is never reverted by the existing-site path on a subsequent version bump.
		if ( ! $old_version ) {
			update_option( 'jetpack_subscriptions_default_on_migrated', true );
			return;
		}

		if ( ! self::is_connection_ready() ) {
			return;
		}

		// Mark as migrated only once the module is active, so a transient activation failure is retried on
		// a later version bump rather than being silently skipped.
		if ( self::is_module_active( 'subscriptions' ) || self::activate_module( 'subscriptions', false, false ) ) {
			update_option( 'jetpack_subscriptions_default_on_migrated', true );
		}
	}

	/**
	 * Option flag that records the AI master-switch opt-out reconciliation has run,
	 * so it never runs twice.
	 *
	 * @var string
	 */
	const AI_MASTER_OPTOUT_MIGRATED_OPTION = 'jetpack_ai_master_optout_migrated';

	/**
	 * Register the on-upgrade init hooks whose relative ORDER matters, extracted so
	 * the ordering can be asserted in tests without invoking plugin_upgrade() (whose
	 * guards make it unreliable to trigger under test). activate_new_modules()
	 * (init, default priority 10) auto-activates "Auto Activate: Yes" modules
	 * including the `ai` master; reconcile_ai_master_optout() must run at a LATER
	 * priority to honor an explicit AI opt-out.
	 *
	 * @return void
	 */
	public static function register_upgrade_init_hooks() {
		add_action( 'init', array( __CLASS__, 'activate_new_modules' ) );
		add_action( 'init', array( __CLASS__, 'reconcile_ai_master_optout' ), 20 );
	}

	/**
	 * Preserves an explicit Jetpack AI opt-out when the `ai` module becomes the site-wide
	 * master switch off WordPress.com Simple (self-hosted and Atomic).
	 *
	 * The `ai` module is "Auto Activate: Yes", so on upgrade {@see self::activate_new_modules()}
	 * turns it on for connected sites — the desired default-on / auto-enable-on-connection
	 * behavior, which this method deliberately leaves alone. The one case it corrects is a site
	 * that had explicitly disabled Jetpack AI (the `jetpack_ai_enabled` option present and falsey)
	 * before the module shipped: that opt-out must survive the module becoming the master, so the
	 * module is deactivated for exactly those sites. An absent or truthy option is left untouched.
	 *
	 * Ordering is the whole point. `activate_new_modules()` is hooked on `init` at priority 10 and
	 * auto-activates the module there; this method is hooked on `init` at priority 20 (see
	 * {@see self::plugin_upgrade()}), so it runs AFTER the auto-activation and its deactivation is
	 * the final state. A version-guarded block that ran inline during `plugins_loaded` would be
	 * undone by the later auto-activation, which is why this is a late-init hook rather than an
	 * inline upgrade step.
	 *
	 * WordPress.com Simple never runs modules — the option stays the master there — so this is a
	 * no-op on Simple. The {@see self::AI_MASTER_OPTOUT_MIGRATED_OPTION} flag makes it run exactly
	 * once, which matters because off-Simple the option is no longer the master after this runs:
	 * a stale falsey option must not keep re-deactivating a module the user later turns back on.
	 *
	 * @return void
	 */
	public static function reconcile_ai_master_optout() {
		if ( get_option( self::AI_MASTER_OPTOUT_MIGRATED_OPTION ) ) {
			return;
		}

		// Simple keeps the `jetpack_ai_enabled` option as the master; modules don't run there.
		if ( ( new Host() )->is_wpcom_simple() ) {
			return;
		}

		// A sentinel default distinguishes an absent option (leave auto-activation alone) from one
		// explicitly stored falsey (an opt-out to preserve).
		$stored = get_option( 'jetpack_ai_enabled', 'not-set' );
		if ( 'not-set' !== $stored && ! (bool) $stored ) {
			( new Modules() )->deactivate( 'ai' );
		}

		update_option( self::AI_MASTER_OPTOUT_MIGRATED_OPTION, true );
	}

	/**
	 * Deletes obsolete SEO module-state options without changing module activation.
	 *
	 * @since 16.3
	 */
	public static function cleanup_seo_module_state_options() {
		delete_option( 'jetpack_seo_sitemap_enabled' );
		delete_option( 'jetpack_seo_canonical_urls_enabled' );
		delete_option( 'jetpack_seo_module_state_reconciled' );
	}

	/**
	 * Seeds the Jetpack SEO discoverability cohort once, so the new SEO surface is
	 * auto-discoverable on fresh installs but opt-in on existing ones (JETPACK-1700).
	 *
	 * Hooked on `updating_jetpack_version`, which fires on every install including the
	 * first — with `$old_version === false` on a brand-new site (the same signal
	 * {@see self::activate_subscriptions_module_for_existing_sites()} keys off). Fresh
	 * installs are seeded visible; existing installs are seeded hidden and opt in later
	 * via the legacy Traffic page or My Jetpack. `add_option()` makes this seed-once: it
	 * never overrides a value a later opt-in (or opt-out) has set. WordPress.com sites
	 * ignore this option entirely (always visible) — see
	 * {@see \Automattic\Jetpack\SEO\Initializer::is_seo_surface_visible()}.
	 *
	 * @param string       $version     The new Jetpack version (unused).
	 * @param string|false $old_version The previous version, or false on a fresh install.
	 */
	public static function seed_seo_visibility_cohort( $version, $old_version ) {
		add_option( Jetpack_SEO_Initializer::VISIBILITY_OPTION, ! $old_version );
	}

	/**
	 * Sets the display_update_modal state.
	 *
	 * The release post update modal that read this state has been removed. The write is kept so the
	 * method still behaves as documented for the deprecation window. When this is deleted, also drop
	 * the matching `display_update_modal` guard in Automattic\Jetpack\CookieState::should_set_cookie(),
	 * which exists only to keep this key out of the cookie on the Jetpack admin screen.
	 *
	 * @deprecated 16.2
	 */
	public static function set_update_modal_display() {
		_deprecated_function( __METHOD__, 'jetpack-16.2' );
		self::state( 'display_update_modal', true );
	}

	/**
	 * Enqueues the block library styles.
	 *
	 * Only ever used by the release post update modal, which has been removed.
	 *
	 * @deprecated 16.2
	 *
	 * @param string $hook The current admin page.
	 */
	public static function enqueue_block_style( $hook ) {
		_deprecated_function( __METHOD__, 'jetpack-16.2' );
		if ( 'toplevel_page_jetpack' === $hook ) {
			wp_enqueue_style( 'wp-block-library' );
		}
	}

	/**
	 * Sets the internal version number and activation state.
	 *
	 * @static
	 */
	public static function plugin_initialize() {
		if ( ! Jetpack_Options::get_option( 'activated' ) ) {
			Jetpack_Options::update_option( 'activated', 2 );
		}

		if ( ! Jetpack_Options::get_option( 'version' ) ) {
			$old_version = JETPACK__VERSION . ':' . time();
			$version     = $old_version;
			/** This action is documented in class.jetpack.php */
			do_action( 'updating_jetpack_version', $version, false );
			Jetpack_Options::update_options( compact( 'version', 'old_version' ) );
		}

		if ( self::is_connection_ready() ) {
			self::handle_default_module_activation( true );
		}

		self::load_modules();

		Jetpack_Options::delete_option( 'do_activate' );
	}

	/**
	 * Handles the activation of the default modules depending on the current state of the site:
	 *  - If the site already has the jetpack_active_modules option, activate those.
	 *  - If the site has a site-only connection, only activate the default modules that require only a site connection.
	 *  - If the site has a user connection, activate the default modules that require a user connection.
	 *
	 * @param bool $should_activate_user_modules Whether the status of the user connection should be checked and the default modules that
	 *                                           require a user connection activated.
	 */
	private static function handle_default_module_activation( $should_activate_user_modules ) {
		$active_modules = Jetpack_Options::get_option( 'active_modules' );
		if ( $active_modules ) {
			self::delete_active_modules();

			/**
			 * Previously active modules could mean two things. First, it could mean
			 * that Jetpack was previously active on the site. In this case we would like
			 * to only activate the modules that were set to active.
			 * Another case could be that the module option was set by a standalone
			 * plugin. In that case the `active_modules_initalized` option will not
			 * be set, so we need to enable default Jetpack modules as well.
			 */
			if ( ! Jetpack_Options::get_option( 'active_modules_initialized' ) ) {
				$default_modules = self::get_default_modules();
				$active_modules  = array_merge( $active_modules, $default_modules );
				Jetpack_Options::update_option( 'active_modules_initialized', true );
			}

			self::activate_default_modules(
				999, // This version trick basically excludes every default module.
				1,
				$active_modules,
				false
			);
		} elseif ( $should_activate_user_modules && ( new Connection_Manager() )->get_connection_owner_id() ) { // Check for a user connection.
			self::activate_default_modules( false, false, array(), false, null, null, null );
			Jetpack_Options::update_option( 'active_modules_initialized', true );
		} else {
			self::activate_default_modules( false, false, array(), false, null, null, false );
		}
	}

	/**
	 * Removes all connection options
	 *
	 * @static
	 */
	public static function plugin_deactivation() {
		require_once ABSPATH . '/wp-admin/includes/plugin.php';
		$tracking = new Tracking();
		$tracking->record_user_event( 'deactivate_plugin', array() );
		if ( is_plugin_active_for_network( 'jetpack/jetpack.php' ) ) {
			Jetpack_Network::init()->deactivate();
		} else {
			add_filter( 'jetpack_update_activated_state_on_disconnect', '__return_false' );
			self::disconnect();
			Jetpack_Options::delete_option( 'version' );
		}

		if ( ! defined( 'WC_ANALYTICS' ) && class_exists( 'Automattic\Woocommerce_Analytics' ) ) {
			Woocommerce_Analytics::maybe_remove_proxy_speed_module();
		}
	}

	/**
	 * Set activated option to 4 on jetpack_idc_disconnect action.
	 */
	public static function on_idc_disconnect() {
		\Jetpack_Options::update_option( 'activated', 4 );
	}

	/**
	 * Disconnects from the Jetpack servers.
	 * Forgets all connection details and tells the Jetpack servers to do the same.
	 *
	 * Will not disconnect if there are other plugins using the connection.
	 *
	 * @since 11.0 Do not disconnect if other plugins are using the connection.
	 *
	 * @static
	 */
	public static function disconnect() {

		$connection = self::connection();

		// If the site is in an IDC because sync is not allowed,
		// let's make sure to not disconnect the production site.
		$connection->remove_connection( ! Identity_Crisis::validate_sync_error_idc_option() );
	}

	/**
	 * Happens after a successful disconnection.
	 *
	 * @static
	 */
	public static function jetpack_site_disconnected() {
		Identity_Crisis::clear_all_idc_options();

		\Automattic\Jetpack\Reprint_Export\Reprint_Exporter::discard_credentials();

		// Delete all the sync related data. Since it could be taking up space.
		Sender::get_instance()->uninstall();

		/**
		 * Filters whether the Jetpack activated state should be updated after disconnecting.
		 *
		 * @since 10.0.0
		 *
		 * @param bool $update_activated_state Whether activated state should be updated after disconnecting, defaults to true.
		 */
		$update_activated_state = apply_filters( 'jetpack_update_activated_state_on_disconnect', true );

		if ( $update_activated_state ) {
			Jetpack_Options::update_option( 'activated', 4 );
		}
	}

	/**
	 * Disconnects the user.
	 *
	 * @deprecated 13.4
	 * @see \Automattic\Jetpack\Connection\Manager::disconnect_user()
	 *
	 * @param int $user_id The user ID to disconnect.
	 */
	public function disconnect_user( $user_id ) {
		$this->connection_manager->disconnect_user( $user_id );
	}

	/**
	 * Checking the domain names in beta versions.
	 * If this is a development version, before attempting to connect, let's make sure that the domains are viable.
	 *
	 * @param null|\WP_Error $error The domain validation error, or `null` if everything's fine.
	 *
	 * @return null|\WP_Error The domain validation error, or `null` if everything's fine.
	 */
	public static function registration_check_domains( $error ) {
		if ( static::is_development_version() ) {
			$domains_to_check = array_unique(
				array(
					'siteurl' => wp_parse_url( get_site_url(), PHP_URL_HOST ),
					'homeurl' => wp_parse_url( get_home_url(), PHP_URL_HOST ),
				)
			);
			foreach ( $domains_to_check as $domain ) {
				$result = static::connection()->is_usable_domain( $domain );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
			}
		}

		return $error;
	}

	/**
	 * Tracking an internal event log. Try not to put too much chaff in here.
	 *
	 * [Everyone Loves a Log!](https://www.youtube.com/watch?v=2C7mNr5WMjA)
	 *
	 * @param mixed $code Error code to log.
	 * @param mixed $data Data to log.
	 */
	public static function log( $code, $data = null ) {

		$raw_log = Jetpack_Options::get_option( 'log', array() );
		// This can be modified by the `jetpack_options` filter, so abort if we don't have an array.
		if ( ! is_array( $raw_log ) ) {
			return;
		}

		// only grab the latest 200 entries.
		$log = array_slice( $raw_log, -199, 199 );

		// Append our event to the log.
		$log_entry = array(
			'time'    => time(),
			'user_id' => get_current_user_id(),
			'blog_id' => Jetpack_Options::get_option( 'id' ),
			'code'    => $code,
		);
		// Don't bother storing it unless we've got some.
		if ( $data !== null ) {
			$log_entry['data'] = $data;
		}
		$log[] = $log_entry;

		// Try add_option first, to make sure it's not autoloaded.
		// @todo: Add an add_option method to Jetpack_Options.
		if ( ! add_option( 'jetpack_log', $log, '', 'no' ) ) {
			Jetpack_Options::update_option( 'log', $log );
		}

		/**
		 * Fires when Jetpack logs an internal event.
		 *
		 * @since 3.0.0
		 *
		 * @param array $log_entry {
		 *  Array of details about the log entry.
		 *
		 *  @param string time Time of the event.
		 *  @param int user_id ID of the user who trigerred the event.
		 *  @param int blog_id Jetpack Blog ID.
		 *  @param string code Unique name for the event.
		 *  @param string data Data about the event.
		 * }
		 */
		do_action( 'jetpack_log_entry', $log_entry );
	}

	/**
	 * Get the internal event log.
	 *
	 * @param string $event only return the specific log events.
	 * @param int    $num - get specific number of latest results, limited to 200.
	 *
	 * @return array of log events || WP_Error for invalid params
	 */
	public static function get_log( $event = false, $num = false ) {
		if ( $event && ! is_string( $event ) ) {
			return new WP_Error( __( 'First param must be string or empty', 'jetpack' ) );
		}

		if ( $num && ! is_numeric( $num ) ) {
			return new WP_Error( __( 'Second param must be numeric or empty', 'jetpack' ) );
		}

		$entire_log = Jetpack_Options::get_option( 'log', array() );

		// If nothing set - act as it did before, otherwise let's start customizing the output.
		if ( ! $num && ! $event ) {
			return $entire_log;
		} else {
			$entire_log = array_reverse( $entire_log );
		}

		$custom_log_output = array();

		if ( $event ) {
			foreach ( $entire_log as $log_event ) {
				if ( $event === $log_event['code'] ) {
					$custom_log_output[] = $log_event;
				}
			}
		} else {
			$custom_log_output = $entire_log;
		}

		if ( $num ) {
			$custom_log_output = array_slice( $custom_log_output, 0, $num );
		}

		return $custom_log_output;
	}

	/**
	 * Log modification of important settings.
	 *
	 * @param string $option Option name.
	 * @param string $old_value Old value of option.
	 * @param string $value New value of option.
	 */
	public static function log_settings_change( $option, $old_value, $value ) {
		switch ( $option ) {
			case 'jetpack_sync_non_public_post_stati':
				self::log( $option, $value );
				break;
		}
	}

	/**
	 * Return stat data for WPCOM sync.
	 *
	 * The Sync stats module was this method's last caller and moved to the Connection package's
	 * `Heartbeat::generate_stats_array()`, which assembles the heartbeat data through the
	 * `jetpack_heartbeat_stats_array` filter. Note the package method does not include the extended
	 * data from `get_additional_stat_data()`, so callers relying on `$extended` need to add it themselves.
	 *
	 * @deprecated 16.2
	 *
	 * @param bool $encode JSON encode the result.
	 * @param bool $extended Adds additional stats data.
	 *
	 * @return array|string Stats data. Array if $encode is false. JSON-encoded string is $encode is true.
	 */
	public static function get_stat_data( $encode = true, $extended = true ) {
		_deprecated_function( __METHOD__, 'jetpack-16.2', 'Automattic\\Jetpack\\Heartbeat::generate_stats_array' );

		$env_stats = method_exists( Heartbeat::class, 'get_environment_stats' )
			? Heartbeat::get_environment_stats()
			: array();
		$data      = array_merge( Jetpack_Heartbeat::generate_stats_array(), $env_stats );

		if ( $extended ) {
			$additional_data = self::get_additional_stat_data();
			$data            = array_merge( $data, $additional_data );
		}

		if ( $encode ) {
			return wp_json_encode( $data, JSON_UNESCAPED_SLASHES );
		}

		return $data;
	}

	/**
	 * Get additional stat data to sync to WPCOM
	 *
	 * @param string $prefix Stats prefix.
	 *
	 * @return array stats values.
	 */
	public static function get_additional_stat_data( $prefix = '' ) {
		$return                             = array();
		$return[ "{$prefix}themes" ]        = self::get_parsed_theme_data();
		$return[ "{$prefix}plugins-extra" ] = self::get_parsed_plugin_data();
		$return[ "{$prefix}users" ]         = (int) self::get_site_user_count();
		$return[ "{$prefix}site-count" ]    = 0;

		if ( function_exists( 'get_blog_count' ) ) {
			$return[ "{$prefix}site-count" ] = get_blog_count();
		}
		return $return;
	}

	/**
	 * Get current site's user count.
	 *
	 * @return int|string|null Number of users on the site. -1 for a large network.
	 */
	private static function get_site_user_count() {
		global $wpdb;

		if ( function_exists( 'wp_is_large_network' ) ) {
			if ( wp_is_large_network( 'users' ) ) {
				return -1; // Not a real value but should tell us that we are dealing with a large network.
			}
		}
		$user_count = get_transient( 'jetpack_site_user_count' );
		if ( false === ( $user_count ) ) {
			// It wasn't there, so regenerate the data and save the transient.
			$user_count = $wpdb->get_var( "SELECT COUNT(*) FROM $wpdb->usermeta WHERE meta_key = '{$wpdb->prefix}capabilities'" );
			set_transient( 'jetpack_site_user_count', $user_count, DAY_IN_SECONDS );
		}
		return $user_count;
	}

	/* Admin Pages */

	/**
	 * Admin init function.
	 *
	 * Runs on admin_init hook.
	 *
	 * @return void
	 */
	public function admin_init() {
		// If the plugin is not connected, display a connect message.
		if (
			// the plugin was auto-activated and needs its candy.
			Jetpack_Options::get_option_and_ensure_autoload( 'do_activate', '0' )
		||
			// the plugin is active, but was never activated.  Probably came from a site-wide network activation.
			! Jetpack_Options::get_option( 'activated' )
		) {
			self::plugin_initialize();
		}

		$is_offline_mode              = ( new Status() )->is_offline_mode();
		$fallback_no_verify_ssl_certs = Jetpack_Options::get_option( 'fallback_no_verify_ssl_certs' );
		/** Already documented in automattic/jetpack-connection::src/class-client.php */
		$client_verify_ssl_certs = apply_filters( 'jetpack_client_verify_ssl_certs', false );

		// Run post-activation actions if needed.
		$this->plugin_post_activation();

		if ( ( self::is_connection_ready() || $is_offline_mode ) && false === $fallback_no_verify_ssl_certs && ! $client_verify_ssl_certs ) {
			// Upgrade: 1.1 -> 1.1.1
			// Check and see if host can verify the Jetpack servers' SSL certificate.
			$args = array();
			// @phan-suppress-next-line PhanAccessMethodInternal -- Phan is correct, but the usage is intentional.
			Client::_wp_remote_request( self::connection()->api_url( 'test' ), $args, true );
		}

		if (
			current_user_can( 'manage_options' )
			&& ! self::permit_ssl()
			&& ! $is_offline_mode
		) {
			add_action( 'jetpack_notices', array( $this, 'alert_auto_ssl_fail' ) );
		}

		add_action( 'load-plugins.php', array( $this, 'intercept_plugin_error_scrape_init' ) );
		add_action( 'load-plugins.php', array( $this, 'plugins_page_init_jetpack_state' ) );

		if ( ! ( is_multisite() && is_plugin_active_for_network( 'jetpack/jetpack.php' ) && ! is_network_admin() ) ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'deactivate_dialog' ) );
		}

		add_filter( 'plugin_action_links_' . plugin_basename( JETPACK__PLUGIN_DIR . 'jetpack.php' ), array( $this, 'plugin_action_links' ) );

		if ( self::is_connection_ready() || $is_offline_mode ) {
			// Artificially throw errors in certain specific cases during plugin activation.
			add_action( 'activate_plugin', array( $this, 'throw_error_on_activate_plugin' ) );
		}
	}

	/**
	 * Adds body classes.
	 *
	 * @param string $admin_body_class Body classes.
	 *
	 * @return string
	 */
	public function admin_body_class( $admin_body_class = '' ) {
		$classes = explode( ' ', trim( $admin_body_class ) );

		$classes[] = self::is_connection_ready() ? 'jetpack-connected' : 'jetpack-disconnected';

		$admin_body_class = implode( ' ', array_unique( $classes ) );
		return " $admin_body_class ";
	}

	/**
	 * Adds Jetpack Page styles by appending class to the admin body class.
	 *
	 * @param string $admin_body_class Existing admin body class string.
	 *
	 * @return string
	 */
	public static function add_jetpack_pagestyles( $admin_body_class = '' ) {
		return $admin_body_class . ' jetpack-pagestyles ';
	}

	/**
	 * Sometimes a plugin can activate without causing errors, but it will cause errors on the next page load.
	 * This function artificially throws errors for such cases (per a specific list).
	 *
	 * @param string $plugin The activated plugin.
	 * @throws RuntimeException If a conflicting plugin is detected.
	 */
	public function throw_error_on_activate_plugin( $plugin ) {
		$active_modules = self::get_active_modules();

		// The Shortlinks module and the Stats plugin conflict, but won't cause errors on activation because of some function_exists() checks.
		if ( function_exists( 'stats_get_api_key' ) && in_array( 'shortlinks', $active_modules, true ) ) {
			$throw = false;

			// Try and make sure it really was the stats plugin.
			if ( ! class_exists( 'ReflectionFunction' ) ) {
				if ( 'stats.php' === basename( $plugin ) ) {
					$throw = true;
				}
			} else {
				// @phan-suppress-next-line PhanUndeclaredFunctionInCallable -- Checked above. See also https://github.com/phan/phan/issues/1204.
				$reflection = new ReflectionFunction( 'stats_get_api_key' );
				if ( basename( $plugin ) === basename( $reflection->getFileName() ) ) {
					$throw = true;
				}
			}

			if ( $throw ) {
				/* translators: Plugin name to deactivate. */
				throw new RuntimeException( sprintf( __( 'Jetpack contains the most recent version of the old "%1$s" plugin.', 'jetpack' ), 'WordPress.com Stats' ) );
			}
		}
	}

	/**
	 * Call to Jetpack::state on the load-plugins.php hook.
	 * In case the jetpackState cookie is populated, this call will read and re-set the cookie before HTTP headers are sent.
	 */
	public function plugins_page_init_jetpack_state() {
		self::state( 'message' );
	}

	/**
	 * Adds the intercept action to the check_admin_referer hook.
	 *
	 * @return void
	 */
	public function intercept_plugin_error_scrape_init() {
		add_action( 'check_admin_referer', array( $this, 'intercept_plugin_error_scrape' ), 10, 2 );
	}

	/**
	 * Detect if conflicting plugin is being deactivated.
	 *
	 * @param string   $action The nonce action.
	 * @param bool|int $result False if the nonce is invalid, 1 if the nonce is valid and generated between 0-12 hours ago, 2 if the nonce is valid and generated between 12-24 hours ago.
	 *
	 * @return void
	 */
	public function intercept_plugin_error_scrape( $action, $result ) {
		if ( ! $result ) {
			return;
		}

		foreach ( $this->plugins_to_deactivate as $deactivate_us ) {
			foreach ( $deactivate_us as $deactivate_me ) {
				if ( "plugin-activation-error_{$deactivate_me[0]}" === $action ) {
					/* translators: Plugin name to deactivate. */
					self::bail_on_activation( sprintf( __( 'Jetpack contains the most recent version of the old &#8220;%1$s&#8221; plugin.', 'jetpack' ), $deactivate_me[1] ), false );
				}
			}
		}
	}

	/**
	 * Register the remote file upload request handlers, if needed.
	 *
	 * @access public
	 */
	public function add_remote_request_handlers() {
		// Remote file uploads are allowed only via AJAX requests.
		if ( ! is_admin() || ! Constants::get_constant( 'DOING_AJAX' ) ) {
			return;
		}

		// Remote file uploads are allowed only for a set of specific AJAX actions.
		$remote_request_actions = array(
			'jetpack_upload_file',
			'jetpack_update_file',
		);

		// phpcs:ignore WordPress.Security.NonceVerification
		if ( ! isset( $_POST['action'] ) || ! in_array( $_POST['action'], $remote_request_actions, true ) ) {
			return;
		}

		// Require Jetpack authentication for the remote file upload AJAX requests.
		if ( ! $this->connection_manager ) {
			$this->connection_manager = new Connection_Manager();
		}

		$this->connection_manager->require_jetpack_authentication();

		// Register the remote file upload AJAX handlers.
		foreach ( $remote_request_actions as $action ) {
			add_action( "wp_ajax_nopriv_{$action}", array( $this, 'remote_request_handlers' ) );
		}
	}

	/**
	 * Handler for Jetpack remote file uploads.
	 *
	 * @access public
	 * @return never
	 */
	public function remote_request_handlers() {
		switch ( current_filter() ) {
			case 'wp_ajax_nopriv_jetpack_upload_file':
				$response = $this->upload_handler();
				break;

			case 'wp_ajax_nopriv_jetpack_update_file':
				$response = $this->upload_handler( true );
				break;
			default:
				$response = new WP_Error( 'unknown_handler', 'Unknown Handler', 400 );
				break;
		}

		if ( ! $response ) {
			$response = new WP_Error( 'unknown_error', 'Unknown Error', 400 );
		}

		if ( is_wp_error( $response ) ) {
			$status_code       = $response->get_error_data();
			$error             = $response->get_error_code();
			$error_description = $response->get_error_message();

			if ( ! is_int( $status_code ) ) {
				$status_code = 400;
			}

			wp_send_json( (object) compact( 'error', 'error_description' ), $status_code, JSON_UNESCAPED_SLASHES );
		}

		if ( true === $response ) {
			status_header( 200 );
			exit( 0 );
		}

		wp_send_json( (object) $response, 200, JSON_UNESCAPED_SLASHES );
	}

	/**
	 * Uploads a file gotten from the global $_FILES.
	 * If `$update_media_item` is true and `post_id` is defined
	 * the attachment file of the media item (gotten through of the post_id)
	 * will be updated instead of add a new one.
	 *
	 * @param  boolean $update_media_item - update media attachment.
	 * @return array|WP_Error - An array describing the uploading files process.
	 */
	public function upload_handler( $update_media_item = false ) {
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' !== strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) ) {
			return new WP_Error( 405, get_status_header_desc( 405 ), 405 );
		}

		$user = wp_authenticate( '', '' );
		if ( ! $user || is_wp_error( $user ) ) {
			return new WP_Error( 403, get_status_header_desc( 403 ), 403 );
		}

		wp_set_current_user( $user->ID );

		if ( ! current_user_can( 'upload_files' ) ) {
			return new WP_Error( 'cannot_upload_files', 'User does not have permission to upload files', 403 );
		}

		if ( empty( $_FILES ) ) {
			return new WP_Error( 'no_files_uploaded', 'No files were uploaded: nothing to process', 400 );
		}

		foreach ( array_keys( $_FILES ) as $files_key ) {
			if ( ! isset( $_POST[ "_jetpack_file_hmac_{$files_key}" ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- no site changes here.
				return new WP_Error( 'missing_hmac', 'An HMAC for one or more files is missing', 400 );
			}
		}

		$media_keys = isset( $_FILES['media'] ) ? array_keys( $_FILES['media'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Unslash is not needed for `$_FILES`, the sniff is wrong. Sanitization should happen below.

		$token = ( new Tokens() )->get_access_token( get_current_user_id() );
		if ( ! $token || is_wp_error( $token ) ) {
			return new WP_Error( 'unknown_token', 'Unknown Jetpack token', 403 );
		}

		/**
		 * Optionally block uploads processed through Jetpack's upload_handler().
		 * The filter may return false or WP_Error to block this particular upload.
		 *
		 * @since 10.8
		 *
		 * @param bool|WP_Error $allowed If false or WP_Error, block the upload. If true, allow the upload.
		 * @param mixed $_FILES The $_FILES attempting to be uploaded.
		 */
		$can_upload = apply_filters( 'jetpack_upload_handler_can_upload', true, $_FILES );
		if ( ! $can_upload || is_wp_error( $can_upload ) ) {
			if ( is_wp_error( $can_upload ) ) {
				return $can_upload;
			}
			return new WP_Error( 'handler_cannot_upload', __( 'The upload handler cannot upload files', 'jetpack' ), 400 );
		}

		$uploaded_files = array();
		$global_post    = $GLOBALS['post'] ?? null;
		unset( $GLOBALS['post'] );
		if ( empty( $_FILES['media']['name'] ) ) {
			// Nothing to process, just return.
			return $uploaded_files;
		}
		foreach ( $_FILES['media']['name'] as $index => $name ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- As above, unslash sniff is wrong. Validation should happen below.
			$file = array();
			foreach ( $media_keys as $media_key ) {
				$file[ $media_key ] = $_FILES['media'][ $media_key ][ $index ] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash,,WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- As above, the unslash sniff is wrong.
			}

			list( $hmac_provided, $salt ) = isset( $_POST['_jetpack_file_hmac_media'][ $index ] ) ? explode( ':', filter_var( wp_unslash( $_POST['_jetpack_file_hmac_media'][ $index ] ) ) ) : array( 'no', '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce should have been checked by the caller.

			$hmac_file = hash_hmac_file( 'sha1', $file['tmp_name'], $salt . $token->secret );
			if ( $hmac_provided !== $hmac_file ) {
				$uploaded_files[ $index ] = (object) array(
					'error'             => 'invalid_hmac',
					'error_description' => 'The corresponding HMAC for this file does not match',
				);
				continue;
			}

			$_FILES['.jetpack.upload.'] = $file;
			$post_id                    = isset( $_POST['post_id'][ $index ] ) ? absint( $_POST['post_id'][ $index ] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- caller should have checked a nonce.
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				$post_id = 0;
			}

			if ( $update_media_item ) {
				if ( ! isset( $post_id ) || 0 === $post_id ) {
					return new WP_Error( 'invalid_input', 'Media ID must be defined.', 400 );
				}

				$media_array = $_FILES['media']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

				$file_array             = array();
				$file_array['name']     = $media_array['name'][0];
				$file_array['type']     = $media_array['type'][0];
				$file_array['tmp_name'] = $media_array['tmp_name'][0];
				$file_array['error']    = $media_array['error'][0];
				$file_array['size']     = $media_array['size'][0];

				$edited_media_item = Jetpack_Media::edit_media_file( $post_id, $file_array );

				if ( is_wp_error( $edited_media_item ) ) {
					return $edited_media_item;
				}

				$response = (object) array(
					'id'   => (string) $post_id,
					'file' => (string) $edited_media_item->post_title,
					'url'  => (string) wp_get_attachment_url( $post_id ),
					'type' => (string) $edited_media_item->post_mime_type,
					'meta' => (array) wp_get_attachment_metadata( $post_id ),
				);

				return array( $response );
			}

			$attachment_id = media_handle_upload(
				'.jetpack.upload.',
				$post_id,
				array(),
				array(
					'action' => 'jetpack_upload_file',
				)
			);

			if ( ! $attachment_id ) {
				$uploaded_files[ $index ] = (object) array(
					'error'             => 'unknown',
					'error_description' => 'An unknown problem occurred processing the upload on the Jetpack site',
				);
			} elseif ( is_wp_error( $attachment_id ) ) {
				$uploaded_files[ $index ] = (object) array(
					'error'             => 'attachment_' . $attachment_id->get_error_code(),
					'error_description' => $attachment_id->get_error_message(),
				);
			} else {
				$attachment               = get_post( $attachment_id );
				$uploaded_files[ $index ] = (object) array(
					'id'   => (string) $attachment_id,
					'file' => $attachment->post_title,
					'url'  => wp_get_attachment_url( $attachment_id ),
					'type' => $attachment->post_mime_type,
					'meta' => wp_get_attachment_metadata( $attachment_id ),
				);
			}
		}
		if ( $global_post !== null ) {
			$GLOBALS['post'] = $global_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}

		return $uploaded_files;
	}

	/**
	 * Add action links for the Jetpack plugin.
	 *
	 * @param array $actions Plugin actions.
	 *
	 * @return array
	 */
	public function plugin_action_links( $actions ) {
		if ( current_user_can( 'jetpack_manage_modules' ) && ( self::is_connection_ready() || ( new Status() )->is_offline_mode() ) ) {
			return array_merge(
				array( 'settings' => sprintf( '<a href="%s">%s</a>', esc_url( self::admin_url( 'page=jetpack-settings#/settings' ) ), __( 'Settings', 'jetpack' ) ) ),
				$actions
			);
		}

		return $actions;
	}

	/**
	 * Adds the deactivation warning modal for Jetpack.
	 *
	 * @param string $hook The current admin page.
	 *
	 * @return void
	 */
	public function deactivate_dialog( $hook ) {
		if (
			'plugins.php' === $hook
			&& self::is_connection_ready()
		) {

			// Register jp-tracks-functions dependency.
			Tracking::register_tracks_functions_scripts( true );

			// add a deactivation script that will pick up deactivation actions for the Jetpack plugin.
			Assets::register_script(
				'jetpack-plugins-page-js',
				'_inc/build/plugins-page.js',
				JETPACK__PLUGIN_FILE,
				array(
					'in_footer'  => true,
					'textdomain' => 'jetpack',
				)
			);
			Assets::enqueue_script( 'jetpack-plugins-page-js' );

			// Add objects to be passed to the initial state of the app.
			// Use wp_add_inline_script instead of wp_localize_script, see https://core.trac.wordpress.org/ticket/25280.
			wp_add_inline_script( 'jetpack-plugins-page-js', 'var Initial_State=' . wp_json_encode( Jetpack_Redux_State_Helper::get_plugins_page_state(), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . ';', 'before' );

			add_action( 'admin_footer', array( $this, 'jetpack_plugin_portal_containers' ) );
		}
	}

	/**
	 * Outputs the wrapper for the plugin modal
	 * Contents are loaded by React script
	 *
	 * @return void
	 */
	public function jetpack_plugin_portal_containers() {
		$this->load_view( 'admin/jetpack-plugin-portal-containers.php' );
	}

	/**
	 * Filters the login URL to include the registration flow in case the user isn't logged in.
	 *
	 * @param string $login_url The wp-login URL.
	 * @param string $redirect  URL to redirect users after logging in.
	 * @since Jetpack 8.4
	 * @return string
	 */
	public function login_url( $login_url, $redirect ) {
		parse_str( (string) wp_parse_url( $redirect, PHP_URL_QUERY ), $redirect_parts );
		if ( ! empty( $redirect_parts[ self::$jetpack_redirect_login ] ) ) {
			$login_url = add_query_arg( self::$jetpack_redirect_login, 'true', $login_url );
		}
		return $login_url;
	}

	/**
	 * Redirects non-authenticated users to authenticate with Calypso if redirect flag is set.
	 *
	 * @since Jetpack 8.4
	 */
	public function login_init() {
		// phpcs:ignore WordPress.Security.NonceVerification
		if ( ! empty( $_GET[ self::$jetpack_redirect_login ] ) ) {
			add_filter( 'allowed_redirect_hosts', array( Host::class, 'allow_wpcom_environments' ) );
			wp_safe_redirect(
				add_query_arg(
					array(
						'forceInstall' => 1,
						'url'          => rawurlencode( get_site_url() ),
					),
					// @todo provide way to go to specific calypso env.
					self::get_calypso_host() . 'jetpack/connect'
				)
			);
			exit( 0 );
		}
	}

	/*
	 * Registration flow:
	 * 1 - ::admin_page_load() action=register
	 * 2 - ::try_registration()
	 * 3 - ::register()
	 *     - Creates jetpack_register option containing two secrets and a timestamp
	 *     - Calls https://jetpack.wordpress.com/jetpack.register/1/ with
	 *       siteurl, home, gmt_offset, timezone_string, site_name, secret_1, secret_2, site_lang, timeout, stats_id
	 *     - That request to jetpack.wordpress.com does not immediately respond.  It first makes a request BACK to this site's
	 *       xmlrpc.php?for=jetpack: RPC method: jetpack.verifyRegistration, Parameters: secret_1
	 *     - The XML-RPC request verifies secret_1, deletes both secrets and responds with: secret_2
	 *     - https://jetpack.wordpress.com/jetpack.register/1/ verifies that XML-RPC response (secret_2) then finally responds itself with
	 *       jetpack_id, jetpack_secret, jetpack_public
	 *     - ::register() then stores jetpack_options: id => jetpack_id, blog_token => jetpack_secret
	 * 4 - redirect to https://wordpress.com/start/jetpack-connect
	 * 5 - user logs in with WP.com account
	 * 6 - remote request to this site's xmlrpc.php with action remoteAuthorize, Jetpack_XMLRPC_Server->remote_authorize
	 *      - Manager::authorize()
	 *      - Manager::get_token()
	 *      - GET https://jetpack.wordpress.com/jetpack.token/1/ with
	 *        client_id, client_secret, grant_type, code, redirect_uri:action=authorize, state, scope, user_email, user_login
	 *          - which responds with access_token, token_type, scope
	 *      - Manager::authorize() stores jetpack_options: user_token => access_token.$user_id
	 *      - Jetpack::activate_default_modules()
	 *          - Deactivates deprecated plugins
	 *          - Activates all default modules
	 *      - Responds with either error, or 'connected' for new connection, or 'linked' for additional linked users
	 * 7 - For a new connection, user selects a Jetpack plan on wordpress.com
	 * 8 - User is redirected back to wp-admin/index.php?page=jetpack with state:message=authorized
	 *     Done!
	 */

	/**
	 * Build the user-facing description stored alongside a registration error code.
	 *
	 * @since 16.2
	 *
	 * @param string $error_code The WP_Error code.
	 * @param string $message    The WP_Error message.
	 * @return string The description, empty when the message is not user-facing copy.
	 */
	public static function get_registration_error_description( $error_code, $message ) {
		// Manager::validate_remote_register_response() does not always put user-facing copy in the
		// message slot: wpcom_5??, wpcom_408 and wpcom_bad_response store the HTTP status there,
		// and jetpack_id stores the raw response body, which can also overflow the state cookie.
		if ( 'jetpack_id' === $error_code || is_numeric( $message ) ) {
			return '';
		}

		return mb_substr( (string) $message, 0, 250 );
	}

	/**
	 * Handles the page load events for the Jetpack admin page
	 */
	public function admin_page_load() {
		$error = false;

		// Make sure we have the right body class to hook stylings for subpages off of.
		add_filter( 'admin_body_class', array( __CLASS__, 'add_jetpack_pagestyles' ), 20 );

		if ( ! empty( $_GET['jetpack_restate'] ) ) {
			// Should only be used in intermediate redirects to preserve state across redirects.
			self::restate();
		}

		if ( isset( $_GET['action'] ) ) {
			switch ( $_GET['action'] ) {
				/**
				 * Cases authorize and authorize_redirect are now handled by Connection package Webhooks
				 */
				case 'authorize_redirect':
				case 'authorize':
					break;
				case 'register':
					if ( ! current_user_can( 'jetpack_connect' ) ) {
						$error = 'cheatin';
						break;
					}
					check_admin_referer( 'jetpack-register' );
					self::log( 'register' );
					self::maybe_set_version_option();
					$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : false;
					if ( $from ) {
						static::connection()->add_register_request_param( 'from', (string) $from );
					}
					$registered = static::connection()->try_registration();
					if ( is_wp_error( $registered ) ) {
						$error = $registered->get_error_code();
						self::state( 'error', $error );

						self::state( 'error_description', self::get_registration_error_description( $error, $registered->get_error_message() ) );

						/**
						 * Jetpack registration Error.
						 *
						 * @since 7.5.0
						 *
						 * @param string|int $error The error code.
						 * @param \WP_Error $registered The error object.
						 */
						do_action( 'jetpack_connection_register_fail', $error, $registered );
						break;
					}

					$redirect = isset( $_GET['redirect'] ) ? wp_unslash( $_GET['redirect'] ) : false; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

					/**
					 * Jetpack registration Success.
					 *
					 * @since 7.5.0
					 *
					 * @param string $from 'from' GET parameter;
					 */
					do_action( 'jetpack_connection_register_success', $from );

					$url = $this->build_connect_url( true, $redirect, $from );

					if ( ! empty( $_GET['auth_approved'] ) && 'true' === $_GET['auth_approved'] ) {
						$url = add_query_arg( 'auth_approved', 'true', $url );
					}

					add_filter( 'allowed_redirect_hosts', array( Host::class, 'allow_wpcom_environments' ) );
					wp_safe_redirect( $url );
					exit( 0 );
				case 'activate':
					if ( ! current_user_can( 'jetpack_activate_modules' ) ) {
						$error = 'cheatin';
						break;
					}

					$module = isset( $_GET['module'] ) ? sanitize_text_field( wp_unslash( $_GET['module'] ) ) : '';
					check_admin_referer( "jetpack_activate-$module" );
					self::log( 'activate', $module );
					if ( ! self::activate_module( $module ) ) {
						/* translators: module/feature name */
						self::state( 'error', sprintf( __( 'Could not activate %s', 'jetpack' ), $module ) );
					}
					// The following two lines will rarely happen, as Jetpack::activate_module normally exits at the end.
					wp_safe_redirect( self::admin_url( 'page=jetpack' ) );
					exit( 0 );
				case 'activate_default_modules':
					check_admin_referer( 'activate_default_modules' );
					self::log( 'activate_default_modules' );
					self::restate();
					$min_version   = isset( $_GET['min_version'] ) ? sanitize_text_field( wp_unslash( $_GET['min_version'] ) ) : false;
					$max_version   = isset( $_GET['max_version'] ) ? sanitize_text_field( wp_unslash( $_GET['max_version'] ) ) : false;
					$other_modules = isset( $_GET['other_modules'] ) && is_array( $_GET['other_modules'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_GET['other_modules'] ) ) : array();
					self::activate_default_modules( $min_version, $max_version, $other_modules );
					wp_safe_redirect( self::admin_url( 'page=jetpack' ) );
					exit( 0 );
				case 'disconnect':
					if ( ! current_user_can( 'jetpack_disconnect' ) ) {
						$error = 'cheatin';
						break;
					}

					check_admin_referer( 'jetpack-disconnect' );
					self::log( 'disconnect' );
					self::disconnect();
					wp_safe_redirect( self::admin_url( 'disconnected=true' ) );
					exit( 0 );
				case 'reconnect':
					if ( ! current_user_can( 'jetpack_reconnect' ) ) {
						$error = 'cheatin';
						break;
					}

					check_admin_referer( 'jetpack-reconnect' );
					self::log( 'reconnect' );
					self::disconnect();

					add_filter( 'allowed_redirect_hosts', array( Host::class, 'allow_wpcom_environments' ) );
					wp_safe_redirect( $this->build_connect_url( true, false, 'reconnect' ) );
					exit( 0 );
				case 'deactivate':
					if ( ! current_user_can( 'jetpack_deactivate_modules' ) ) {
						$error = 'cheatin';
						break;
					}

					$modules = sanitize_text_field( wp_unslash( $_GET['module'] ) );
					check_admin_referer( "jetpack_deactivate-$modules" );
					foreach ( explode( ',', $modules ) as $module ) {
						self::log( 'deactivate', $module );
						self::deactivate_module( $module );
						self::state( 'message', 'module_deactivated' );
					}
					self::state( 'module', $modules );
					wp_safe_redirect( self::admin_url( 'page=jetpack' ) );
					exit( 0 );
				case 'unlink':
					$redirect = isset( $_GET['redirect'] ) ? sanitize_text_field( wp_unslash( $_GET['redirect'] ) ) : '';
					check_admin_referer( 'jetpack-unlink' );
					self::log( 'unlink' );
					$this->connection_manager->disconnect_user();
					self::state( 'message', 'unlinked' );
					if ( 'sub-unlink' === $redirect ) {
						wp_safe_redirect( admin_url() );
					} else {
						wp_safe_redirect( self::admin_url( array( 'page' => rawurlencode( $redirect ) ) ) );
					}
					exit( 0 );
				default:
					/**
					 * Fires when a Jetpack admin page is loaded with an unrecognized parameter.
					 *
					 * @since 2.6.0
					 *
					 * @param string sanitize_key( $_GET['action'] ) Unrecognized URL parameter.
					 */
					do_action( 'jetpack_unrecognized_action', sanitize_key( $_GET['action'] ) );
			}
		}

		$error = $error ? $error : self::state( 'error' );
		if ( ! $error ) {
			self::activate_new_modules( true );
		}

		$activated_manage = false;
		$message_code     = self::state( 'message' );
		if ( self::state( 'optin-manage' ) ) {
			$activated_manage = $message_code;
			$message_code     = 'jetpack-manage';
		}

		switch ( $message_code ) {
			case 'jetpack-manage':
				$sites_url = esc_url( Redirect::get_url( 'calypso-sites' ) );
				// translators: %s is the URL to the "Sites" panel on wordpress.com.
				$this->message = '<strong>' . sprintf( __( 'You are all set! Your site can now be managed from <a href="%s" target="_blank">wordpress.com/sites</a>.', 'jetpack' ), $sites_url ) . '</strong>';
				if ( $activated_manage ) {
					$this->message .= '<br /><strong>' . __( 'Manage has been activated for you!', 'jetpack' ) . '</strong>';
				}
				break;

		}

		$deactivated_plugins = self::state( 'deactivated_plugins' );

		if ( ! empty( $deactivated_plugins ) ) {
			$deactivated_plugins = explode( ',', $deactivated_plugins );
			$deactivated_titles  = array();
			foreach ( $deactivated_plugins as $deactivated_plugin ) {
				list( $module, $idx ) = explode( ':', $deactivated_plugin );
				if ( ! isset( $this->plugins_to_deactivate[ $module ][ $idx ] ) ) {
					continue;
				}

				$deactivated_titles[] = '<strong>' . str_replace( ' ', '&nbsp;', $this->plugins_to_deactivate[ $module ][ $idx ][1] ) . '</strong>';
			}

			if ( $deactivated_titles ) {
				if ( $this->message ) {
					$this->message .= "<br /><br />\n";
				}

				$this->message .= wp_sprintf(
					_n(
						'Jetpack contains the most recent version of the old %l plugin.',
						'Jetpack contains the most recent versions of the old %l plugins.',
						count( $deactivated_titles ),
						'jetpack'
					),
					$deactivated_titles
				);

				$this->message .= "<br />\n";

				$this->message .= _n(
					'The old version has been deactivated and can be removed from your site.',
					'The old versions have been deactivated and can be removed from your site.',
					count( $deactivated_titles ),
					'jetpack'
				);
			}
		}

		$this->privacy_checks = self::state( 'privacy_checks' );

		if ( $this->message || $this->error || $this->privacy_checks ) {
			add_action( 'jetpack_notices', array( $this, 'admin_notices' ) );
		}

		add_filter( 'jetpack_short_module_description', 'wptexturize' );
	}

	/**
	 * Display admin notice upon error.
	 *
	 * @return void
	 */
	public function admin_notices() {

		if ( $this->error ) {
			?>
<div id="message" class="jetpack-message jetpack-err">
	<div class="squeezer">
		<h2>
			<?php
			echo wp_kses(
				$this->error,
				array(
					'a'      => array( 'href' => array() ),
					'small'  => true,
					'code'   => true,
					'strong' => true,
					'br'     => true,
					'b'      => true,
				)
			);
			?>
			</h2>
			<?php
			$desc = self::state( 'error_description' );
			if ( $desc ) :
				?>
		<p><?php echo esc_html( stripslashes( $desc ) ); ?></p>
<?php	endif; ?>
	</div>
</div>
			<?php
		}

		if ( $this->message ) {
			?>
<div id="message" class="jetpack-message">
	<div class="squeezer">
		<h2>
			<?php
			echo wp_kses(
				$this->message,
				array(
					'strong' => array(),
					'a'      => array( 'href' => true ),
					'br'     => true,
				)
			);
			?>
			</h2>
	</div>
</div>
			<?php
		}

		if ( $this->privacy_checks ) :
			$module_names = array();
			$module_slugs = array();

			$privacy_checks = explode( ',', $this->privacy_checks );
			$privacy_checks = array_filter( $privacy_checks, array( 'Jetpack', 'is_module' ) );
			foreach ( $privacy_checks as $module_slug ) {
				$module = self::get_module( $module_slug );
				if ( ! $module ) {
					continue;
				}

				$module_slugs[] = $module_slug;
				$module_names[] = "<strong>{$module['name']}</strong>";
			}

			$module_slugs = implode( ',', $module_slugs );
			?>
<div id="message" class="jetpack-message jetpack-err">
	<div class="squeezer">
		<h2><strong><?php esc_html_e( 'Is this site private?', 'jetpack' ); ?></strong></h2><br />
		<p>
			<?php
			echo wp_kses(
				wptexturize(
					wp_sprintf(
						_nx(
							"Like your site's RSS feeds, %l allows access to your posts and other content to third parties.",
							"Like your site's RSS feeds, %l allow access to your posts and other content to third parties.",
							count( $privacy_checks ),
							'%l = list of Jetpack module/feature names',
							'jetpack'
						),
						$module_names
					)
				),
				array( 'strong' => true )
			);

			echo "\n<br />\n";

			echo wp_kses(
				sprintf(
						/* translators: URL to deactivate Jetpack features. */
					_nx(
						'If your site is not publicly accessible, consider <a href="%1$s" title="%2$s">deactivating this feature</a>.',
						'If your site is not publicly accessible, consider <a href="%1$s" title="%2$s">deactivating these features</a>.',
						count( $privacy_checks ),
						'%1$s = deactivation URL, %2$s = "Deactivate {list of Jetpack module/feature names}',
						'jetpack'
					),
					esc_url(
						wp_nonce_url(
							self::admin_url(
								array(
									'page'   => 'jetpack',
									'action' => 'deactivate',
									'module' => rawurlencode( $module_slugs ),
								)
							),
							"jetpack_deactivate-$module_slugs"
						)
					),
					esc_attr( wp_kses( wp_sprintf( _x( 'Deactivate %l', '%l = list of Jetpack module/feature names', 'jetpack' ), $module_names ), array() ) )
				),
				array(
					'a' => array(
						'href'  => true,
						'title' => true,
					),
				)
			);
			?>
		</p>
	</div>
</div>
			<?php
endif;
	}

	/**
	 * Initialize the jetpack stats instance only when needed
	 *
	 * @return void
	 */
	private function initialize_stats() {
		if ( $this->a8c_mc_stats_instance === null ) {
			$this->a8c_mc_stats_instance = new Automattic\Jetpack\A8c_Mc_Stats();
		}
	}

	/**
	 * Record a stat for later output.  This will only currently output in the admin_footer.
	 *
	 * @param string $group Stats group.
	 * @param string $detail Stats detail.
	 */
	public function stat( $group, $detail ) {
		$this->initialize_stats();
		$this->a8c_mc_stats_instance->add( $group, $detail );

		// Keep a local copy for backward compatibility (there are some direct checks on this).
		$this->stats = $this->a8c_mc_stats_instance->get_current_stats();
	}

	/**
	 * Load stats pixels. $group is auto-prefixed with "x_jetpack-"
	 *
	 * @param string $method Used to check if method is "server-side".
	 */
	public function do_stats( $method = '' ) {
		$this->initialize_stats();
		if ( 'server_side' === $method ) {
			$this->a8c_mc_stats_instance->do_server_side_stats();
		} else {
			$this->a8c_mc_stats_instance->do_stats();
		}

		// Keep a local copy for backward compatibility (there are some direct checks on this).
		$this->stats = array();
	}

	/**
	 * Runs stats code for a one-off, server-side.
	 *
	 * @param array|string $args The arguments to append to the URL. Should include `x_jetpack-{$group}={$stats}` or whatever we want to store.
	 *
	 * @return bool If it worked.
	 */
	public static function do_server_side_stat( $args ) {
		$url                   = self::build_stats_url( $args );
		$a8c_mc_stats_instance = new Automattic\Jetpack\A8c_Mc_Stats();
		return $a8c_mc_stats_instance->do_server_side_stat( $url );
	}

	/**
	 * Builds the stats url.
	 *
	 * @param array|string $args The arguments to append to the URL.
	 *
	 * @return string The URL to be pinged.
	 */
	public static function build_stats_url( $args ) {

		$a8c_mc_stats_instance = new Automattic\Jetpack\A8c_Mc_Stats();
		return $a8c_mc_stats_instance->build_stats_url( $args );
	}

	/**
	 * Builds a URL to the Jetpack connection auth page
	 *
	 * @since 3.9.5
	 *
	 * @param bool        $raw If true, URL will not be escaped.
	 * @param bool|string $redirect If true, will redirect back to Jetpack wp-admin landing page after connection.
	 *                              If string, will be a custom redirect.
	 * @param bool|string $from If not false, adds 'from=$from' param to the connect URL.
	 * @param bool        $register If true, will generate a register URL regardless of the existing token, since 4.9.0.
	 *
	 * @return string Connect URL
	 */
	public function build_connect_url( $raw = false, $redirect = false, $from = false, $register = false ) {
		$site_id    = Jetpack_Options::get_option( 'id' );
		$blog_token = ( new Tokens() )->get_access_token();

		if ( $register || ! $blog_token || ! $site_id ) {
			$url = self::nonce_url_no_esc( self::admin_url( 'action=register' ), 'jetpack-register' );

			if ( ! empty( $redirect ) ) {
				$url = add_query_arg(
					'redirect',
					rawurlencode( wp_validate_redirect( esc_url_raw( $redirect ) ) ),
					$url
				);
			}

			if ( is_network_admin() ) {
				$url = add_query_arg( 'is_multisite', network_admin_url( 'admin.php?page=jetpack-settings' ), $url );
			}

			$calypso_env = ( new Host() )->get_calypso_env();

			if ( ! empty( $calypso_env ) ) {
				$url = add_query_arg( 'calypso_env', $calypso_env, $url );
			}
		} else {

			// Let's check the existing blog token to see if we need to re-register. We only check once per minute
			// because otherwise this logic can get us in to a loop.
			$last_connect_url_check = (int) Jetpack_Options::get_raw_option( 'jetpack_last_connect_url_check' );
			if ( ! $last_connect_url_check || ( time() - $last_connect_url_check ) > MINUTE_IN_SECONDS ) {
				Jetpack_Options::update_raw_option( 'jetpack_last_connect_url_check', time() );

				$response = Client::wpcom_json_api_request_as_blog(
					sprintf( '/sites/%d', $site_id ) . '?force=wpcom',
					'1.1'
				);

				if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {

					// Generating a register URL instead to refresh the existing token.
					return $this->build_connect_url( $raw, $redirect, $from, true );
				}
			}

			$url = ( new Authorize_Redirect( static::connection() ) )->build_authorize_url( $redirect );
		}

		if ( $from ) {
			$url = add_query_arg( 'from', $from, $url );
		}

		$url = $raw ? esc_url_raw( $url ) : esc_url( $url );
		/**
		 * Filter the URL used when connecting a user to a WordPress.com account.
		 *
		 * @since 8.1.0
		 *
		 * @param string $url Connection URL.
		 * @param bool   $raw If true, URL will not be escaped.
		 */
		return apply_filters( 'jetpack_build_connection_url', $url, $raw );
	}

	/**
	 * Create the Jetpack authorization URL.
	 *
	 * @param bool|string $redirect URL to redirect to.
	 * @param null        $deprecated Deprecated since Jetpack 10.9.
	 *
	 * @todo Update default value for redirect since the called function expects a string.
	 *
	 * @deprecated 13.4
	 *
	 * @return mixed|void
	 */
	public static function build_authorize_url( $redirect = false, $deprecated = null ) { // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Authorize_Redirect::build_authorize_url' );

		return ( new Authorize_Redirect( static::connection() ) )->build_authorize_url( $redirect );
	}

	/**
	 * Filters the connection URL parameter array.
	 *
	 * @deprecated 13.4
	 *
	 * @param array $args default URL parameters used by the package.
	 * @return array the modified URL arguments array.
	 */
	public static function filter_connect_request_body( $args ) {
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Authorize_Redirect::filter_connect_request_body' );

		return Authorize_Redirect::filter_connect_request_body( $args );
	}

	/**
	 * Filters the `jetpack/v4/connection/data` API response of the Connection package in order to
	 * add Jetpack-the-plugin related permissions.
	 *
	 * @since 10.0
	 *
	 * @param array $current_user_connection_data An array containing the current user connection data.
	 * @return array
	 */
	public static function filter_jetpack_current_user_connection_data( $current_user_connection_data ) {
		$jetpack_permissions = array(
			'admin_page'         => current_user_can( 'jetpack_admin_page' ),
			'manage_modules'     => current_user_can( 'jetpack_manage_modules' ),
			'network_admin'      => current_user_can( 'jetpack_network_admin_page' ),
			'network_sites_page' => current_user_can( 'jetpack_network_sites_page' ),
			'edit_posts'         => current_user_can( 'edit_posts' ),
			'publish_posts'      => current_user_can( 'publish_posts' ),
			'manage_options'     => current_user_can( 'manage_options' ),
			'view_stats'         => current_user_can( 'view_stats' ),
			'manage_plugins'     => current_user_can( 'install_plugins' )
									&& current_user_can( 'activate_plugins' )
									&& current_user_can( 'update_plugins' )
									&& current_user_can( 'delete_plugins' ),
		);

		if ( isset( $current_user_connection_data['permissions'] ) &&
			is_array( $current_user_connection_data['permissions'] ) ) {
				$current_user_connection_data['permissions'] = array_merge( $current_user_connection_data['permissions'], $jetpack_permissions );
		} else {
			$current_user_connection_data['permissions'] = $jetpack_permissions;
		}

		return $current_user_connection_data;
	}

	/**
	 * Filters the redirection URL that is used for connect requests. The redirect
	 * URL should return the user back to the Jetpack console.
	 *
	 * @deprecated 13.4
	 *
	 * @param String $redirect the default redirect URL used by the package.
	 * @return String the modified URL.
	 */
	public static function filter_connect_redirect_url( $redirect ) {
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Authorize_Redirect::filter_connect_redirect_url' );
		return Authorize_Redirect::filter_connect_redirect_url( $redirect );
	}

	/**
	 * This action fires at the beginning of the Manager::authorize method.
	 */
	public static function authorize_starting() {
		$jetpack_unique_connection = Jetpack_Options::get_option( 'unique_connection' );
		// Checking if site has been active/connected previously before recording unique connection.
		if ( ! $jetpack_unique_connection ) {
			// jetpack_unique_connection option has never been set.
			$jetpack_unique_connection = array(
				'connected'    => 0,
				'disconnected' => 0,
				'version'      => '3.6.1',
			);

			update_option( 'jetpack_unique_connection', $jetpack_unique_connection );

			// Track unique connection.
			$jetpack = self::init();

			$jetpack->stat( 'connections', 'unique-connection' );
			$jetpack->do_stats( 'server_side' );
		}

		// Increment number of times connected.
		$jetpack_unique_connection['connected'] += 1;
		Jetpack_Options::update_option( 'unique_connection', $jetpack_unique_connection );
	}

	/**
	 * This action fires when the site is registered (connected at a site level).
	 */
	public function handle_unique_registrations_stats() {
		$jetpack_unique_registrations = Jetpack_Options::get_option( 'unique_registrations' );
		// Checking if site has been registered previously before recording unique connection.
		if ( ! $jetpack_unique_registrations ) {

			$jetpack_unique_registrations = 0;

			$this->stat( 'connections', 'unique-registrations' );
			$this->do_stats( 'server_side' );
		}

		// Increment number of times connected.
		++$jetpack_unique_registrations;
		Jetpack_Options::update_option( 'unique_registrations', $jetpack_unique_registrations );
	}

	/**
	 * This action fires at the end of the Manager::authorize method when a secondary user is
	 * linked.
	 */
	public static function authorize_ending_linked() {
		// Don't activate anything since we are just connecting a user.
		self::state( 'message', 'linked' );
	}

	/**
	 * This action fires at the end of the Manager::authorize method when the master user is
	 * authorized.
	 *
	 * @param array $data The request data.
	 */
	public static function authorize_ending_authorized( $data ) {
		// If redirect_uri is SSO, ensure SSO module is enabled.
		parse_str( wp_parse_url( $data['redirect_uri'], PHP_URL_QUERY ), $redirect_options );

		/** This filter is documented in class.jetpack-cli.php */
		$jetpack_start_enable_sso = apply_filters( 'jetpack_start_enable_sso', true );

		$activate_sso = (
			isset( $redirect_options['action'] ) &&
			'jetpack-sso' === $redirect_options['action'] &&
			$jetpack_start_enable_sso
		);

		$do_redirect_on_error = ( 'client' === $data['auth_type'] );

		self::handle_post_authorization_actions( $activate_sso, $do_redirect_on_error );
	}

	/**
	 * Fires on the jetpack_site_registered hook and acitvates default modules
	 */
	public static function activate_default_modules_on_site_register() {
		self::handle_default_module_activation( false );

		// Since this is a fresh connection, be sure to clear out IDC options.
		Identity_Crisis::clear_all_idc_options();
	}

	/**
	 * This action fires at the end of the REST_Connector connection_reconnect method when the
	 * reconnect process is completed.
	 * Note that this currently only happens when we don't need the user to re-authorize
	 * their WP.com account, eg in cases where we are restoring a connection with
	 * unhealthy blog token.
	 */
	public static function reconnection_completed() {
		self::state( 'message', 'reconnection_completed' );
	}

	/**
	 * Apply activation source to a query string array.
	 *
	 * @param array $args Args used for a query string.
	 *
	 * @return void
	 */
	public static function apply_activation_source_to_args( &$args ) {
		list( $activation_source_name, $activation_source_keyword ) = get_option( 'jetpack_activation_source' );

		if ( $activation_source_name ) {
			$args['_as'] = rawurlencode( $activation_source_name );
		}

		if ( $activation_source_keyword ) {
			$args['_ak'] = rawurlencode( $activation_source_keyword );
		}
	}

	/**
	 * Returns the reconnection URL.
	 *
	 * @param bool $raw True to return an unescaped URL. False returns value after `esc_url`.
	 *
	 * @return string|null
	 */
	public function build_reconnect_url( $raw = false ) {
		$url = wp_nonce_url( self::admin_url( 'action=reconnect' ), 'jetpack-reconnect' );
		return $raw ? $url : esc_url( $url );
	}

	/**
	 * Jetpack Admin URL.
	 *
	 * @param array $args Query string args.
	 *
	 * @return string Jetpack admin URL.
	 */
	public static function admin_url( $args = null ) {
		return ( new Paths() )->admin_url( $args );
	}

	/**
	 * Creates a nonce from an URL.
	 *
	 * @param string $actionurl URL for action.
	 * @param string $action Nonce action.
	 * @param string $name Query arg name.
	 *
	 * @return string
	 */
	public static function nonce_url_no_esc( $actionurl, $action = -1, $name = '_wpnonce' ) {
		$actionurl = str_replace( '&amp;', '&', $actionurl );
		return add_query_arg( $name, wp_create_nonce( $action ), $actionurl );
	}

	/**
	 * Dismiss Jetpack notices.
	 *
	 * @return void
	 */
	public function dismiss_jetpack_notice() {
		if ( ! isset( $_GET['jetpack-notice'] ) ) {
			return;
		}

		switch ( $_GET['jetpack-notice'] ) {
			case 'dismiss':
				if ( check_admin_referer( 'jetpack-deactivate' ) && ! is_plugin_active_for_network( plugin_basename( JETPACK__PLUGIN_DIR . 'jetpack.php' ) ) ) {

					require_once ABSPATH . 'wp-admin/includes/plugin.php';
					deactivate_plugins( JETPACK__PLUGIN_DIR . 'jetpack.php', false, false );
					wp_safe_redirect( admin_url() . 'plugins.php?deactivate=true&plugin_status=all&paged=1&s=' );
				}
				break;
		}
	}

	/**
	 * Determines which module has a higher sort order.
	 *
	 * @param array $a Modules array.
	 * @param array $b Modules array.
	 *
	 * @return int 0 if the same sort or (+/-) to indicate which is greater.
	 */
	public static function sort_modules( $a, $b ) {
		return $a['sort'] <=> $b['sort'];
	}

	/**
	 * Recheck SSL status for use via an AJAX call.
	 *
	 * Sends data back via `wp_send_json`.
	 *
	 * @return void
	 */
	public function ajax_recheck_ssl() {
		check_ajax_referer( 'recheck-ssl', 'ajax-nonce' );
		$result = self::permit_ssl( true );
		wp_send_json(
			array(
				'enabled' => $result,
				'message' => self::get_ssl_test_message(),
			),
			null, // @phan-suppress-current-line PhanTypeMismatchArgumentProbablyReal -- It takes null, but its phpdoc only says int.
			JSON_UNESCAPED_SLASHES
		);
	}

	/* Client API */

	/**
	 * Verify the onboarding token.
	 *
	 * @deprecated since 13.9
	 *
	 * @param array  $token_data Token data.
	 * @param string $token Token value.
	 * @param string $request_data JSON-encoded request data.
	 *
	 * @return mixed
	 */
	public static function verify_onboarding_token( $token_data, $token, $request_data ) {
		_deprecated_function( __METHOD__, '13.9' );
		// Default to a blog token.
		$token_type = 'blog';

		// Let's see if this is onboarding. In such case, use user token type and the provided user id.
		if ( isset( $request_data ) || ! empty( $_GET['onboarding'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- no site changes, if caller is changing the site the nonce should be verified there.
			if ( ! empty( $_GET['onboarding'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- no site changes.
				$jpo = $_GET; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- no site changes.
			} else {
				$jpo = json_decode( $request_data, true );
			}

			$jpo_token = ! empty( $jpo['onboarding']['token'] ) ? $jpo['onboarding']['token'] : null;
			$jpo_user  = ! empty( $jpo['onboarding']['jpUser'] ) ? $jpo['onboarding']['jpUser'] : null;

			if (
				isset( $jpo_user )
				&& isset( $jpo_token )
				&& is_email( $jpo_user )
				&& ctype_alnum( $jpo_token )
				&& isset( $_GET['rest_route'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- no site changes.
				&& self::validate_onboarding_token_action(
					$jpo_token,
					wp_unslash( $_GET['rest_route'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- no site changes.
				)
			) {
				$jp_user = get_user_by( 'email', $jpo_user );
				if ( is_a( $jp_user, 'WP_User' ) ) {
					wp_set_current_user( $jp_user->ID );
					$user_can = is_multisite()
						? current_user_can_for_site( get_current_blog_id(), 'manage_options' )
						: current_user_can( 'manage_options' );
					if ( $user_can ) {
						$token_type              = 'user';
						$token->external_user_id = $jp_user->ID;
					}
				}
			}

			$token_data['type']    = $token_type;
			$token_data['user_id'] = $token->external_user_id;
		}

		return $token_data;
	}

	/**
	 * Create a random secret for validating onboarding payload
	 *
	 * @deprecated since 13.9
	 * @return string Secret token
	 */
	public static function create_onboarding_token() {
		_deprecated_function( __METHOD__, '13.9' );
		$token = Jetpack_Options::get_option( 'onboarding' );
		if ( false === ( $token ) ) {
			$token = wp_generate_password( 32, false );
			Jetpack_Options::update_option( 'onboarding', $token );
		}

		return $token;
	}

	/**
	 * Remove the onboarding token
	 *
	 * @deprecated since 13.9
	 * @return bool True on success, false on failure
	 */
	public static function invalidate_onboarding_token() {
		_deprecated_function( __METHOD__, '13.9' );
		return Jetpack_Options::delete_option( 'onboarding' );
	}

	/**
	 * Validate an onboarding token for a specific action
	 *
	 * @deprecated since 13.9
	 *
	 * @param string $token Onboarding token.
	 * @param string $action Action name.
	 *
	 * @return boolean True if token/action pair is accepted, false if not
	 */
	public static function validate_onboarding_token_action( $token, $action ) {
		_deprecated_function( __METHOD__, '13.9' );
		// Compare tokens, bail if tokens do not match.
		if ( ! hash_equals( $token, Jetpack_Options::get_option( 'onboarding' ) ) ) {
			return false;
		}

		// List of valid actions we can take.
		$valid_actions = array(
			'/jetpack/v4/settings',
		);

		// Only allow valid actions.
		if ( ! in_array( $action, $valid_actions, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Checks to see if the URL is using SSL to connect with Jetpack
	 *
	 * @param bool $force_recheck Force SSL recheck.
	 *
	 * @return boolean
	 * @since 2.3.3
	 */
	public static function permit_ssl( $force_recheck = false ) {
		if ( ! method_exists( Heartbeat::class, 'permit_ssl' ) ) {
			// Skip the SSL-fail notice when the check cannot run.
			return true;
		}

		return Heartbeat::permit_ssl( $force_recheck );
	}

	/**
	 * Returns a localized message describing the last SSL connectivity failure, if any.
	 *
	 * The Connection package's canonical SSL check stores a neutral reason code; this maps it to
	 * a translated, `jetpack`-domain message for display in the admin notice and AJAX recheck.
	 *
	 * @since 16.1
	 *
	 * @return string The localized message, or an empty string when there is no failure.
	 */
	public static function get_ssl_test_message() {
		if ( ! method_exists( Heartbeat::class, 'get_ssl_test_error' ) ) {
			return '';
		}

		$error = Heartbeat::get_ssl_test_error();

		switch ( $error['code'] ) {
			case 'no_ssl_support':
				return __( 'WordPress reports no SSL support', 'jetpack' );
			case 'bad_response':
				return __( 'Response was not OK: ', 'jetpack' ) . $error['detail'];
			default:
				return '';
		}
	}

	/**
	 * Displays an admin_notice, alerting the user that outbound SSL isn't working.
	 */
	public function alert_auto_ssl_fail() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$ajax_nonce = wp_create_nonce( 'recheck-ssl' );
		?>

		<div id="jetpack-ssl-warning" class="error jp-identity-crisis">
			<div class="jp-banner__content">
				<h2><?php esc_html_e( 'Outbound HTTPS not working', 'jetpack' ); ?></h2>
				<p><?php esc_html_e( 'Your site could not connect to WordPress.com via HTTPS. This could be due to any number of reasons, including faulty SSL certificates, misconfigured or missing SSL libraries, or network issues.', 'jetpack' ); ?></p>
				<p>
					<?php esc_html_e( 'Jetpack will re-test for HTTPS support once a day, but you can click here to try again immediately: ', 'jetpack' ); ?>
					<a href="#" id="jetpack-recheck-ssl-button"><?php esc_html_e( 'Try again', 'jetpack' ); ?></a>
					<span id="jetpack-recheck-ssl-output"><?php echo esc_html( self::get_ssl_test_message() ); ?></span>
				</p>
				<p>
					<?php
					printf(
							/* translators: Both are URLs. First for the connection debug tool and the second for a support page. */
						__( 'For more help, try our <a href="%1$s">connection debugger</a> or <a href="%2$s" target="_blank">troubleshooting tips</a>.', 'jetpack' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- we're building known HTML.
						esc_url( self::admin_url( array( 'page' => 'jetpack-debugger' ) ) ),
						esc_url( Redirect::get_url( 'jetpack-support-getting-started-troubleshooting-tips' ) )
					);
					?>
				</p>
			</div>
		</div>
		<style>
			#jetpack-recheck-ssl-output { margin-left: 5px; color: red; }
		</style>
		<script type="text/javascript">
			jQuery( document ).ready( function( $ ) {
				$( '#jetpack-recheck-ssl-button' ).click( function( e ) {
					var $this = $( this );
					$this.html( <?php echo wp_json_encode( esc_html__( 'Checking', 'jetpack' ), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?> );
					$( '#jetpack-recheck-ssl-output' ).html( '' );
					e.preventDefault();
					var data = { action: 'jetpack-recheck-ssl', 'ajax-nonce': <?php echo wp_json_encode( $ajax_nonce, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?> };
					$.post( ajaxurl, data )
					.done( function( response ) {
						if ( response.enabled ) {
							$( '#jetpack-ssl-warning' ).hide();
						} else {
							this.html( <?php echo wp_json_encode( esc_html__( 'Try again', 'jetpack' ), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?> );
							$( '#jetpack-recheck-ssl-output' ).html( 'SSL Failed: ' + response.message );
						}
					}.bind( $this ) );
				} );
			} );
		</script>

		<?php
	}

	/**
	 * Returns the connection manager object.
	 *
	 * @return Automattic\Jetpack\Connection\Manager
	 */
	public static function connection() {
		$jetpack = static::init();

		// If the connection manager hasn't been instantiated, do that now.
		if ( ! $jetpack->connection_manager ) {
			$jetpack->connection_manager = new Connection_Manager( 'jetpack' );
		}

		return $jetpack->connection_manager;
	}

	/**
	 * Get verification secrets.
	 *
	 * @param string $action Action name.
	 * @param int    $user_id User ID.
	 *
	 * @return array|string|WP_Error
	 */
	public static function get_secrets( $action, $user_id ) {
		$secrets = ( new Secrets() )->get( $action, $user_id );

		if ( Secrets::SECRETS_MISSING === $secrets ) {
			return new WP_Error( 'verify_secrets_missing', 'Verification secrets not found' );
		}

		if ( Secrets::SECRETS_EXPIRED === $secrets ) {
			return new WP_Error( 'verify_secrets_expired', 'Verification took too long' );
		}

		return $secrets;
	}

	/**
	 * Filters the token request body to include tracking properties.
	 *
	 * @param array $properties Token request properties.
	 *
	 * @return array amended properties.
	 */
	public static function filter_token_request_body( $properties ) {
		$tracking        = new Tracking();
		$tracks_identity = $tracking->tracks_get_identity( get_current_user_id() );

		return array_merge(
			$properties,
			array(
				'_ui' => $tracks_identity['_ui'],
				'_ut' => $tracks_identity['_ut'],
			)
		);
	}

	/**
	 * If the db version is showing something other that what we've got now, bump it to current.
	 *
	 * @return bool True if the option was incorrect and updated, false if nothing happened.
	 */
	public static function maybe_set_version_option() {
		list( $version ) = explode( ':', Jetpack_Options::get_option( 'version' ) );
		if ( JETPACK__VERSION !== $version ) {
			Jetpack_Options::update_option( 'version', JETPACK__VERSION . ':' . time() );

			if ( version_compare( JETPACK__VERSION, $version, '>' ) ) {
				/** This action is documented in class.jetpack.php */
				do_action( 'updating_jetpack_version', JETPACK__VERSION, $version );
			}

			return true;
		}
		return false;
	}

	/* Client Server API */

	/**
	 * State is passed via cookies from one request to the next, but never to subsequent requests.
	 * SET: state( $key, $value );
	 * GET: $value = state( $key );
	 *
	 * @param string $key State key.
	 * @param string $value Value.
	 * @param bool   $restate Reset the cookie (private).
	 */
	public static function state( $key = null, $value = null, $restate = false ) {
		return ( new CookieState() )->state( $key, $value, $restate );
	}

	/**
	 * Set an empty state.
	 *
	 * @return void
	 */
	public static function restate() {
		self::state( null, null, true );
	}

	/**
	 * Determines whether the jetpackState[$key] value should be added to the
	 * cookie.
	 *
	 * @param string $key The state key.
	 *
	 * @return boolean Whether the value should be added to the cookie.
	 */
	public static function should_set_cookie( $key ) {
		return ( new CookieState() )->should_set_cookie( $key );
	}

	/**
	 * Check if site is publicly accessible.
	 *
	 * @param string $file Module file.
	 *
	 * @return void
	 */
	public static function check_privacy( $file ) {
		static $is_site_publicly_accessible = null;

		if ( $is_site_publicly_accessible === null ) {
			$is_site_publicly_accessible = false;

			$rpc = new Jetpack_IXR_Client();

			$success = $rpc->query( 'jetpack.isSitePubliclyAccessible', home_url() );
			if ( $success ) {
				$response = $rpc->getResponse();
				if ( $response ) {
					$is_site_publicly_accessible = true;
				}
			}

			Jetpack_Options::update_option( 'public', (int) $is_site_publicly_accessible );
		}

		if ( $is_site_publicly_accessible ) {
			return;
		}

		$module_slug = self::get_module_slug( $file );

		$privacy_checks = self::state( 'privacy_checks' );
		if ( ! $privacy_checks ) {
			$privacy_checks = $module_slug;
		} else {
			$privacy_checks .= ",$module_slug";
		}

		self::state( 'privacy_checks', $privacy_checks );
	}

	/* JSON API Authorization */

	/**
	 * Handles the login action for Authorizing the JSON API
	 */
	public function login_form_json_api_authorization() {
		$authorize_json_api = new Authorize_Json_Api();
		$authorize_json_api->verify_json_api_authorization_request();

		add_action( 'wp_login', array( $authorize_json_api, 'store_json_api_authorization_token' ), 10, 2 );

		add_action( 'login_message', array( $authorize_json_api, 'login_message_json_api_authorization' ) );
		add_action( 'login_form', array( $this, 'preserve_action_in_login_form_for_json_api_authorization' ) );
		add_filter( 'site_url', array( $this, 'post_login_form_to_signed_url' ), 10, 3 );
	}

	/**
	 * Make sure the login form is POSTed to the signed URL so we can reverify the request.
	 *
	 * @param string $url Redirect URL.
	 * @param string $path Path.
	 * @param string $scheme URL Scheme.
	 */
	public function post_login_form_to_signed_url( $url, $path, $scheme ) {
		if ( 'wp-login.php' !== $path || ( 'login_post' !== $scheme && 'login' !== $scheme ) ) {
			return $url;
		}
		$query_string = isset( $_SERVER['QUERY_STRING'] ) ? wp_unslash( $_SERVER['QUERY_STRING'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$parsed_url   = wp_parse_url( $url );
		$url          = strtok( $url, '?' );
		$url          = "$url?{$query_string}";
		if ( ! empty( $parsed_url['query'] ) ) {
			$url .= "&{$parsed_url['query']}";
		}

		return $url;
	}

	/**
	 * Make sure the POSTed request is handled by the same action.
	 */
	public function preserve_action_in_login_form_for_json_api_authorization() {
		$http_host   = isset( $_SERVER['HTTP_HOST'] ) ? wp_unslash( $_SERVER['HTTP_HOST'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- escaped with esc_url below.
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- escaped with esc_url below.
		echo "<input type='hidden' name='action' value='jetpack_json_api_authorization' />\n";
		echo "<input type='hidden' name='jetpack_json_api_original_query' value='" . esc_url( set_url_scheme( $http_host . $request_uri ) ) . "' />\n";
	}

	/**
	 * If someone logs in to approve API access, store the Access Code in usermeta.
	 *
	 * @deprecated 13.4
	 *
	 * @param string  $user_login Unused.
	 * @param WP_User $user User logged in.
	 */
	public function store_json_api_authorization_token( $user_login, $user ) {
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Automattic\\Jetpack\\Connection\\Authorize_Json_Api::store_json_api_authorization_token' );

		return ( new Authorize_Json_Api() )->store_json_api_authorization_token( $user_login, $user );
	}

	/**
	 * Add public-api.wordpress.com to the safe redirect allowed list - only added when someone allows API access.
	 *
	 * To be used with a filter of allowed domains for a redirect.
	 *
	 * @deprecated 13.4
	 *
	 * @param array $domains Allowed WP.com Environments.
	 */
	public function allow_wpcom_public_api_domain( $domains ) {
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Automattic\\Jetpack\\Status\\Host::allow_wpcom_public_api_domain' );

		return Host::allow_wpcom_public_api_domain( $domains );
	}

	/**
	 * Check if the redirect is encoded.
	 *
	 * @deprecated 13.4
	 *
	 * @param string $redirect_url Redirect URL.
	 *
	 * @return bool If redirect has been encoded.
	 */
	public static function is_redirect_encoded( $redirect_url ) {
		_deprecated_function( __METHOD__, 'jetpack-13.4' );
		return preg_match( '/https?%3A%2F%2F/i', $redirect_url ) > 0;
	}

	/**
	 * Add all wordpress.com environments to the safe redirect allowed list.
	 *
	 * To be used with a filter of allowed domains for a redirect.
	 *
	 * @param array $domains Allowed WP.com Environments.
	 *
	 * @deprecated since 11.1
	 */
	public function allow_wpcom_environments( $domains ) {
		return Host::allow_wpcom_environments( $domains );
	}

	/**
	 * Add the Access Code details to the public-api.wordpress.com redirect.
	 *
	 * @deprecated 13.4
	 *
	 * @param string  $redirect_to URL.
	 * @param string  $original_redirect_to URL.
	 * @param WP_User $user WP_User for the redirect.
	 *
	 * @return string
	 */
	public function add_token_to_login_redirect_json_api_authorization( $redirect_to, $original_redirect_to, $user ) {
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Automattic\\Jetpack\\Connection\\Authorize_Json_Api::add_token_to_login_redirect_json_api_authorization' );

		return ( new Authorize_Json_Api() )->add_token_to_login_redirect_json_api_authorization( $redirect_to, $original_redirect_to, $user );
	}

	/**
	 * Verifies the request by checking the signature
	 *
	 * @deprecated 13.4
	 *
	 * @since 4.6.0 Method was updated to use `$_REQUEST` instead of `$_GET` and `$_POST`. Method also updated to allow
	 * passing in an `$environment` argument that overrides `$_REQUEST`. This was useful for integrating with SSO.
	 *
	 * @param null|array $environment Value to override $_REQUEST.
	 */
	public function verify_json_api_authorization_request( $environment = null ) {
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Automattic\\Jetpack\\Connection\\Authorize_Json_Api::verify_json_api_authorization_request' );

		return ( new Authorize_Json_Api() )->verify_json_api_authorization_request( $environment );
	}

	/**
	 * HTML for the JSON API authorization notice.
	 *
	 * @deprecated 13.4
	 *
	 * @return string
	 */
	public function login_message_json_api_authorization() {
		_deprecated_function( __METHOD__, 'jetpack-13.4', 'Automattic\\Jetpack\\Connection\\Authorize_Json_Api::login_message_json_api_authorization' );

		return ( new Authorize_Json_Api() )->login_message_json_api_authorization();
	}

	/**
	 * Get $content_width, but with a <s>twist</s> filter.
	 */
	public static function get_content_width() {
		$content_width = ( isset( $GLOBALS['content_width'] ) && is_numeric( $GLOBALS['content_width'] ) )
			? $GLOBALS['content_width']
			: false;
		/**
		 * Filter the Content Width value.
		 *
		 * @since 2.2.3
		 *
		 * @param string $content_width Content Width value.
		 */
		return apply_filters( 'jetpack_content_width', $content_width );
	}

	/**
	 * Pings the WordPress.com Mirror Site for the specified options.
	 *
	 * @param string|array $option_names The option names to request from the WordPress.com Mirror Site.
	 *
	 * @return array An associative array of the option values as stored in the WordPress.com Mirror Site
	 */
	public function get_cloud_site_options( $option_names ) {
		$option_names = array_filter( (array) $option_names, 'is_string' );

		$xml = new Jetpack_IXR_Client();
		$xml->query( 'jetpack.fetchSiteOptions', $option_names );
		if ( $xml->isError() ) {
			return array(
				'error_code' => $xml->getErrorCode(),
				'error_msg'  => $xml->getErrorMessage(),
			);
		}
		$cloud_site_options = $xml->getResponse();

		return $cloud_site_options;
	}

	/**
	 * Checks if the site is currently in an identity crisis.
	 *
	 * Now delegates to the Connection package so this matches what the heartbeat itself reports.
	 * Note the package guards on `Connection\Manager::is_connected()` where this used to guard on
	 * `Jetpack::is_connection_ready()`, so the `jetpack_is_connection_ready` filter no longer applies.
	 *
	 * @deprecated 16.2
	 *
	 * @return array|bool Array of options that are in a crisis, or false if everything is OK.
	 */
	public static function check_identity_crisis() {
		_deprecated_function( __METHOD__, 'jetpack-16.2', 'Automattic\\Jetpack\\Identity_Crisis::check_identity_crisis' );

		return Identity_Crisis::check_identity_crisis();
	}

	/**
	 * Normalizes a url by doing three things:
	 *  - Strips protocol
	 *  - Strips www
	 *  - Adds a trailing slash
	 *
	 * @since 4.4.0
	 * @param string $url URL.
	 * @return WP_Error|string
	 */
	public static function normalize_url_protocol_agnostic( $url ) {
		$parsed_url = wp_parse_url( trailingslashit( esc_url_raw( $url ) ) );
		if ( ! $parsed_url || empty( $parsed_url['host'] ) || empty( $parsed_url['path'] ) ) {
			/* translators: URL string */
			return new WP_Error( 'cannot_parse_url', sprintf( esc_html__( 'Cannot parse URL %s', 'jetpack' ), $url ) );
		}

		// Strip www and protocols.
		$url = preg_replace( '/^www\./i', '', $parsed_url['host'] . $parsed_url['path'] );
		return $url;
	}

	/**
	 * Maybe Use a .min.css stylesheet, maybe not.
	 *
	 * Hooks onto `plugins_url` filter at priority 1, and accepts all 3 args.
	 *
	 * @param string $url URL.
	 * @param string $path File path.
	 * @param string $plugin Plugin.
	 *
	 * @return mixed
	 */
	public static function maybe_min_asset( $url, $path, $plugin ) {
		// Short out on things trying to find actual paths.
		if ( ! $path || empty( $plugin ) ) {
			return $url;
		}

		$path = ltrim( $path, '/' );

		// Strip out the abspath.
		$base = dirname( plugin_basename( $plugin ) );

		// Short out on non-Jetpack assets.
		if ( ! str_starts_with( $base, 'jetpack/' ) ) {
			return $url;
		}

		// File name parsing.
		$file              = "{$base}/{$path}";
		$full_path         = JETPACK__PLUGIN_DIR . substr( $file, 8 );
		$file_name         = substr( $full_path, strrpos( $full_path, '/' ) + 1 );
		$file_name_parts_r = array_reverse( explode( '.', $file_name ) );
		$extension         = array_shift( $file_name_parts_r );

		if ( in_array( strtolower( $extension ), array( 'css', 'js' ), true ) ) {
			// Already pointing at the minified version.
			if ( 'min' === $file_name_parts_r[0] ) {
				return $url;
			}

			$min_full_path = preg_replace( "#\.{$extension}$#", ".min.{$extension}", $full_path );
			if ( file_exists( $min_full_path ) ) {
				$url = preg_replace( "#\.{$extension}$#", ".min.{$extension}", $url );
				// If it's a CSS file, stash it so we can set the .min suffix for rtl-ing.
				if ( 'css' === $extension ) {
					$key                      = str_replace( JETPACK__PLUGIN_DIR, 'jetpack/', $min_full_path );
					self::$min_assets[ $key ] = $path;
				}
			}
		}

		return $url;
	}

	/**
	 * If the asset is minified, let's flag .min as the suffix.
	 *
	 * Attached to `style_loader_src` filter.
	 *
	 * @param string $src source file.
	 * @param string $handle The registered handle of the script in question.
	 *
	 * @return mixed
	 */
	public static function set_suffix_on_min( $src, $handle ) {
		if ( ! is_string( $src ) || ! str_contains( $src, '.min.css' ) ) {
			return $src;
		}

		if ( ! empty( self::$min_assets ) ) {
			foreach ( self::$min_assets as $file => $path ) {
				if ( str_contains( $src, $file ) ) {
					wp_style_add_data( $handle, 'suffix', '.min' );
					return $src;
				}
			}
		}

		return $src;
	}

	/**
	 * Maybe inlines a stylesheet.
	 *
	 * @deprecated since 11.7.
	 *
	 * @param string $tag The tag that would link to the external asset.
	 * @param string $handle The registered handle of the script in question.
	 *
	 * @return string
	 */
	public static function maybe_inline_style( $tag, $handle ) { //phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
		_deprecated_function( __METHOD__, '11.7', 'wp_maybe_inline_styles' );

		return $tag;
	}

	/**
	 * Loads a view file from the views
	 *
	 * Data passed in with the $data parameter will be available in the
	 * template file as $data['value']
	 *
	 * @html-template-var array $data
	 *
	 * @param string $template - Template file to load.
	 * @param array  $data - Any data to pass along to the template.
	 * @return boolean - If template file was found.
	 **/
	public function load_view( $template, $data = array() ) { // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- This is used via the required files.
		$views_dir = JETPACK__PLUGIN_DIR . 'views/';

		if ( file_exists( $views_dir . $template ) ) {
			require_once $views_dir . $template;
			return true;
		}

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			trigger_error( sprintf( 'Jetpack: Unable to find view file: %s', esc_html( $views_dir . $template ) ), E_USER_WARNING ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_trigger_error
		}
		return false;
	}

	/**
	 * Register Jetpack-specific tests on the connection package's health test suite.
	 *
	 * @param \Automattic\Jetpack\Connection\Connection_Health_Tests $connection_tests The test suite instance.
	 */
	public function register_jetpack_connection_tests( $connection_tests ) {
		require_once JETPACK__PLUGIN_DIR . '_inc/lib/debugger/class-jetpack-cxn-tests.php';
		$jetpack_tests = new Jetpack_Cxn_Tests();
		$jetpack_tests->register_tests_on( $connection_tests );
	}

	/**
	 * Throws warnings for deprecated hooks to be removed from Jetpack that cannot remain in the original place in the code.
	 */
	public function deprecated_hooks() {
		$filter_deprecated_list = array(
			'jetpack_bail_on_shortcode'                    => array(
				'replacement' => 'jetpack_shortcodes_to_include',
				'version'     => 'jetpack-3.1.0',
			),
			'wpl_sharing_2014_1'                           => array(
				'replacement' => null,
				'version'     => 'jetpack-3.6.0',
			),
			'jetpack-tools-to-include'                     => array(
				'replacement' => 'jetpack_tools_to_include',
				'version'     => 'jetpack-3.9.0',
			),
			'jetpack_identity_crisis_options_to_check'     => array(
				'replacement' => null,
				'version'     => 'jetpack-4.0.0',
			),
			'update_option_jetpack_single_user_site'       => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'audio_player_default_colors'                  => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_featured_images_enabled'   => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_update_details'            => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_updates'                   => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_network_name'              => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_network_allow_new_registrations' => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_network_add_new_users'     => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_network_site_upload_space' => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_network_upload_file_types' => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_network_enable_administration_menus' => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_is_multi_site'             => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_is_main_network'           => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'add_option_jetpack_main_network_site'         => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'jetpack_sync_all_registered_options'          => array(
				'replacement' => null,
				'version'     => 'jetpack-4.3.0',
			),
			'jetpack_has_identity_crisis'                  => array(
				'replacement' => 'jetpack_sync_error_idc_validation',
				'version'     => 'jetpack-4.4.0',
			),
			'jetpack_is_post_mailable'                     => array(
				'replacement' => null,
				'version'     => 'jetpack-4.4.0',
			),
			'jetpack_seo_site_host'                        => array(
				'replacement' => null,
				'version'     => 'jetpack-5.1.0',
			),
			'jetpack_installed_plugin'                     => array(
				'replacement' => 'jetpack_plugin_installed',
				'version'     => 'jetpack-6.0.0',
			),
			'jetpack_holiday_snow_option_name'             => array(
				'replacement' => null,
				'version'     => 'jetpack-6.0.0',
			),
			'jetpack_holiday_chance_of_snow'               => array(
				'replacement' => null,
				'version'     => 'jetpack-6.0.0',
			),
			'jetpack_holiday_snow_js_url'                  => array(
				'replacement' => null,
				'version'     => 'jetpack-6.0.0',
			),
			'jetpack_is_holiday_snow_season'               => array(
				'replacement' => null,
				'version'     => 'jetpack-6.0.0',
			),
			'jetpack_holiday_snow_option_updated'          => array(
				'replacement' => null,
				'version'     => 'jetpack-6.0.0',
			),
			'jetpack_holiday_snowing'                      => array(
				'replacement' => null,
				'version'     => 'jetpack-6.0.0',
			),
			'jetpack_sso_auth_cookie_expirtation'          => array(
				'replacement' => 'jetpack_sso_auth_cookie_expiration',
				'version'     => 'jetpack-6.1.0',
			),
			'jetpack_cache_plans'                          => array(
				'replacement' => null,
				'version'     => 'jetpack-6.1.0',
			),
			'jetpack_enable_site_verification'             => array(
				'replacement' => null,
				'version'     => 'jetpack-6.5.0',
			),
			'can_display_jetpack_manage_notice'            => array(
				'replacement' => null,
				'version'     => 'jetpack-7.3.0',
			),
			'atd_http_post_timeout'                        => array(
				'replacement' => null,
				'version'     => 'jetpack-7.3.0',
			),
			'atd_service_domain'                           => array(
				'replacement' => null,
				'version'     => 'jetpack-7.3.0',
			),
			'atd_load_scripts'                             => array(
				'replacement' => null,
				'version'     => 'jetpack-7.3.0',
			),
			'jetpack_widget_authors_exclude'               => array(
				'replacement' => 'jetpack_widget_authors_params',
				'version'     => 'jetpack-7.7.0',
			),
			// Removed in Jetpack 7.9.0.
			'jetpack_pwa_manifest'                         => array(
				'replacement' => null,
				'version'     => 'jetpack-7.9.0',
			),
			'jetpack_pwa_background_color'                 => array(
				'replacement' => null,
				'version'     => 'jetpack-7.9.0',
			),
			'jetpack_check_mobile'                         => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'jetpack_mobile_stylesheet'                    => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'jetpack_mobile_template'                      => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'jetpack_mobile_theme_menu'                    => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'minileven_show_featured_images'               => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'minileven_attachment_size'                    => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'instagram_cache_oembed_api_response_body'     => array(
				'replacement' => null,
				'version'     => 'jetpack-9.1.0',
			),
			'jetpack_can_make_outbound_https'              => array(
				'replacement' => null,
				'version'     => 'jetpack-9.1.0',
			),
			'sharing_email_can_send'                       => array(
				'replacement' => null,
				'version'     => 'jetpack-11.0.0',
			),
			'sharing_email_check'                          => array(
				'replacement' => null,
				'version'     => 'jetpack-11.0.0',
			),
			'sharing_services_email'                       => array(
				'replacement' => null,
				'version'     => 'jetpack-11.0.0',
			),
			'jetpack_dsp_promote_posts_enabled'            => array(
				'replacement' => null,
				'version'     => 'jetpack-11.8.0',
			),
			'jetpack_are_blogging_prompts_enabled'         => array(
				'replacement' => null,
				'version'     => 'jetpack-11.8.0',
			),
			'jetpack_subscriptions_modal_enabled'          => array(
				'replacement' => null,
				'version'     => 'jetpack-12.7.0',
			),
			'jetpack_pre_connection_prompt_helpers'        => array(
				'replacement' => null,
				'version'     => 'jetpack-13.2.0',
			),
			'jetpack_contact_form_use_package'             => array(
				'replacement' => null,
				'version'     => 'jetpack-13.4.0',
			),
			// jetpack_implode_frontend_css has been removed, but is not listed here. The updated behavior is exactly the only use of the filter.
			// We can reassess formally deprecating it here later; for now, it would be noise with no functional difference.
		);

		foreach ( $filter_deprecated_list as $tag => $args ) {
			if ( has_filter( $tag ) ) {
				apply_filters_deprecated( $tag, array( null ), $args['version'], $args['replacement'] );
			}
		}

		$action_deprecated_list = array(
			'jetpack_updated_theme'        => array(
				'replacement' => 'jetpack_updated_themes',
				'version'     => 'jetpack-6.2.0',
			),
			'atd_http_post_error'          => array(
				'replacement' => null,
				'version'     => 'jetpack-7.3.0',
			),
			'mobile_reject_mobile'         => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'mobile_force_mobile'          => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'mobile_app_promo_download'    => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'mobile_setup'                 => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'jetpack_mobile_footer_before' => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'wp_mobile_theme_footer'       => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'minileven_credits'            => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'jetpack_mobile_header_before' => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'jetpack_mobile_header_after'  => array(
				'replacement' => null,
				'version'     => 'jetpack-8.3.0',
			),
			'sharing_email_dialog'         => array(
				'replacement' => null,
				'version'     => 'jetpack-11.0.0',
			),
			'sharing_email_send_post'      => array(
				'replacement' => null,
				'version'     => 'jetpack-11.0.0',
			),
		);

		foreach ( $action_deprecated_list as $tag => $args ) {
			if ( has_action( $tag ) ) {
				do_action_deprecated( $tag, array(), $args['version'], $args['replacement'] );
			}
		}
	}

	/**
	 * Converts any url in a stylesheet, to the correct absolute url.
	 *
	 * Considerations:
	 *  - Normal, relative URLs     `feh.png`
	 *  - Data URLs                 `data:image/gif;base64,eh129ehiuehjdhsa==`
	 *  - Schema-agnostic URLs      `//domain.com/feh.png`
	 *  - Absolute URLs             `http://domain.com/feh.png`
	 *  - Domain root relative URLs `/feh.png`
	 *
	 * @param string $css The raw CSS -- should be read in directly from the file.
	 * @param string $css_file_url The URL that the file can be accessed at, for calculating paths from.
	 *
	 * @return mixed|string
	 */
	public static function absolutize_css_urls( $css, $css_file_url ) {
		$pattern = '#url\((?P<path>[^)]*)\)#i';
		$css_dir = dirname( $css_file_url );
		$p       = wp_parse_url( $css_dir );
		$domain  = sprintf(
			'%1$s//%2$s%3$s%4$s',
			isset( $p['scheme'] ) ? "{$p['scheme']}:" : '',
			isset( $p['user'], $p['pass'] ) ? "{$p['user']}:{$p['pass']}@" : '',
			$p['host'],
			isset( $p['port'] ) ? ":{$p['port']}" : ''
		);

		if ( preg_match_all( $pattern, $css, $matches, PREG_SET_ORDER ) ) {
			$replace = array();
			$find    = array();
			foreach ( $matches as $match ) {
				$url = trim( $match['path'], "'\" \t" );

				// If this is a data url, we don't want to mess with it.
				if ( str_starts_with( $url, 'data:' ) ) {
					continue;
				}

				// If this is an absolute or protocol-agnostic url,
				// we don't want to mess with it.
				if ( preg_match( '#^(https?:)?//#i', $url ) ) {
					continue;
				}

				switch ( substr( $url, 0, 1 ) ) {
					case '/':
						$absolute = $domain . $url;
						break;
					default:
						$absolute = $css_dir . '/' . $url;
				}

				$find[]    = $match[0];
				$replace[] = sprintf( 'url("%s")', $absolute );
			}
			$css = str_replace( $find, $replace, $css );
		}

		return $css;
	}

	/**
	 * Check the heartbeat data
	 *
	 * Organizes the heartbeat data by severity.  For example, if the site
	 * is in an ID crisis, it will be in the $filtered_data['bad'] array.
	 *
	 * Data will be added to "caution" array, if it either:
	 *  - Out of date Jetpack version
	 *  - Out of date WP version
	 *  - Out of date PHP version
	 *
	 * $return array $filtered_data
	 */
	public static function jetpack_check_heartbeat_data() {
		/*
		 * Site environment stats (incl. wp-version/php-version checked below) now live in the Connection package,
		 * and the IDC stat is contributed by the Connection package's `jetpack_heartbeat_stats_array` filter
		 * callback. We rebuild the stat here rather than running that filter: the filter's callbacks have side
		 * effects (Connection\Manager::add_stats_to_heartbeat() consumes and deletes the `xmlrpc_errors` option)
		 * and return non-scalar values, neither of which is appropriate for this read-only diagnostic.
		 */
		$env_stats = method_exists( Heartbeat::class, 'get_environment_stats' )
			? Heartbeat::get_environment_stats()
			: array();
		$raw_data  = array_merge(
			Jetpack_Heartbeat::generate_stats_array(),
			$env_stats,
			array( 'identitycrisis' => Identity_Crisis::check_identity_crisis() ? 'yes' : 'no' )
		);

		$good    = array();
		$caution = array();
		$bad     = array();

		foreach ( $raw_data as $stat => $value ) {

			// Check jetpack version.
			if ( 'version' === $stat ) {
				if ( version_compare( $value, JETPACK__VERSION, '<' ) ) {
					$caution[ $stat ] = $value . ' - min supported is ' . JETPACK__VERSION;
					continue;
				}
			}

			// Check WP version.
			if ( 'wp-version' === $stat ) {
				if ( version_compare( $value, JETPACK__MINIMUM_WP_VERSION, '<' ) ) {
					$caution[ $stat ] = $value . ' - min supported is ' . JETPACK__MINIMUM_WP_VERSION;
					continue;
				}
			}

			// Check PHP version.
			if ( 'php-version' === $stat ) {
				if ( version_compare( PHP_VERSION, JETPACK__MINIMUM_PHP_VERSION, '<' ) ) {
					$caution[ $stat ] = $value . ' - min supported is ' . JETPACK__MINIMUM_PHP_VERSION;
					continue;
				}
			}

			// Check ID crisis.
			if ( 'identitycrisis' === $stat ) {
				if ( 'yes' === $value ) {
					$bad[ $stat ] = $value;
					continue;
				}
			}

			// The rest are good :).
			$good[ $stat ] = $value;
		}

		$filtered_data = array(
			'good'    => $good,
			'caution' => $caution,
			'bad'     => $bad,
		);

		return $filtered_data;
	}

	/**
	 * This method is used to organize all options that can be reset
	 * without disconnecting Jetpack.
	 *
	 * It is used in class.jetpack-cli.php to reset options
	 *
	 * @since 5.4.0 Logic moved to Jetpack_Options class. Method left in Jetpack class for backwards compat.
	 *
	 * @return array of options to delete.
	 */
	public static function get_jetpack_options_for_reset() {
		return Jetpack_Options::get_options_for_reset();
	}

	/**
	 * Get the user's meta box order.
	 *
	 * @param array $sorted Value for the user's option.
	 * @return mixed
	 */
	public function get_user_option_meta_box_order_dashboard( $sorted ) {
		if ( ! is_array( $sorted ) ) {
			return $sorted;
		}

		foreach ( $sorted as $box_context => $ids ) {
			if ( ! str_contains( $ids, 'dashboard_stats' ) ) {
				// If the old id isn't anywhere in the ids, don't bother exploding and fail out.
				continue;
			}

			$ids_array = explode( ',', $ids );
			$key       = array_search( 'dashboard_stats', $ids_array, true );

			if ( false !== $key ) {
				// If we've found that exact value in the option (and not `google_dashboard_stats` for example).
				$ids_array[ $key ]      = 'jetpack_summary_widget';
				$sorted[ $box_context ] = implode( ',', $ids_array );
				// We've found it, stop searching, and just return.
				break;
			}
		}

		return $sorted;
	}
	/**
	 * Checks if Akismet is active and working.
	 *
	 * We dropped support for Akismet 3.0 with Jetpack 6.1.1 while introducing a check for an Akismet valid key
	 * that implied usage of methods present since more recent version.
	 * See https://github.com/Automattic/jetpack/pull/9585
	 *
	 * @since  5.1.0
	 *
	 * @return bool True = Akismet available. False = Aksimet not available.
	 */
	public static function is_akismet_active() {
		static $status = null;

		if ( $status !== null ) {
			return $status;
		}

		// Check if a modern version of Akismet is active.
		if ( ! method_exists( 'Akismet', 'http_post' ) ) {
			$status = false;
			return $status;
		}

		// Make sure there is a key known to Akismet at all before verifying key.
		$akismet_key = Akismet::get_api_key();
		if ( ! $akismet_key ) {
			$status = false;
			return $status;
		}

		// Possible values: valid, invalid, failure via Akismet. false if no status is cached.
		$akismet_key_state = get_transient( 'jetpack_akismet_key_is_valid' );

		// Do not used the cache result in wp-admin or REST API requests if the key isn't valid, in case someone is actively renewing, etc.
		$recheck = ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) && 'valid' !== $akismet_key_state;
		// We cache the result of the Akismet key verification for ten minutes.
		if ( ! $akismet_key_state || $recheck ) {
			$akismet_key_state = Akismet::verify_key( $akismet_key );
			set_transient( 'jetpack_akismet_key_is_valid', $akismet_key_state, 10 * MINUTE_IN_SECONDS );
		}

		$status = 'valid' === $akismet_key_state;

		return $status;
	}

	/**
	 * Given a minified path, and a non-minified path, will return
	 * a minified or non-minified file URL based on whether SCRIPT_DEBUG is set and truthy.
	 *
	 * Both `$min_base` and `$non_min_base` are expected to be relative to the
	 * root Jetpack directory.
	 *
	 * @since 5.6.0
	 *
	 * @param string $min_path Minimized path.
	 * @param string $non_min_path Non-minimized path.
	 * @return string The URL to the file
	 */
	public static function get_file_url_for_environment( $min_path, $non_min_path ) {
		return Assets::get_file_url_for_environment( $min_path, $non_min_path );
	}

	/**
	 * Checks for whether Jetpack Backup is enabled.
	 * Will return true if the state of Backup is anything except "unavailable".
	 *
	 * @return bool|int|mixed
	 */
	public static function is_rewind_enabled() {
		// Rewind is a paid feature, therefore requires a user-level connection.
		if ( ! static::connection()->has_connected_owner() ) {
			return false;
		}
		$rewind_enabled = get_transient( 'jetpack_rewind_enabled' );
		$recheck        = ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) && '0' === $rewind_enabled;
		if ( false === $rewind_enabled || $recheck ) {
			require_once JETPACK__PLUGIN_DIR . '_inc/lib/class.core-rest-api-endpoints.php';
			$rewind_data    = (array) Jetpack_Core_Json_Api_Endpoints::rewind_data();
			$rewind_enabled = ( ! is_wp_error( $rewind_data )
				&& ! empty( $rewind_data['state'] )
				&& 'active' === $rewind_data['state'] )
				? 1
				: 0;
			set_transient( 'jetpack_rewind_enabled', $rewind_enabled, 10 * MINUTE_IN_SECONDS );
		}
		return $rewind_enabled;
	}

	/**
	 * Return Calypso environment value; used for developing Jetpack and pairing
	 * it with different Calypso enrionments, such as localhost.
	 *
	 * @deprecated 12.4 Moved to the Status package.
	 *
	 * @return string Calypso environment
	 */
	public static function get_calypso_env() {
		_deprecated_function( __METHOD__, 'jetpack-12.4', '\Automattic\Jetpack\Status\Host->get_calypso_env' );
		return ( new Host() )->get_calypso_env();
	}

	/**
	 * Returns the hostname with protocol for Calypso.
	 * Used for developing Jetpack with Calypso.
	 *
	 * @since 8.4.0
	 *
	 * @return string Calypso host.
	 */
	public static function get_calypso_host() {
		$calypso_env = ( new Host() )->get_calypso_env();
		switch ( $calypso_env ) {
			case 'development':
				return 'http://calypso.localhost:3000/';
			case 'wpcalypso':
				return 'https://wpcalypso.wordpress.com/';
			case 'horizon':
				return 'https://horizon.wordpress.com/';
			default:
				return 'https://wordpress.com/';
		}
	}

	/**
	 * Handles activating default modules as well general cleanup for the new connection.
	 *
	 * @param boolean $activate_sso                 Whether to activate the SSO module when activating default modules.
	 * @param boolean $redirect_on_activation_error Whether to redirect on activation error.
	 * @param boolean $send_state_messages          Whether to send state messages.
	 * @return void
	 */
	public static function handle_post_authorization_actions(
		$activate_sso = false,
		$redirect_on_activation_error = false,
		$send_state_messages = true
	) {
		$other_modules = $activate_sso
			? array( 'sso' )
			: array();

		if ( Jetpack_Options::get_option( 'active_modules_initialized' ) ) {
			$active_modules = self::get_active_modules();
			self::delete_active_modules();

			self::activate_default_modules( 999, 1, array_merge( $active_modules, $other_modules ), $redirect_on_activation_error, $send_state_messages );
		} else {
			// Default modules that don't require a user were already activated on site_register.
			// This time let's activate only those that require a user, this assures we don't reactivate manually deactivated modules while the site was connected only at a site level.
			self::activate_default_modules( false, false, $other_modules, $redirect_on_activation_error, $send_state_messages, null, true );
			Jetpack_Options::update_option( 'active_modules_initialized', true );
		}

		// Since this is a fresh connection, be sure to clear out IDC options.
		Identity_Crisis::clear_all_idc_options();

		if ( $send_state_messages ) {
			self::state( 'message', 'authorized' );
		}
	}

	/**
	 * Whether UI for backups should be displayed.
	 *
	 * On WPCom platforms this is gated on the backups-self-serve site feature.
	 * On self-hosted Jetpack sites it falls back to the jetpack_show_backups filter.
	 *
	 * @return bool Should backups UI be displayed?
	 */
	public static function show_backups_ui() {
		if ( ( new \Automattic\Jetpack\Status\Host() )->is_wpcom_platform() ) {
			return function_exists( 'wpcom_site_has_feature' ) && wpcom_site_has_feature( 'backups-self-serve' );
		}

		/**
		 * Whether UI for backups should be displayed.
		 *
		 * @since 6.5.0
		 *
		 * @param bool $show_backups Should UI for backups be displayed? True by default.
		 */
		return self::is_plugin_active( 'vaultpress/vaultpress.php' ) || apply_filters( 'jetpack_show_backups', true );
	}

	/**
	 * Whether UI for security scanning should be displayed.
	 *
	 * On WPCom platforms this is gated on the scan-self-serve site feature.
	 * On self-hosted Jetpack sites it always returns true.
	 *
	 * @return bool Should scan UI be displayed?
	 */
	public static function show_scan_ui() {
		if ( ( new \Automattic\Jetpack\Status\Host() )->is_wpcom_platform() ) {
			return function_exists( 'wpcom_site_has_feature' ) && wpcom_site_has_feature( 'scan-self-serve' );
		}

		return true;
	}

	/**
	 * Clean leftoveruser meta.
	 *
	 * Delete Jetpack-related user meta when it is no longer needed.
	 *
	 * @since 7.3.0
	 *
	 * @param int $user_id User ID being updated.
	 */
	public static function user_meta_cleanup( $user_id ) {
		$meta_keys = array(
			// AtD removed from Jetpack 7.3.
			'AtD_options',
			'AtD_check_when',
			'AtD_guess_lang',
			'AtD_ignored_phrases',
		);

		foreach ( $meta_keys as $meta_key ) {
			if ( get_user_meta( $user_id, $meta_key ) ) {
				delete_user_meta( $user_id, $meta_key );
			}
		}
	}

	/**
	 * Checks if a Jetpack site is both active and not in offline mode.
	 *
	 * This is a DRY function to avoid repeating `Jetpack::is_connection_ready && ! Automattic\Jetpack\Status->is_offline_mode`.
	 *
	 * @since 8.8.0
	 *
	 * @return bool True if Jetpack is active and not in offline mode.
	 */
	public static function is_active_and_not_offline_mode() {
		if ( ! self::is_connection_ready() || ( new Status() )->is_offline_mode() ) {
			return false;
		}
		return true;
	}

	/**
	 * Returns the list of products that we have available for purchase.
	 *
	 * This method will not take current purchases or upgrades into account
	 * but is instead a static list of products Jetpack offers with some
	 * corresponding sales text/materials.
	 *
	 * @param bool $show_legacy Determine if we should include legacy product/plan details.
	 * @return array
	 */
	public static function get_products_for_purchase( $show_legacy = false ) {
		$products = array();

		$products['backup'] = array(
			'title'             => __( 'Jetpack Backup', 'jetpack' ),
			'slug'              => 'jetpack_backup_t1_yearly',
			'description'       => __( 'Never lose a word, image, page, or time worrying about your site with automated backups & one-click restores.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array( 'security' ),
			'features'          => array(
				_x( 'Real-time cloud backups', 'Backup Product Feature', 'jetpack' ),
				_x( '10GB of backup storage', 'Backup Product Feature', 'jetpack' ),
				_x( '30-day archive & activity log*', 'Backup Product Feature', 'jetpack' ),
				_x( 'One-click restores', 'Backup Product Feature', 'jetpack' ),
			),
			'disclaimer'        => array(
				'text'      => __( '* Subject to your usage and storage limit.', 'jetpack' ),
				'link_text' => __( 'Learn more', 'jetpack' ),
				'url'       => Redirect::get_url( 'jetpack-faq-backup-disclaimer' ),
			),
		);

		$products['creator'] = array(
			'title'             => __( 'Jetpack Creator', 'jetpack' ),
			'slug'              => 'jetpack_creator_yearly',
			'description'       => __( 'Craft stunning content, boost your subscriber base, and monetize your online presence.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array( 'complete' ),
			'features'          => array(
				_x( 'Unlimited subscriber imports', 'Creator Product Feature', 'jetpack' ),
				_x( 'Earn more from your content', 'Creator Product Feature', 'jetpack' ),
				_x( 'Accept payments with PayPal', 'Creator Product Feature', 'jetpack' ),
				_x( 'Increase earnings with WordAds', 'Creator Product Feature', 'jetpack' ),
			),
		);

		$products['growth'] = array(
			'title'             => __( 'Jetpack Growth', 'jetpack' ),
			'slug'              => 'jetpack_growth_yearly',
			'description'       => __( 'Essential tools to help you grow your audience, track visitor engagement, and turn leads into loyal customers and advocates.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array( 'complete' ),
			'features'          => array(
				_x( 'Jetpack Social', 'Growth Product Feature', 'jetpack' ),
				_x( 'Jetpack Stats (10K site views, upgradeable)', 'Growth Product Feature', 'jetpack' ),
				_x( 'Unlimited subscriber imports', 'Growth Product Feature', 'jetpack' ),
				_x( 'Earn more from your content', 'Growth Product Feature', 'jetpack' ),
				_x( 'Accept payments with PayPal', 'Growth Product Feature', 'jetpack' ),
				_x( 'Increase earnings with WordAds', 'Growth Product Feature', 'jetpack' ),
			),
		);

		$products['scan'] = array(
			'title'             => __( 'Jetpack Scan', 'jetpack' ),
			'slug'              => 'jetpack_scan',
			'description'       => __( 'Automatic scanning and one-click fixes keep your site one step ahead of security threats and malware.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array( 'security' ),
			'features'          => array(
				_x( 'Automated daily scanning', 'Scan Product Feature', 'jetpack' ),
				_x( 'One-click fixes for most issues', 'Scan Product Feature', 'jetpack' ),
				_x( 'Instant email notifications', 'Scan Product Feature', 'jetpack' ),
				_x( 'Access to latest Firewall rules', 'Scan Product Feature', 'jetpack' ),
			),
		);

		$products['search'] = array(
			'title'             => __( 'Jetpack Site Search', 'jetpack' ),
			'slug'              => 'jetpack_search',
			'description'       => __( 'Help your site visitors find answers instantly so they keep reading and buying. Great for sites with a lot of content.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array(),
			'features'          => array(
				_x( 'Instant search and indexing', 'Search Product Feature', 'jetpack' ),
				_x( 'Powerful filtering', 'Search Product Feature', 'jetpack' ),
				_x( 'Supports 38 languages', 'Search Product Feature', 'jetpack' ),
				_x( 'Spelling correction', 'Search Product Feature', 'jetpack' ),
			),
		);

		$products['akismet'] = array(
			'title'             => __( 'Akismet Anti-spam', 'jetpack' ),
			'slug'              => 'jetpack_anti_spam',
			'description'       => __( 'Save time and get better responses by automatically blocking spam from your comments and forms.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array( 'security' ),
			'features'          => array(
				_x( 'Comment and form spam protection', 'Anti-Spam Product Feature', 'jetpack' ),
				_x( 'Block spam without CAPTCHAs', 'Anti-Spam Product Feature', 'jetpack' ),
				_x( 'Advanced stats', 'Anti-Spam Product Feature', 'jetpack' ),
			),
		);

		$products['security'] = array(
			'title'             => _x( 'Security', 'Jetpack product name', 'jetpack' ),
			'slug'              => 'jetpack_security_t1_yearly',
			'description'       => __( 'Comprehensive site security, including Backup, Scan, and Anti-spam.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array(),
			'features'          => array(
				_x( 'Real-time cloud backups with 10GB storage', 'Security Tier 1 Feature', 'jetpack' ),
				_x( 'Automated real-time malware scan', 'Security Daily Plan Feature', 'jetpack' ),
				_x( 'One-click fixes for most threats', 'Security Daily Plan Feature', 'jetpack' ),
				_x( 'Comment & form spam protection', 'Security Daily Plan Feature', 'jetpack' ),
			),
		);

		$products['videopress'] = array(
			'title'             => __( 'Jetpack VideoPress', 'jetpack' ),
			'slug'              => 'jetpack_videopress',
			'description'       => __( 'High-quality, ad-free video built specifically for WordPress.', 'jetpack' ),
			'show_promotion'    => true,
			'discount_percent'  => 50,
			'included_in_plans' => array(),
			'features'          => array(
				_x( '1TB of storage', 'VideoPress Product Feature', 'jetpack' ),
				_x( 'Built into WordPress editor', 'VideoPress Product Feature', 'jetpack' ),
				_x( 'Ad-free and customizable player', 'VideoPress Product Feature', 'jetpack' ),
				_x( 'Unlimited users', 'VideoPress Product Feature', 'jetpack' ),
			),
		);

		if ( $show_legacy ) {
			$products['jetpack_backup_daily'] = array(
				'title'             => __( 'Jetpack Backup', 'jetpack' ),
				'slug'              => 'jetpack_backup_daily',
				'description'       => __( 'Never lose a word, image, page, or time worrying about your site with automated backups & one-click restores.', 'jetpack' ),
				'show_promotion'    => false,
				'discount_percent'  => 0,
				'included_in_plans' => array(),
				'features'          => array(
					_x( 'Automated daily backups (off-site)', 'Backup Product Feature', 'jetpack' ),
					_x( 'One-click restores', 'Backup Product Feature', 'jetpack' ),
					_x( 'Unlimited backup storage', 'Backup Product Feature', 'jetpack' ),
				),
			);
		}

		return $products;
	}

	/**
	 * Register product descriptions for partner coupon usage.
	 *
	 * @since 10.4.0
	 *
	 * @param array $products An array of registered products.
	 *
	 * @return array
	 */
	public function get_partner_coupon_product_descriptions( $products ) {
		return array_merge( $products, self::get_products_for_purchase( true ) );
	}

	/**
	 * Determine if the current user is allowed to make Jetpack purchases without
	 * a WordPress.com account
	 *
	 * @return boolean True if the user can make purchases, false if not
	 */
	public static function current_user_can_purchase() {

		// The site must be site-connected to Jetpack (no users connected).
		if ( ! self::connection()->is_site_connection() ) {
			return false;
		}

		// Make sure only administrators can make purchases.
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Add 5-star review link on the Jetpack Plugin meta, in the plugins list table (on the plugins page).
	 *
	 * @param array  $plugin_meta An array of the plugin's metadata.
	 * @param string $plugin_file Path to the plugin file.
	 *
	 * @return array $plugin_meta An array of the plugin's metadata.
	 */
	public function add_5_star_review_link( $plugin_meta, $plugin_file ) {
		if ( $plugin_file !== 'jetpack/jetpack.php' ) {
			return $plugin_meta;
		}

		$u    = get_current_user_id();
		$site = get_site_url();

		$plugin_meta[] = '<a href="https://jetpack.com/redirect?source=jetpack-plugin-review&site=' . esc_attr( $site ) . '&u=' . esc_attr( $u ) . '" target="_blank" rel="noopener noreferrer" title="' . esc_attr__( 'Rate Jetpack on WordPress.org', 'jetpack' ) . '" style="color: #ffb900">'
			. str_repeat( '<span class="dashicons dashicons-star-filled" style="font-size: 16px; width:16px; height: 16px"></span>', 5 )
			. '</a>';

		return $plugin_meta;
	}

	/**
	 * Lazy instantiation of the Plugin_Tracking object.
	 *
	 * @since 13.9
	 *
	 * @return void
	 */
	public function initialize_tracking() {
		if ( did_action( 'jetpack_initialize_tracking' ) > 1 ) {
			// Only need to run once.
			return;
		}

		if ( ( new Tracking( 'jetpack', $this->connection_manager ) )->should_enable_tracking( new Terms_Of_Service(), new Status() ) || static::is_connection_ready() ) {
			( new Plugin_Tracking() )->init();
		}
	}

	/**
	 * Run the "initialize tracking" hook.
	 *
	 * @since 13.9
	 */
	public function run_initialize_tracking_action() {
		/**
		 * Fires when the tracking needs to be initialized.
		 * Doesn't necessarily mean that will actually happen, depends if the 'jetpack_tos_agreed' option is set.
		 *
		 * @since 13.9
		 */
		do_action( 'jetpack_initialize_tracking' );
	}

	/**
	 * Initialize REST jsonAPI if needed.
	 *
	 * @return void
	 */
	public function maybe_initialize_rest_jsonapi() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! empty( $_GET['jsonapi'] ) && ( ! defined( 'IS_WPCOM' ) || ! IS_WPCOM ) ) {
			require_once ABSPATH . 'wp-admin/includes/admin.php'; // JSON API relies on WP functionality not autoloaded in REST.

			define( 'WPCOM_JSON_API__BASE', 'public-api.wordpress.com/rest/v1' );
			require_once JETPACK__PLUGIN_DIR . 'class.json-api-endpoints.php';
		}
	}

	/**
	 * Run plugin post-activation actions if we need to.
	 *
	 * @return void
	 */
	private function plugin_post_activation() {
		if ( ( new Status() )->is_offline_mode() ) {
			return;
		}

		if ( get_transient( 'activated_jetpack' ) ) {
			delete_transient( 'activated_jetpack' );

			if ( ( new Host() )->is_woa_site() ) {
				$redirect_url = static::admin_url( 'page=jetpack' );
			} elseif ( is_network_admin() ) {
				$redirect_url = admin_url( 'network/admin.php?page=jetpack' );
			} elseif ( get_transient( 'my_jetpack_product_activated' ) ) {
				// don't redirect if this is an activation that just came from My Jetpack
				// My Jetpack has its own set of post-activation redirects
				return;
			} elseif ( My_Jetpack_Initializer::should_initialize() ) {
				$redirect_url = static::admin_url( 'page=my-jetpack' );
			} else {
				$redirect_url = static::admin_url( 'page=jetpack' );
			}

			wp_safe_redirect( $redirect_url );
		}
	}
}

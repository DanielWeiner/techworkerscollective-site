<?php
/**
 * Jetpack AI Sidebar — Agents Manager integration and provider registration.
 *
 * Initializes the jetpack-agents-manager package so it loads the Agents
 * Manager bundle and emits its `agentsManagerData` payload, registers Jetpack
 * AI as an Agents Manager provider, and loads the Jetpack AI provider bundle
 * that exposes Jetpack AI abilities in the block editor.
 *
 * @package automattic/jetpack
 */

namespace Automattic\Jetpack\Extensions\AiAssistantPlugin;

use Automattic\Jetpack\Agents_Manager\Agents_Manager;
use Automattic\Jetpack\Connection\Manager as Connection_Manager;
use Automattic\Jetpack\Current_Plan;
use Automattic\Jetpack\SEO\Ai_Seo;
use Automattic\Jetpack\Status;
use Automattic\Jetpack\Status\Host;

// Required directly rather than relying on the plugin bootstrap: on
// WordPress.com Simple the extension files load through wpcom's own loader
// and load-jetpack.php never runs.
require_once __DIR__ . '/../../../../_inc/lib/class-jetpack-ai-settings.php';

const AM_ASSET_BASE_PATH                  = 'widgets.wp.com/agents-manager/';
const AI_SIDEBAR_ASSET_TRANSIENT          = 'jetpack_ai_sidebar_asset';
const AI_SIDEBAR_JS_URL                   = 'https://' . AM_ASSET_BASE_PATH . 'jetpack-ai-sidebar.min.js';
const AI_SIDEBAR_CSS_URL                  = 'https://' . AM_ASSET_BASE_PATH . 'jetpack-ai-sidebar.css';
const AI_SIDEBAR_RTL_CSS_URL              = 'https://' . AM_ASSET_BASE_PATH . 'jetpack-ai-sidebar.rtl.css';
const AI_SIDEBAR_PROVIDER_URL             = 'https://' . AM_ASSET_BASE_PATH . 'jetpack-ai-sidebar.provider.mjs';
const AI_SIDEBAR_AGENT_ID                 = 'wp-orchestrator';
const AI_SIDEBAR_TOOLBAR_BUTTON_EXTENSION = 'ai-sidebar-toolbar-button';
const AI_SIDEBAR_AGENT_NOTICE_EXTENSION   = 'ai-sidebar-agent-notice';
const AI_SIDEBAR_AGENT_SUPPORT_EXTENSION  = 'ai-sidebar-agent-support';

/**
 * Initializes the Agents Manager package and registers the Jetpack AI
 * provider in the block editor.
 */
class Jetpack_AI_Sidebar {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public static function init(): void {
		// Ahead of the sidebar gate: the notice also shows on sites merely eligible for the Agent.
		add_action( 'jetpack_register_gutenberg_extensions', array( __CLASS__, 'register_agent_notice_extension' ), 99 );

		// Gate the whole sidebar entrypoint on the preview surface, which is
		// itself overridable via the jetpack_ai_sidebar_enabled filter.
		if ( ! self::is_jetpack_ai_sidebar_preview_enabled() ) {
			return;
		}

		// Initialize the Agents Manager package so it owns loading the Agents
		// Manager bundle and emitting the `agentsManagerData` payload. The call
		// is idempotent: on WordPress.com and Atomic, jetpack-mu-wpcom may have
		// already initialized it, in which case this is a no-op.
		Agents_Manager::init();

		// Register as Agents Manager provider. The filter fires inside
		// Agents_Manager::enqueue_scripts(). Priority 20 so Jetpack loads
		// AFTER Image Studio (priority 10).
		add_filter( 'agents_manager_agent_providers', array( __CLASS__, 'register_provider' ), 20 );

		add_filter( 'jetpack_ai_sidebar_agents_manager_data', array( __CLASS__, 'add_agents_manager_data' ), 10, 1 );

		// Ask the Agents Manager package to mount on Jetpack AI provider surfaces.
		add_filter( 'agents_manager_enabled_in_block_editor', array( __CLASS__, 'enable_agents_manager_on_provider_surfaces' ) );

		// Enqueue the IIFE bundle on supported editor surfaces — it registers
		// Jetpack AI abilities via @wordpress/abilities, which Big Sky or the
		// Agents Manager can discover regardless of which provider system is active.
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'maybe_enqueue_abilities_script' ), 201 );

		// Patch Jetpack AI Sidebar Preview data into agentsManagerData when the
		// Agents Manager bundle was enqueued by an external host (Big Sky on
		// Atomic, etc.) and the jetpack_ai_sidebar_agents_manager_data filter
		// never fired. Priority 250 runs after both jetpack-mu-wpcom and the
		// Agents Manager package enqueue (priority 101).
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'maybe_patch_jetpack_ai_sidebar_preview_data' ), 250 );

		// Let editor JS know when the Jetpack AI Sidebar toolbar button replaces the legacy AI toolbar.
		add_action( 'jetpack_register_gutenberg_extensions', array( __CLASS__, 'register_toolbar_button_extension' ), 99 );
	}

	// ──────────────────────────────────────────────────
	// Jetpack AI provider bundle
	// ──────────────────────────────────────────────────

	/**
	 * Enqueue the IIFE bundle that registers Jetpack AI abilities.
	 *
	 * This runs independently of AM/provider registration so preview abilities
	 * are available even when Big Sky standalone is the active UI.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_abilities_script(): void {
		if ( ! self::should_expose_provider() ) {
			return;
		}

		// CIAB (next-admin) has its own AM setup — don't enqueue alongside it.
		if ( did_action( 'next_admin_init' ) ) {
			return;
		}

		if ( self::is_agents_manager_disconnected() ) {
			return;
		}

		// Guard against double-enqueue (e.g. hooked multiple times).
		if ( wp_script_is( 'jetpack-ai-provider' ) ) {
			return;
		}

		$asset_data = self::get_ai_sidebar_asset_data();
		if ( ! $asset_data ) {
			return;
		}

		$version      = $asset_data['version'] ?? false;
		$dependencies = $asset_data['dependencies'] ?? array();

		wp_enqueue_script(
			'jetpack-ai-provider',
			AI_SIDEBAR_JS_URL,
			$dependencies,
			$version,
			true
		);

		wp_enqueue_style(
			'jetpack-ai-provider',
			is_rtl() ? AI_SIDEBAR_RTL_CSS_URL : AI_SIDEBAR_CSS_URL,
			array(),
			$version
		);
	}

	// ──────────────────────────────────────────────────
	// Asset manifest (Image Studio pattern)
	// ──────────────────────────────────────────────────

	/**
	 * Try to read the asset manifest from the local filesystem.
	 *
	 * On WordPress.com, widgets.wp.com assets are available at ABSPATH.
	 *
	 * @param string $relative_path The relative path to the JSON file.
	 * @return array|false The decoded asset data, or false if not available locally.
	 */
	private static function get_asset_data_from_file( string $relative_path ) {
		$local_path = ABSPATH . $relative_path;
		if ( ! file_exists( $local_path ) ) {
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading a local file, not a remote URL.
		$contents = file_get_contents( $local_path );
		if ( false === $contents ) {
			return false;
		}

		$data = json_decode( $contents, true );
		if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
			return false;
		}

		return $data;
	}

	/**
	 * Fetch the asset manifest via HTTP.
	 *
	 * @param string $url The URL to fetch.
	 * @return array|false The decoded asset data, or false on failure.
	 */
	private static function get_asset_data_from_remote( string $url ) {
		$response = wp_safe_remote_get( $url );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$content_type = wp_remote_retrieve_header( $response, 'content-type' );
		if ( is_string( $content_type ) && false === stripos( $content_type, 'json' ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
			return false;
		}

		return $data;
	}

	// ──────────────────────────────────────────────────
	// Provider registration
	// ──────────────────────────────────────────────────

	/**
	 * Register Jetpack AI as an Agents Manager provider.
	 *
	 * Appends the CDN-hosted ESM wrapper URL to the providers list so AM
	 * can dynamically import it. Asset enqueueing is handled separately by
	 * maybe_enqueue_abilities_script.
	 *
	 * @param array $providers Existing provider URLs.
	 * @return array Updated providers.
	 */
	public static function register_provider( array $providers ): array {
		// CIAB (next-admin) has AM natively — skip to avoid duplicate agents.
		if ( did_action( 'next_admin_init' ) ) {
			return $providers;
		}

		// The provider IIFE is enqueued on the same surfaces where the ESM
		// wrapper is registered. Avoid registering the wrapper when AM may
		// import it before window.__JetpackAIProvider exists.
		if ( ! self::should_expose_provider() ) {
			return $providers;
		}

		// The providers filter still runs for disconnected variants.
		if ( self::is_agents_manager_disconnected() ) {
			return $providers;
		}

		// Don't register if the IIFE bundle cannot be loaded. The ESM wrapper
		// re-exports from window.__JetpackAIProvider at import time; if the
		// IIFE never ran, toolProvider is still a truthy Proxy and AM would
		// call getAbilities() on it and get undefined, breaking the merge.
		if ( ! self::get_ai_sidebar_asset_data() ) {
			return $providers;
		}

		// Register as AM provider via CDN-hosted ESM wrapper.
		// AM dynamically imports this module to merge tools, suggestions, and components.
		// No ?ver= needed — the wrapper re-exports from window.__JetpackAIProvider
		// at import time, so its behavior always matches the loaded IIFE bundle.
		$providers[] = AI_SIDEBAR_PROVIDER_URL;

		return $providers;
	}

	/**
	 * Fetch and cache the CDN asset manifest for the AI sidebar bundle.
	 *
	 * @return array|false The decoded asset data, or false on failure.
	 */
	private static function get_ai_sidebar_asset_data() {
		$skip_cache = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG;

		if ( ! $skip_cache ) {
			$cached = get_transient( AI_SIDEBAR_ASSET_TRANSIENT );
			if ( false !== $cached ) {
				return $cached;
			}
		}

		$json_path = AM_ASSET_BASE_PATH . 'jetpack-ai-sidebar.asset.json';

		// Try local file first (available on WordPress.com).
		$data = self::get_asset_data_from_file( $json_path );

		// Fallback to remote fetch.
		if ( false === $data ) {
			$data = self::get_asset_data_from_remote( 'https://' . $json_path );
		}

		if ( false === $data ) {
			// The manifest is unavailable from both the local file and the CDN
			// — for example when the server cannot reach widgets.wp.com. Skip
			// rather than enqueue a provider whose bundle the browser may also
			// be unable to load, which would break the Agents Manager merge.
			return false;
		}

		if ( ! $skip_cache ) {
			set_transient( AI_SIDEBAR_ASSET_TRANSIENT, $data, HOUR_IN_SECONDS );
		}

		return $data;
	}

	// ──────────────────────────────────────────────────
	// Helper methods
	// ──────────────────────────────────────────────────

	/**
	 * UI feature flag for the SEO suggestions (SEO title and meta description).
	 *
	 * Two halves: the site can offer AI SEO at all — the package's shared gate,
	 * the same one the AI settings row uses, so the control and the surface it
	 * governs cannot drift — and the feature's own toggle is on. Kept independent
	 * of the Optimize Title suggestion: SEO suggestions target the SEO meta
	 * fields, not the visible post title.
	 *
	 * The SEO *feature* option is consulted, not the automatic-generation one:
	 * a switched-off feature must not offer suggestions, even user-initiated
	 * ones, while automatic generation governs only automatic runs.
	 *
	 * Guarded with class_exists: the autoloader can pick an older jetpack-seo
	 * copy from another plugin, predating the shared gate. Suggestions stay off
	 * without it.
	 *
	 * @return bool
	 */
	private static function is_seo_suggestions_enabled(): bool {
		return class_exists( Ai_Seo::class )
			&& Ai_Seo::is_available()
			&& \Jetpack_AI_Settings::is_ai_seo_enabled();
	}

	/**
	 * UI feature flag for the public Jetpack AI Sidebar Preview surface: this
	 * host loads the sidebar, and at least one feature it surfaces is on.
	 *
	 * @return bool
	 */
	private static function is_jetpack_ai_sidebar_preview_enabled(): bool {
		return self::is_host_enabled() && self::has_enabled_sidebar_features();
	}

	/**
	 * Whether this host loads the sidebar at all: a WordPress.com platform site
	 * with Big Sky enabled, past the filter and the master switch. Public and
	 * feature-free so the AI SEO gate can ask without asking back through it.
	 *
	 * @since 16.2
	 *
	 * @return bool
	 */
	public static function is_host_enabled(): bool {
		$host = new Host();

		$enabled = false;
		if ( $host->is_wpcom_platform() && class_exists( 'Big_Sky' ) ) {
			$default = $host->is_wpcom_simple() ? '1' : '0';
			$enabled = (bool) get_option( 'big_sky_enable', $default );
		}

		/**
		 * Filter to enable or disable the Jetpack AI sidebar feature.
		 *
		 * Defaults to true only on WordPress.com platform sites with Big Sky
		 * present and enabled. Acts as a host-level override that can force the
		 * sidebar on (e.g. for local development) or off, and is respected by
		 * init() and every sidebar surface. The override cannot force the
		 * sidebar on while the writing-assistant and SEO enhancer features are
		 * both off — a featureless sidebar never loads.
		 *
		 * @param bool $enabled Whether the Jetpack AI sidebar is enabled.
		 */
		$enabled = (bool) apply_filters( 'jetpack_ai_sidebar_enabled', $enabled );

		// Re-asserted after the filter so a later filter cannot surface a sidebar
		// blocked by the host or master gates — the gates are final, as with
		// is_ai_enabled().
		return $enabled && \Jetpack_AI_Settings::apply_master_gates( true );
	}

	/**
	 * Whether any feature the sidebar surfaces is effectively enabled; with
	 * nothing to offer it must not load. Caveat: init() runs before seo-tools
	 * registers jetpack_disable_seo_tools, so that term reads its default here.
	 *
	 * @return bool
	 */
	private static function has_enabled_sidebar_features(): bool {
		return \Jetpack_AI_Settings::is_feature_enabled( 'writing_assistant' )
			|| self::is_seo_suggestions_enabled();
	}

	/**
	 * Whether the Jetpack AI provider bundle should be exposed for this request.
	 *
	 * This is scoped to the supported editor surfaces: post editor, page editor,
	 * and site editor. Each surface remains subject to the preview and AI feature
	 * gates.
	 *
	 * @return bool
	 */
	private static function should_expose_provider(): bool {
		return self::is_jetpack_ai_sidebar_preview_enabled()
			&& self::is_supported_provider_surface()
			&& self::has_ai_features();
	}

	/**
	 * Whether the Agents Manager is loading a disconnected build, which it does
	 * when the current user has no linked WordPress.com account.
	 *
	 * @return bool
	 */
	private static function is_agents_manager_disconnected(): bool {
		$variant = Agents_Manager::get_active_variant();

		// Null means the Agents Manager is not loading at all, which is not a disconnection.
		return is_string( $variant ) && str_contains( $variant, 'disconnected' );
	}

	/**
	 * Preview configuration consumed by the Agents Manager and Jetpack AI provider bundles.
	 *
	 * @return array Preview mode and feature availability.
	 */
	private static function get_jetpack_ai_sidebar_preview_config(): array {
		// Ability permission callbacks enforce server-side access for these
		// features. The writing suggestions additionally follow the writing
		// assistant toggle on the AI settings page — a switched-off feature
		// must not surface suggestions even when an external host (Big Sky,
		// Woo) draws the sidebar — and SEO requires the site-side gates below.
		$writing_on = \Jetpack_AI_Settings::is_feature_enabled( 'writing_assistant' );

		$features = array(
			'aiEditorialReview'       => (bool) apply_filters( 'jetpack_ai_editorial_review_enabled', true ) && $writing_on,
			'generateFeedback'        => $writing_on,
			'proofreadContent'        => $writing_on,
			'blockTransformations'    => $writing_on,
			'blockToolbarButton'      => $writing_on,
			'optimizeTitleSuggestion' => $writing_on,
			'seoSuggestions'          => self::is_seo_suggestions_enabled(),
			'excerptSuggestion'       => $writing_on,
			'chatHistory'             => false,
			'supportGuides'           => false,
		);

		/**
		 * Filter the feature set exposed in Jetpack AI Sidebar Preview.
		 *
		 * @param array $features Associative array of preview feature flags.
		 */
		$filtered_features = apply_filters( 'jetpack_ai_sidebar_preview_features', $features );
		$features          = is_array( $filtered_features ) ? array_merge( $features, $filtered_features ) : $features;

		// Normalize the flags released here while leaving host-added values
		// untouched. Keep the AI settings page toggles and SEO's site-side
		// requirements final.
		$features['aiEditorialReview']       = (bool) $features['aiEditorialReview'] && $writing_on;
		$features['generateFeedback']        = (bool) $features['generateFeedback'] && $writing_on;
		$features['proofreadContent']        = (bool) $features['proofreadContent'] && $writing_on;
		$features['blockToolbarButton']      = (bool) $features['blockToolbarButton'] && $writing_on;
		$features['optimizeTitleSuggestion'] = (bool) $features['optimizeTitleSuggestion'] && $writing_on;
		$features['seoSuggestions']          = (bool) $features['seoSuggestions'] && self::is_seo_suggestions_enabled();
		$features['excerptSuggestion']       = (bool) $features['excerptSuggestion'] && $writing_on;
		// Block transformations (Translate, Change Tone, etc.) are writing features
		// and follow the writing assistant toggle.
		$features['blockTransformations'] = (bool) $features['blockTransformations'] && $writing_on;

		return array(
			'enabled'                    => self::is_jetpack_ai_sidebar_preview_enabled(),
			'features'                   => $features,
			// Not in $features, which is public and host-filterable.
			'agentNoticeActionAvailable' => self::is_agent_action_available(),
		);
	}

	/**
	 * Whether the Jetpack AI Sidebar toolbar button replaces the legacy AI toolbar.
	 *
	 * The button is a writing entry point, so it follows the writing assistant
	 * toggle. Switching it off cannot bring the legacy toolbar back in its place:
	 * the editor renders that toolbar only while this feature is unavailable AND
	 * the AI Assistant block and its ai-assistant-support extension are
	 * registered, and both of those are themselves gated on the writing assistant.
	 *
	 * @return bool
	 */
	public static function is_toolbar_button_enabled(): bool {
		$preview_config = self::get_jetpack_ai_sidebar_preview_config();

		return self::should_expose_provider()
			&& ! self::is_agents_manager_disconnected()
			&& true === ( $preview_config['features']['blockToolbarButton'] ?? false );
	}

	/**
	 * Register the Jetpack AI Sidebar toolbar button feature.
	 *
	 * @return void
	 */
	public static function register_toolbar_button_extension(): void {
		if ( ! self::is_toolbar_button_enabled() ) {
			\Jetpack_Gutenberg::set_extension_unavailable(
				AI_SIDEBAR_TOOLBAR_BUTTON_EXTENSION,
				'jetpack_ai_sidebar_feature_disabled'
			);
			return;
		}

		\Jetpack_Gutenberg::set_extension_available( AI_SIDEBAR_TOOLBAR_BUTTON_EXTENSION );
	}

	/**
	 * Whether the legacy AI panel should point people at the WordPress Agent.
	 *
	 * True once there is a working agent to open, or earlier, once the site is
	 * eligible to turn one on.
	 *
	 * @return bool
	 */
	public static function is_agent_notice_enabled(): bool {
		if ( self::is_agent_action_available() ) {
			return true;
		}

		return self::is_wordpress_agent_eligible()
			&& self::is_supported_provider_surface()
			&& self::has_ai_features()
			&& ! self::is_agents_manager_disconnected();
	}

	/**
	 * Whether the site has turned the WordPress Agent on, whatever Jetpack's own
	 * sidebar gate says.
	 *
	 * The Big Sky plugin's own Settings > Writing checkbox can turn it off while
	 * the plugin stays active, so the option counts as well as the class.
	 *
	 * @return bool
	 */
	private static function is_wordpress_agent_enabled(): bool {
		$host = new Host();

		if ( ! $host->is_wpcom_platform() || ! class_exists( 'Big_Sky' ) ) {
			return false;
		}

		$default = $host->is_wpcom_simple() ? '1' : '0';

		return (bool) get_option( 'big_sky_enable', $default );
	}

	/**
	 * Whether the site is eligible to turn the WordPress Agent on, whether or not
	 * it has done so yet.
	 *
	 * Prefers the wpcom mu-plugin functions: the plan check cannot see the free
	 * trial. Not gated on the Big_Sky class, which on Simple only loads once the
	 * Agent is on.
	 *
	 * @return bool
	 */
	private static function is_wordpress_agent_eligible(): bool {
		$host = new Host();

		if ( ! $host->is_wpcom_platform() ) {
			return false;
		}

		if ( function_exists( 'big_sky_is_available_for_site' ) && function_exists( 'big_sky_is_enabled' ) ) {
			// @phan-suppress-next-line PhanUndeclaredFunction -- Provided by WPCOM's Big Sky mu-plugin; guarded by function_exists() above.
			return big_sky_is_available_for_site() || big_sky_is_enabled();
		}

		// Off Simple the plugin is only installed once the site qualifies.
		return class_exists( 'Big_Sky' ) || Current_Plan::supports( 'big-sky' );
	}

	/**
	 * Register the WordPress Agent notice feature.
	 *
	 * @return void
	 */
	public static function register_agent_notice_extension(): void {
		if ( ! self::is_agent_notice_enabled() ) {
			// Its own reason, so the payload tells this apart from the toolbar button.
			\Jetpack_Gutenberg::set_extension_unavailable(
				AI_SIDEBAR_AGENT_NOTICE_EXTENSION,
				'jetpack_ai_sidebar_agent_notice_disabled'
			);
			return;
		}

		\Jetpack_Gutenberg::set_extension_available( AI_SIDEBAR_AGENT_NOTICE_EXTENSION );

		// Tells the notice whether to offer to enable the Agent or to open it.
		if ( self::is_wordpress_agent_enabled() ) {
			\Jetpack_Gutenberg::set_extension_available( AI_SIDEBAR_AGENT_SUPPORT_EXTENSION );
			return;
		}

		\Jetpack_Gutenberg::set_extension_unavailable(
			AI_SIDEBAR_AGENT_SUPPORT_EXTENSION,
			'jetpack_ai_sidebar_agent_disabled'
		);
	}

	/**
	 * Whether the notice's action button has a working agent to send people to.
	 *
	 * Narrower than is_agent_notice_enabled(): an eligible site shows the notice,
	 * but only an enabled one has a chat to open.
	 *
	 * @return bool
	 */
	public static function is_agent_action_available(): bool {
		return self::should_expose_provider() && ! self::is_agents_manager_disconnected();
	}

	/**
	 * Add Jetpack AI Sidebar-specific data to externally emitted Agents Manager payloads.
	 *
	 * @param mixed $data Data encoded into `agentsManagerData`.
	 * @return mixed Filtered data.
	 */
	public static function add_agents_manager_data( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		$fields = self::get_agents_manager_data_fields( $data );
		if ( ! $fields ) {
			return $data;
		}

		// Set our fields in place, leaving the rest of $data (including agentProviders)
		// untouched so the client-side gate can drop Jetpack AI Sidebar while keeping
		// fallbacks such as the Big Sky provider. Hosts that need intentional overrides
		// should use the sidebar and preview feature filters.
		foreach ( $fields as $key => $value ) {
			$data[ $key ] = $value;
		}
		return $data;
	}

	/**
	 * Fields Jetpack should add to `agentsManagerData` for the current screen.
	 *
	 * @param array $data Existing Agents Manager data.
	 * @return array
	 */
	private static function get_agents_manager_data_fields( array $data = array() ): array {
		if ( ! self::should_expose_provider() ) {
			return array();
		}

		$fields = array();
		if ( empty( $data['agentId'] ) ) {
			$fields['agentId'] = AI_SIDEBAR_AGENT_ID;
		}
		$fields['jetpackAiSidebar'] = self::get_jetpack_ai_sidebar_preview_config();

		return $fields;
	}

	/**
	 * Enable Agents Manager when the Jetpack AI provider can be exposed.
	 *
	 * @param mixed $enabled Existing Agents Manager block-editor gate value.
	 * @return bool
	 */
	public static function enable_agents_manager_on_provider_surfaces( $enabled ): bool {
		if ( $enabled ) {
			return true;
		}

		return self::should_expose_provider();
	}

	/**
	 * Inject Jetpack AI Sidebar Preview data into an externally enqueued AM bundle.
	 *
	 * The design-intended hook is jetpack_ai_sidebar_agents_manager_data, applied
	 * by jetpack-agents-manager Agents_Manager::enqueue_scripts(). On Atomic the bundled
	 * mu-wpcom (via wpcomsh) lags this PR, so the filter never fires and the
	 * client gets agentsManagerData without our fields. This `before` script runs
	 * after the upstream `before` that declares the const (added earlier) but
	 * before the AM bundle reads it, so the field is set when AM initialises.
	 * Gives Atomic parity with Jurassic Ninja without depending on a wpcomsh
	 * redeploy.
	 *
	 * Skipped on WordPress.com Simple — wpcom's data extension owns the predicate
	 * there, including any WordPress.com-specific kill-switch override.
	 *
	 * @return void
	 */
	public static function maybe_patch_jetpack_ai_sidebar_preview_data(): void {
		if ( ( new Host() )->is_wpcom_simple() ) {
			return;
		}

		// 'registered' rather than 'enqueued': wp_add_inline_script attaches to any
		// registered handle and serializes correctly regardless of when the
		// enqueue lands in the dependency graph.
		if ( ! wp_script_is( 'agents-manager', 'registered' ) ) {
			return;
		}

		// The fields getter carries the provider exposure gate.
		$fields = self::get_agents_manager_data_fields();
		if ( ! $fields ) {
			return;
		}

		// The second path the provider URL can reach agentsManagerData by.
		if ( self::is_agents_manager_disconnected() ) {
			return;
		}

		// Build the assignments from the same field source as the data filter so the
		// two emit paths cannot drift. agentId is guarded client-side because the
		// externally emitted payload may already define the active agent.
		$assignments = '';
		foreach ( $fields as $key => $value ) {
			$assignment_value = wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );

			if ( 'agentId' === $key ) {
				$assignments .= ' if ( ! agentsManagerData.agentId ) { agentsManagerData.agentId = ' . $assignment_value . '; }';
				continue;
			}

			$assignments .= ' agentsManagerData.' . $key . ' = ' . $assignment_value . ';';
		}

		if ( self::get_ai_sidebar_asset_data() ) {
			$assignments .= self::get_agent_provider_upsert_script();
		}

		wp_add_inline_script(
			'agents-manager',
			'if ( typeof agentsManagerData === "object" && agentsManagerData !== null ) {' . $assignments . ' }',
			'before'
		);
	}

	/**
	 * Build the inline script that upserts Jetpack AI Sidebar into agentProviders.
	 *
	 * @return string Inline JavaScript.
	 */
	private static function get_agent_provider_upsert_script(): string {
		$provider_url = wp_json_encode( AI_SIDEBAR_PROVIDER_URL, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );

		return ' agentsManagerData.agentProviders = Array.isArray( agentsManagerData.agentProviders ) ? agentsManagerData.agentProviders : [];'
			. ' if ( agentsManagerData.agentProviders.indexOf( ' . $provider_url . ' ) === -1 ) { agentsManagerData.agentProviders.push( ' . $provider_url . ' ); }';
	}

	/**
	 * Check if the current screen is a block editor.
	 *
	 * @return bool
	 */
	private static function is_block_editor(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}

		$screen = get_current_screen();
		return $screen && $screen->is_block_editor();
	}

	/**
	 * Check if the current screen can consume the Jetpack AI provider bundle.
	 *
	 * @return bool
	 */
	private static function is_supported_provider_surface(): bool {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen instanceof \WP_Screen ) {
			return false;
		}

		if ( 'site-editor' === $screen->base ) {
			return true;
		}

		return self::is_block_editor()
			&& 'post' === $screen->base
			&& in_array( $screen->post_type, array( 'post', 'page' ), true );
	}

	/**
	 * Check whether AI features are available.
	 *
	 * - wpcom simple: available when Jetpack AI is enabled.
	 * - Atomic/self-hosted: requires Jetpack AI enabled, a connected owner, and non-offline mode.
	 *
	 * @return bool
	 */
	private static function has_ai_features(): bool {
		if ( ! \Jetpack_AI_Settings::is_ai_enabled() ) {
			return false;
		}

		$host = new Host();

		if ( $host->is_wpcom_simple() ) {
			return true;
		}

		return ( new Connection_Manager( 'jetpack' ) )->has_connected_owner()
			&& ! ( new Status() )->is_offline_mode();
	}
}

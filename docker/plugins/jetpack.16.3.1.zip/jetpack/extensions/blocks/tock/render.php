<?php
/**
 * Tock block render implementation.
 *
 * Loaded lazily from tock.php only when the block is rendered, to keep
 * the render body out of the eager front-end PHP/opcache footprint.
 *
 * @package automattic/jetpack
 */

namespace Automattic\Jetpack\Extensions\Tock;

use Automattic\Jetpack\Blocks;
use Jetpack_Gutenberg;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

/**
 * Render the widget and associated JS
 *
 * @param array $attr    The block attributes.
 */
function render_block_implementation( $attr ) {
	$content = '<div id="Tock_widget_container" data-tock-display-mode="Button" data-tock-color-mode="Blue" data-tock-locale="en-us" data-tock-timezone="America/New_York"></div>';
	if ( empty( $attr['url'] ) ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		return Jetpack_Gutenberg::notice(
			__( 'The block will not be shown to your site visitors until a Tock business name is set.', 'jetpack' ),
			'warning',
			Blocks::classes( Blocks::get_block_feature( __DIR__ ), $attr )
		);
	}

	wp_enqueue_script( 'tock-widget', 'https://www.exploretock.com/tock.js', array(), JETPACK__VERSION, true );

	// Add CSS to hide direct link.
	Jetpack_Gutenberg::load_assets_as_required( __DIR__ );

	wp_add_inline_script(
		'tock-widget',
		"!function(t,o){if(!t.tock){var e=t.tock=function(){e.callMethod?
		  e.callMethod.apply(e,arguments):e.queue.push(arguments)};t._tock||(t._tock=e),
		  e.push=e,e.loaded=!0,e.version='1.0',e.queue=[];}}(window,document);
			tock('init', " . wp_json_encode( $attr['url'], JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . ');',
		'before'
	);
	return sprintf(
		'<div class="%1$s">%2$s</div>',
		esc_attr( Blocks::classes( Blocks::get_block_feature( __DIR__ ), $attr ) ),
		$content
	);
}

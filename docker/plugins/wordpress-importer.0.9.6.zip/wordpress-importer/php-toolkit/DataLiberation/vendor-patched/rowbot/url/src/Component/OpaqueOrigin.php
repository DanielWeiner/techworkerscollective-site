<?php

declare( strict_types=1 );

namespace VendorPrefix\Rowbot\URL\Component;

use VendorPrefix\Rowbot\URL\Origin;

/**
 * @see https://html.spec.whatwg.org/multipage/browsers.html#concept-origin-opaque
 */
final class OpaqueOrigin implements Origin {
	public function getEffectiveDomain(): ?string {
		return null;
	}

	public function isOpaque(): bool {
		return true;
	}

	/**
	 * @param  Origin  $other
	 */
	public function isSameOrigin( $other ): bool {
		return $this === $other;
	}

	/**
	 * @param  Origin  $other
	 */
	public function isSameOriginDomain( $other ): bool {
		return $this === $other;
	}

	/**
	 * @see https://html.spec.whatwg.org/multipage/origin.html#ascii-serialisation-of-an-origin
	 */
	public function __toString(): string {
		return 'null';
	}
}
